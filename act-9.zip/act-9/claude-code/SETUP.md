# Try Act 9 with Claude Code

## 1. Open the repository

```bash
cd claude-production-architecture-workshop-act9
claude
```

Claude Code loads the root `CLAUDE.md`.

## 2. Start with plan mode

```bash
claude --permission-mode plan
```

## 3. Run the architecture-defense skill

Inside Claude Code:

```text
/act9-defense
```

Then ask:

```text
Evaluate evidence/current-state.json against evidence/readiness-policy.json.
Do not edit either file.
Produce a Go, Conditional Go, or No-Go recommendation with blockers,
conditions, rollout waves, rollback triggers, and named owners.
```

## 4. Suggested assignment prompts

### Assignment 1 — Evidence quality

```text
Read assignments/01_evidence_pack/README.md and the evidence directory.
Separate facts, assumptions, missing evidence, and stale evidence.
Do not edit source evidence.
Create assignments/01_evidence_pack/submission.md.
```

### Assignment 3 — Scorecard

```text
Inspect ReadinessEngine.java and the current evidence.
Run the tests.
Explain why the current result is No-Go.
Do not lower policy thresholds.
```

### Assignment 5 — Rollout waves

```text
Review RolloutPlanner.java.
Propose repository selection, entry criteria, exit criteria,
rollback triggers, and stop authority for each wave.
```

### Assignment 7 — Incident drill

```text
Use INC-3 from IncidentLibrary.
Simulate detection, containment, communication, reconciliation,
recovery validation, and lessons encoded into CLAUDE.md and CI.
```

### Assignment 8 — Executive defense

```text
Use /act9-defense.
Create a five-minute executive architecture defense.
Lead with the decision, then evidence, blockers, conditions,
rollout waves, rollback, and business outcomes.
```

### Controlled implementation

```text
Implement only the approved change.
Run:
cd act-9-java-readiness && ./scripts/test.sh
Summarize changed files, tests, evidence impact, residual risk, and rollback.
```

## 5. Included hooks

- `PreToolUse` asks before protected readiness evidence or policy is edited.
- `PostToolUse` runs the Java readiness tests after edits.

These controls support discipline but do not replace CODEOWNERS, CI, architecture review, or managed enterprise policy.
