# Certification-Style Questions

## 1
A program has strong productivity gains but incomplete rollback evidence. Best decision?

A. Go because value is proven  
B. Treat rollback as a hard gate for production-impacting rollout  
C. Remove rollback from the scorecard  
D. Wait for an incident

**Answer: B**

## 2
Why can a high weighted score still result in No-Go?

A. Scores never matter  
B. A hard blocker can override the aggregate score  
C. Training is always irrelevant  
D. Business outcomes must be ignored

**Answer: B**

## 3
What should follow closure of hard blockers when other gaps remain?

A. Immediate enterprise rollout  
B. Conditional Go through risk-based waves  
C. Remove CODEOWNERS  
D. Disable metrics

**Answer: B**

## 4
What is the first action after detecting duplicate irreversible writes?

A. Retry again  
B. Stop the write path and retries, then reconcile by idempotency evidence  
C. Increase timeout  
D. Delete traces

**Answer: B**

## 5
What makes an architecture defense defensible?

A. Confidence and presentation style  
B. Evidence, owners, thresholds, blockers, rollback, and measurable follow-up  
C. A longer prompt  
D. A unanimous model response

**Answer: B**
