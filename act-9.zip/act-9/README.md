# Claude Production Architecture Workshop — Act 9

## Production Delivery and Architecture Defense

This GitHub-ready package contains a complete Java production-readiness lab for deciding whether a Claude-enabled engineering program should scale.

It includes:

- a dependency-free Java readiness decision engine;
- repository, CI/CD, governance, eval, observability, rollback, incident, training, and adoption evidence;
- weighted production-readiness scoring;
- hard blockers and conditional-go logic;
- rollout-wave planning;
- rollback and incident simulations;
- certification-style architecture-defense assignments;
- model answers inside every assignment;
- Claude Code project instructions, permissions, hooks, and a reusable `/act9-defense` skill;
- Act 9 slides.

Core lesson:

> Production readiness is not a feeling. It is an evidence-backed, reversible, defensible decision.

## Quick start

```bash
cd act-9-java-readiness
./scripts/test.sh
./scripts/demo.sh
```

Then open:

```text
assignments/START_HERE.md
```

## Scenario

Leadership wants to scale Claude Code and Claude-powered delivery practices across 20 repositories.

Current evidence:

- 18 of 20 repositories have `CLAUDE.md`;
- 16 of 20 have complete CODEOWNERS coverage;
- 15 of 20 have all required CI gates;
- cycle time improved by 22%;
- review rework fell from +35% to +8%;
- no production incident occurred in the last 45 days;
- rollback evidence is complete in 80% of production-impacting pull requests;
- training katas were completed by 70% of active developers;
- metrics are reported monthly;
- incident lessons are now encoded into repository guidance and CI checks.

Participants must decide whether to approve, conditionally approve, or reject enterprise scale-out.
