# Production Readiness Decision Engine

## Requirements

- Java 17+
- Bash

## Test

```bash
./scripts/test.sh
```

## Demo

```bash
./scripts/demo.sh
```

## Expected current decision

The current evidence produces **NO_GO** because:

- required CI-gate coverage is below the enterprise minimum;
- rollback evidence is below the enterprise minimum.

When those hard blockers close, the decision becomes **CONDITIONAL_GO** until remaining readiness conditions are met.
