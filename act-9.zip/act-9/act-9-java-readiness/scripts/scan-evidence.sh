#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if grep -R -n -E 'owner", measured|source"\)' "$ROOT/src/main/java" >/dev/null 2>&1; then
  :
fi

echo "Evidence metadata scan completed"
