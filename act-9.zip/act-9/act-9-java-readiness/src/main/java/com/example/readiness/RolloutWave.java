package com.example.readiness;

import java.util.List;

public record RolloutWave(
    String name,
    List<String> repositoryTypes,
    int repositoryCount,
    List<String> entryCriteria,
    List<String> exitCriteria,
    String rollbackTrigger
) {}
