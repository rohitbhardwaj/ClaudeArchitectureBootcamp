package com.example.readiness;

import java.util.List;
import java.util.Map;

public record ReadinessResult(
    Decision decision,
    double weightedScore,
    Map<ReadinessDimension, Double> dimensionScores,
    List<Blocker> blockers,
    List<String> conditions,
    String rationale
) {}
