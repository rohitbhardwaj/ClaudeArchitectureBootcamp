package com.example.readiness;

import java.util.List;

public record IncidentScenario(
    String id,
    String title,
    String trigger,
    List<String> signals,
    List<String> containmentActions,
    List<String> recoveryEvidence
) {}
