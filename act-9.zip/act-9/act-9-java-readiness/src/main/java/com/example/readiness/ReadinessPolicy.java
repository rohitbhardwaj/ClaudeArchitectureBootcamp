package com.example.readiness;

public record ReadinessPolicy(
    double goThreshold,
    double conditionalGoThreshold,
    int maximumOpenHardBlockersForConditionalGo,
    double minimumRollbackCoverage,
    double minimumTrainingCoverage,
    double minimumCiCoverage
) {
    public static ReadinessPolicy enterpriseDefault() {
        return new ReadinessPolicy(
            0.90,
            0.75,
            0,
            0.95,
            0.85,
            0.90
        );
    }
}
