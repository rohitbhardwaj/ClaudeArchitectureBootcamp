package com.example.readiness;

public record Blocker(
    String evidenceId,
    String reason,
    String requiredAction,
    String owner
) {}
