package com.example.readiness;

public enum Decision {
    GO,
    CONDITIONAL_GO,
    NO_GO
}
