package com.example.readiness;

import java.util.List;

public interface EvidenceRepository {
    List<Evidence> load();
}
