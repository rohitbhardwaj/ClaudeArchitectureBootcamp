package com.example.readiness;

import java.util.List;

public class IncidentLibrary {
    public List<IncidentScenario> scenarios() {
        return List.of(
            new IncidentScenario(
                "INC-1",
                "AI-assisted API contract drift",
                "A generated refactor removes a response field used by two consumers.",
                List.of("contract test failure", "consumer error rate", "schema diff"),
                List.of("block deployment", "disable rollout wave", "restore prior contract"),
                List.of("replayed tests", "consumer confirmation", "rollback evidence")
            ),
            new IncidentScenario(
                "INC-2",
                "Sensitive data logging",
                "A generated error handler logs request bodies containing PII.",
                List.of("PII scan alert", "log anomaly", "security incident"),
                List.of("stop deployment", "revoke access", "purge affected logs"),
                List.of("scan clean", "access review", "incident lesson encoded in CI")
            ),
            new IncidentScenario(
                "INC-3",
                "Duplicate irreversible action",
                "A timeout causes a retry of a financial action without idempotency.",
                List.of("duplicate transaction", "retry spike", "reconciliation mismatch"),
                List.of("disable write tool", "halt retries", "reconcile transactions"),
                List.of("idempotency proof", "compensation record", "post-incident eval")
            )
        );
    }
}
