package com.example.readiness;

import java.util.*;

public class ReadinessEngine {

    public ReadinessResult evaluate(List<Evidence> evidence, ReadinessPolicy policy) {
        Objects.requireNonNull(evidence);
        Objects.requireNonNull(policy);

        Map<ReadinessDimension, List<Evidence>> grouped = new EnumMap<>(ReadinessDimension.class);
        for (Evidence item : evidence) {
            grouped.computeIfAbsent(item.dimension(), ignored -> new ArrayList<>()).add(item);
        }

        Map<ReadinessDimension, Double> dimensionScores = new EnumMap<>(ReadinessDimension.class);
        double totalWeight = 0.0;
        double weighted = 0.0;

        for (Map.Entry<ReadinessDimension, List<Evidence>> entry : grouped.entrySet()) {
            double dimensionWeight = entry.getValue().stream().mapToDouble(Evidence::weight).sum();
            double dimensionWeighted = entry.getValue().stream()
                .mapToDouble(e -> e.normalizedScore() * e.weight())
                .sum();

            double score = dimensionWeight == 0 ? 0.0 : dimensionWeighted / dimensionWeight;
            dimensionScores.put(entry.getKey(), score);
            totalWeight += dimensionWeight;
            weighted += dimensionWeighted;
        }

        double overall = totalWeight == 0 ? 0.0 : weighted / totalWeight;
        List<Blocker> blockers = detectBlockers(evidence, policy);
        List<String> conditions = buildConditions(evidence, policy);

        Decision decision;
        if (!blockers.isEmpty()) {
            decision = Decision.NO_GO;
        } else if (overall >= policy.goThreshold() && conditions.isEmpty()) {
            decision = Decision.GO;
        } else if (overall >= policy.conditionalGoThreshold()) {
            decision = Decision.CONDITIONAL_GO;
        } else {
            decision = Decision.NO_GO;
        }

        String rationale = switch (decision) {
            case GO -> "All hard gates are satisfied and weighted readiness meets the enterprise Go threshold.";
            case CONDITIONAL_GO -> "No hard blocker remains, but one or more readiness conditions must close during phased rollout.";
            case NO_GO -> "At least one hard blocker is open or the readiness score is below the minimum threshold.";
        };

        return new ReadinessResult(
            decision,
            round(overall),
            Map.copyOf(dimensionScores),
            List.copyOf(blockers),
            List.copyOf(conditions),
            rationale
        );
    }

    private List<Blocker> detectBlockers(List<Evidence> evidence, ReadinessPolicy policy) {
        List<Blocker> blockers = new ArrayList<>();

        evidence.stream()
            .filter(Evidence::hardBlocker)
            .filter(e -> !e.meetsTarget())
            .forEach(e -> blockers.add(new Blocker(
                e.id(),
                e.description() + " is below required target",
                "Close the gap and attach verified evidence",
                e.owner()
            )));

        find(evidence, "rollback-evidence").ifPresent(e -> {
            if (e.achieved() < policy.minimumRollbackCoverage()
                && blockers.stream().noneMatch(b -> b.evidenceId().equals(e.id()))) {
                blockers.add(new Blocker(
                    e.id(),
                    "Rollback evidence is below the enterprise minimum",
                    "Increase complete rollback evidence to at least "
                        + percent(policy.minimumRollbackCoverage()),
                    e.owner()
                ));
            }
        });

        find(evidence, "ci-gates").ifPresent(e -> {
            double coverage = e.achieved() / e.target();
            if (coverage < policy.minimumCiCoverage()
                && blockers.stream().noneMatch(b -> b.evidenceId().equals(e.id()))) {
                blockers.add(new Blocker(
                    e.id(),
                    "Required CI gate coverage is below enterprise minimum",
                    "Increase repository CI coverage to at least "
                        + percent(policy.minimumCiCoverage()),
                    e.owner()
                ));
            }
        });

        return blockers;
    }

    private List<String> buildConditions(List<Evidence> evidence, ReadinessPolicy policy) {
        List<String> conditions = new ArrayList<>();

        find(evidence, "repo-guidance").ifPresent(e -> {
            if (!e.meetsTarget()) conditions.add("Add CLAUDE.md to the remaining repositories.");
        });

        find(evidence, "codeowners").ifPresent(e -> {
            if (!e.meetsTarget()) conditions.add("Complete CODEOWNERS coverage across all production repositories.");
        });

        find(evidence, "training").ifPresent(e -> {
            if (e.achieved() < policy.minimumTrainingCoverage()) {
                conditions.add("Raise required training completion to at least "
                    + percent(policy.minimumTrainingCoverage()) + ".");
            }
        });

        find(evidence, "eval-coverage").ifPresent(e -> {
            if (!e.meetsTarget()) conditions.add("Complete regression and safety eval coverage.");
        });

        find(evidence, "trace-coverage").ifPresent(e -> {
            if (!e.meetsTarget()) conditions.add("Complete trace and decision-evidence coverage.");
        });

        return conditions;
    }

    private Optional<Evidence> find(List<Evidence> evidence, String id) {
        return evidence.stream().filter(e -> e.id().equals(id)).findFirst();
    }

    private static double round(double value) {
        return Math.round(value * 1000.0) / 1000.0;
    }

    private static String percent(double value) {
        return Math.round(value * 100.0) + "%";
    }
}
