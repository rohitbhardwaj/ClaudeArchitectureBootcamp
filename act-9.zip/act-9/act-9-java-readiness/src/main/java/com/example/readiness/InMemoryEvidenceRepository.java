package com.example.readiness;

import java.time.LocalDate;
import java.util.List;

public class InMemoryEvidenceRepository implements EvidenceRepository {

    public List<Evidence> load() {
        LocalDate measured = LocalDate.of(2026, 7, 31);

        return List.of(
            new Evidence(
                "repo-guidance",
                ReadinessDimension.REPOSITORY_CONTROL,
                "Repositories with CLAUDE.md",
                18, 20, 1.0, false,
                "Engineering Enablement", measured,
                "repository inventory"
            ),
            new Evidence(
                "codeowners",
                ReadinessDimension.REVIEW_AND_OWNERSHIP,
                "Repositories with complete CODEOWNERS",
                16, 20, 1.0, false,
                "Platform Governance", measured,
                "repository inventory"
            ),
            new Evidence(
                "ci-gates",
                ReadinessDimension.CI_CD_GATES,
                "Repositories with tests, dependency scan, PII scan, and API contract gates",
                15, 20, 1.2, true,
                "DevSecOps", measured,
                "CI inventory"
            ),
            new Evidence(
                "security-incidents",
                ReadinessDimension.SECURITY_AND_PRIVACY,
                "Days without a production security or privacy incident",
                45, 45, 1.2, false,
                "Security", measured,
                "incident register"
            ),
            new Evidence(
                "eval-coverage",
                ReadinessDimension.EVALS_AND_QUALITY,
                "Production workflows with regression and safety evals",
                18, 22, 1.1, false,
                "AI Quality", measured,
                "eval registry"
            ),
            new Evidence(
                "trace-coverage",
                ReadinessDimension.OBSERVABILITY,
                "Production workflows with complete trace and decision evidence",
                19, 22, 1.0, false,
                "SRE", measured,
                "telemetry audit"
            ),
            new Evidence(
                "rollback-evidence",
                ReadinessDimension.ROLLBACK_AND_RECOVERY,
                "Production-impacting pull requests with complete rollback evidence",
                0.80, 0.95, 1.4, true,
                "Release Engineering", measured,
                "PR evidence audit"
            ),
            new Evidence(
                "training",
                ReadinessDimension.TRAINING_AND_ADOPTION,
                "Active developers completing required katas",
                0.70, 0.85, 1.0, false,
                "Engineering Enablement", measured,
                "training dashboard"
            ),
            new Evidence(
                "monthly-governance",
                ReadinessDimension.OPERATING_GOVERNANCE,
                "Monthly governance metrics reported",
                1, 1, 1.0, false,
                "Architecture Council", measured,
                "monthly governance pack"
            ),
            new Evidence(
                "cycle-time",
                ReadinessDimension.BUSINESS_OUTCOMES,
                "Relative cycle-time improvement",
                0.22, 0.15, 0.8, false,
                "Engineering Operations", measured,
                "delivery analytics"
            ),
            new Evidence(
                "review-rework",
                ReadinessDimension.BUSINESS_OUTCOMES,
                "Improvement in AI-assisted review rework",
                0.27, 0.20, 0.8, false,
                "Engineering Operations", measured,
                "PR analytics"
            ),
            new Evidence(
                "incident-learning",
                ReadinessDimension.OPERATING_GOVERNANCE,
                "Incident lessons encoded into repository guidance and CI",
                1, 1, 1.0, false,
                "Architecture Council", measured,
                "incident closure review"
            )
        );
    }
}
