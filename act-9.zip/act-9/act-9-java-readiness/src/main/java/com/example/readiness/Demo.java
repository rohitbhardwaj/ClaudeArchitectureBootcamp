package com.example.readiness;

public class Demo {
    public static void main(String[] args) {
        var evidence = new InMemoryEvidenceRepository().load();
        var result = new ReadinessEngine().evaluate(
            evidence,
            ReadinessPolicy.enterpriseDefault()
        );

        System.out.println("DECISION: " + result.decision());
        System.out.println("WEIGHTED SCORE: " + result.weightedScore());
        System.out.println("BLOCKERS:");
        result.blockers().forEach(System.out::println);
        System.out.println("CONDITIONS:");
        result.conditions().forEach(System.out::println);

        System.out.println("\nROLLOUT WAVES:");
        new RolloutPlanner().plan().forEach(System.out::println);

        System.out.println("\nINCIDENT DRILLS:");
        new IncidentLibrary().scenarios().forEach(System.out::println);
    }
}
