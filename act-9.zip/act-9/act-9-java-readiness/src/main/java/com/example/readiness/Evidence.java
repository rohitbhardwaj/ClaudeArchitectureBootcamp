package com.example.readiness;

import java.time.LocalDate;

public record Evidence(
    String id,
    ReadinessDimension dimension,
    String description,
    double achieved,
    double target,
    double weight,
    boolean hardBlocker,
    String owner,
    LocalDate measuredOn,
    String source
) {
    public double normalizedScore() {
        if (target <= 0) return 0.0;
        return Math.max(0.0, Math.min(1.0, achieved / target));
    }

    public boolean meetsTarget() {
        return achieved >= target;
    }
}
