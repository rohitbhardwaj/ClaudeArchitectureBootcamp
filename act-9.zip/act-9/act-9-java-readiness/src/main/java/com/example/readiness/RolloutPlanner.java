package com.example.readiness;

import java.util.List;

public class RolloutPlanner {
    public List<RolloutWave> plan() {
        return List.of(
            new RolloutWave(
                "Wave 0 — Lab",
                List.of("sandbox", "training"),
                2,
                List.of("training complete", "no production data", "manual review"),
                List.of("katas passed", "tool boundaries understood"),
                "any uncontained tool or data access"
            ),
            new RolloutWave(
                "Wave 1 — Low Risk",
                List.of("internal tools", "read-only services"),
                4,
                List.of("CLAUDE.md", "CODEOWNERS", "tests", "CI gates"),
                List.of("two stable release cycles", "no severity-1 findings"),
                "contract drift, security finding, or rollback failure"
            ),
            new RolloutWave(
                "Wave 2 — Customer Facing",
                List.of("customer APIs", "workflow services"),
                8,
                List.of("complete evals", "tracing", "rollback rehearsal", "named owner"),
                List.of("SLOs met", "review rework within target"),
                "SLO breach, unauthorized action, or incident"
            ),
            new RolloutWave(
                "Wave 3 — High Impact",
                List.of("payments", "identity", "regulated systems"),
                6,
                List.of("all enterprise gates", "approval controls", "incident drill"),
                List.of("architecture council approval", "30-day stable operation"),
                "any policy bypass, evidence gap, or unreconciled action"
            )
        );
    }
}
