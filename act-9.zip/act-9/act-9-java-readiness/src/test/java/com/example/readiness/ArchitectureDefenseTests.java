package com.example.readiness;

public class ArchitectureDefenseTests {
    public static void main(String[] args) {
        var repository = new InMemoryEvidenceRepository();
        var evidence = repository.load();

        TestSupport.check(
            evidence.stream().allMatch(e -> e.owner() != null && !e.owner().isBlank()),
            "Every evidence item needs an owner"
        );

        TestSupport.check(
            evidence.stream().allMatch(e -> e.source() != null && !e.source().isBlank()),
            "Every evidence item needs a source"
        );

        TestSupport.check(
            evidence.stream().allMatch(e -> e.measuredOn() != null),
            "Every evidence item needs a measurement date"
        );

        System.out.println("ArchitectureDefenseTests: PASS");
    }
}
