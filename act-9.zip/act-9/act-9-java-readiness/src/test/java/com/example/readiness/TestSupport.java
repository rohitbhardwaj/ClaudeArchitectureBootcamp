package com.example.readiness;

public final class TestSupport {
    private TestSupport() {}

    public static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void equals(Object expected, Object actual, String message) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(
                message + " expected=" + expected + " actual=" + actual
            );
        }
    }
}
