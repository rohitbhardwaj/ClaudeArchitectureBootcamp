package com.example.readiness;

public class TestRunner {
    public static void main(String[] args) {
        ReadinessEngineTests.main(args);
        ArchitectureDefenseTests.main(args);
        System.out.println("ALL ACT 9 TESTS: PASS");
    }
}
