package com.example.readiness;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReadinessEngineTests {

    public static void main(String[] args) {
        currentEvidenceIsNoGoBecauseHardGatesRemainOpen();
        closingHardGatesProducesConditionalGo();
        completeEvidenceProducesGo();
        rolloutPlanUsesRiskWaves();
        incidentLibraryContainsRecoveryEvidence();
        System.out.println("ReadinessEngineTests: PASS");
    }

    static void currentEvidenceIsNoGoBecauseHardGatesRemainOpen() {
        var result = new ReadinessEngine().evaluate(
            new InMemoryEvidenceRepository().load(),
            ReadinessPolicy.enterpriseDefault()
        );

        TestSupport.equals(Decision.NO_GO, result.decision(), "Expected No-Go");
        TestSupport.check(
            result.blockers().stream().anyMatch(b -> b.evidenceId().equals("rollback-evidence")),
            "Rollback evidence should block"
        );
        TestSupport.check(
            result.blockers().stream().anyMatch(b -> b.evidenceId().equals("ci-gates")),
            "CI coverage should block"
        );
    }

    static void closingHardGatesProducesConditionalGo() {
        List<Evidence> evidence = new ArrayList<>(new InMemoryEvidenceRepository().load());
        evidence.replaceAll(e -> switch (e.id()) {
            case "rollback-evidence" -> replacement(e, 0.95, 0.95);
            case "ci-gates" -> replacement(e, 20, 20);
            default -> e;
        });

        var result = new ReadinessEngine().evaluate(
            evidence,
            ReadinessPolicy.enterpriseDefault()
        );

        TestSupport.equals(
            Decision.CONDITIONAL_GO,
            result.decision(),
            "Expected Conditional Go"
        );
        TestSupport.check(result.blockers().isEmpty(), "No hard blockers expected");
        TestSupport.check(!result.conditions().isEmpty(), "Conditions should remain");
    }

    static void completeEvidenceProducesGo() {
        List<Evidence> evidence = new ArrayList<>(new InMemoryEvidenceRepository().load());
        evidence.replaceAll(e -> switch (e.id()) {
            case "repo-guidance" -> replacement(e, 20, 20);
            case "codeowners" -> replacement(e, 20, 20);
            case "ci-gates" -> replacement(e, 20, 20);
            case "eval-coverage" -> replacement(e, 22, 22);
            case "trace-coverage" -> replacement(e, 22, 22);
            case "rollback-evidence" -> replacement(e, 0.98, 0.95);
            case "training" -> replacement(e, 0.90, 0.85);
            default -> e;
        });

        var result = new ReadinessEngine().evaluate(
            evidence,
            ReadinessPolicy.enterpriseDefault()
        );

        TestSupport.equals(Decision.GO, result.decision(), "Expected Go");
        TestSupport.check(result.blockers().isEmpty(), "No blockers expected");
        TestSupport.check(result.conditions().isEmpty(), "No conditions expected");
    }

    static void rolloutPlanUsesRiskWaves() {
        var waves = new RolloutPlanner().plan();
        TestSupport.equals(4, waves.size(), "Expected four rollout waves");
        TestSupport.check(
            waves.get(3).repositoryTypes().contains("payments"),
            "High-impact wave should include payments"
        );
    }

    static void incidentLibraryContainsRecoveryEvidence() {
        var scenarios = new IncidentLibrary().scenarios();
        TestSupport.check(
            scenarios.stream().allMatch(s -> !s.recoveryEvidence().isEmpty()),
            "Every incident needs recovery evidence"
        );
    }

    private static Evidence replacement(Evidence e, double achieved, double target) {
        return new Evidence(
            e.id(), e.dimension(), e.description(),
            achieved, target, e.weight(), e.hardBlocker(),
            e.owner(), LocalDate.of(2026, 7, 31), e.source()
        );
    }
}
