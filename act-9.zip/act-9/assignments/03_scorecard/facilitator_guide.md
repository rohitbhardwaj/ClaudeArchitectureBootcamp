# Facilitator Guide — Build the Readiness Scorecard

## Watch for

- using an average score to hide a critical blocker;
- treating incident-free days as proof of safety;
- allowing business value to override rollback;
- no evidence owner or measurement date;
- enterprise rollout without waves;
- rollback described only as code revert;
- no reconciliation for irreversible actions;
- lowering thresholds to obtain Go.

## Debrief

1. Which evidence is strongest?
2. Which evidence is missing?
3. What blocks rollout?
4. What can be a condition?
5. What is the first rollback action?
