# Assignment 3 — Build the Readiness Scorecard

## Task

Run the Java engine, inspect its weighting, and explain the current result. Propose improvements without changing policy to force a preferred answer.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
