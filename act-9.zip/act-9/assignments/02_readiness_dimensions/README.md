# Assignment 2 — Define Production Readiness Dimensions

## Task

Create a readiness model covering repository controls, ownership, CI/CD, security, evals, observability, rollback, training, governance, and business outcomes.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
