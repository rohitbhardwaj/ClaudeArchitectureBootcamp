# Model Answer — Try the Defense in Claude Code

Start in plan mode, invoke `/act9-defense`, read current evidence and policy, and prohibit edits to them. Require the output to separate facts, blockers, conditions, and assumptions. Run the Java tests. The PreToolUse hook should ask before evidence edits, while PostToolUse runs checks after approved changes. Human reviewers remain accountable for the final decision.

## Why this answer is strong

It protects evidence integrity, separates hard gates from improvement conditions, and connects the decision to reversible rollout and recovery.
