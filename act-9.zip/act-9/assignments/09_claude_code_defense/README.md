# Assignment 9 — Try the Defense in Claude Code

## Task

Use the repository CLAUDE.md, project settings, hooks, and `/act9-defense` skill to produce an evidence-backed decision.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
