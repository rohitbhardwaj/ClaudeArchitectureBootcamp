# Assignment 7 — Run an Incident and Recovery Drill

## Task

Use one incident scenario and demonstrate detection, containment, communication, recovery, verification, and lessons encoded into engineering controls.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
