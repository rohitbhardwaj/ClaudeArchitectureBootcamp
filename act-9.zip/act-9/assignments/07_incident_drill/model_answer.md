# Model Answer — Run an Incident and Recovery Drill

For duplicate financial action: disable the write tool, stop retries, preserve traces, query by idempotency key, reconcile transactions, notify owners, compensate where possible, verify balances, add an idempotency test and CI gate, update CLAUDE.md, and run the scenario in the eval suite. Recovery is not complete until business state and evidence are reconciled.

## Why this answer is strong

It protects evidence integrity, separates hard gates from improvement conditions, and connects the decision to reversible rollout and recovery.
