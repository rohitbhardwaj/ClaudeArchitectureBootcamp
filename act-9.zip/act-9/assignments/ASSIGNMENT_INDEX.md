# Act 9 Assignment Index

| # | Assignment | Main artifact |
|---|---|---|
| 1 | Read the Evidence Pack | Evidence quality assessment |
| 2 | Readiness Dimensions | Readiness model |
| 3 | Readiness Scorecard | Weighted score |
| 4 | Hard Blockers | Blocking conditions |
| 5 | Rollout Waves | Phased deployment plan |
| 6 | Release and Rollback Gates | Delivery control plan |
| 7 | Incident and Recovery Drill | Incident exercise |
| 8 | Executive Architecture Defense | Decision memo and presentation |
| 9 | Claude Code Defense | AI-assisted evidence review |
| 10 | Final Certification Scenario | Go / Conditional Go / No-Go |
