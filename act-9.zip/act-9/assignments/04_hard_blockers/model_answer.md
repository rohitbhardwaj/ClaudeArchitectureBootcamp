# Model Answer — Identify Hard Blockers

Hard blockers include missing critical CI gates, inadequate rollback evidence, open critical security findings, uncontrolled irreversible actions, missing production ownership, cross-tenant leakage, unavailable kill switch, and unrehearsed recovery for high-impact systems. Training or adoption gaps may be conditions for low-risk waves but can become blockers for high-impact waves.

## Why this answer is strong

It protects evidence integrity, separates hard gates from improvement conditions, and connects the decision to reversible rollout and recovery.
