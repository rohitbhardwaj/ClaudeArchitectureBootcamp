# Assignment 4 — Identify Hard Blockers

## Task

Define which findings must block rollout regardless of aggregate score.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
