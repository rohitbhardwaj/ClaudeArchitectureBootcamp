# Model Answer — Design Release and Rollback Gates

Repository gates include CLAUDE.md, CODEOWNERS, PR disclosure, and architecture rules. CI gates include tests, contracts, dependency, secret, PII, and eval checks. Production gates include canary, trace coverage, SLOs, cost budgets, and kill switch. Rollback evidence must identify trigger, first containment action, data compatibility, irreversible effects, reconciliation, verification, owner, and rehearsal date.

## Why this answer is strong

It protects evidence integrity, separates hard gates from improvement conditions, and connects the decision to reversible rollout and recovery.
