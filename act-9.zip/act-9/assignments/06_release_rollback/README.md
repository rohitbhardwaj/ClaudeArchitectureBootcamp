# Assignment 6 — Design Release and Rollback Gates

## Task

Define repository, CI/CD, production, rollback, and reconciliation gates.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
