# Assignment 10 — Final Certification Scenario

## Task

Leadership wants to scale Claude Code to all product engineering teams. Make and defend the final decision.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
