# Start Here — Act 9

## Recommended sequence

1. Read the Evidence Pack
2. Define Production Readiness Dimensions
3. Build the Readiness Scorecard
4. Identify Hard Blockers
5. Design Rollout Waves
6. Design Release and Rollback Gates
7. Run an Incident and Recovery Drill
8. Build the Executive Architecture Defense
9. Try the Defense in Claude Code
10. Final Certification Scenario

Each assignment folder contains:

- `README.md`
- `participant_worksheet.md`
- `model_answer.md`
- `facilitator_guide.md`

Attempt the assignment before reading its model answer.
