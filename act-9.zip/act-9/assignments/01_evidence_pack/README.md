# Assignment 1 — Read the Evidence Pack

## Task

Review all current-state evidence. Separate verified facts, assumptions, missing evidence, stale evidence, and outcome metrics.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
