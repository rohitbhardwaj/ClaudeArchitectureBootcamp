# Worksheet — Read the Evidence Pack

## Decision question

## Verified evidence

| Evidence | Source | Date | Owner | Confidence |
|---|---|---|---|---|
| | | | | |

## Missing evidence

## Hard blockers

## Conditions

## Business outcomes

## Rollout and rollback

## Named owners

## Decision

## Defense
