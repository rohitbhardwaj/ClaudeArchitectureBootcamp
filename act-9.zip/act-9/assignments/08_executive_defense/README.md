# Assignment 8 — Build the Executive Architecture Defense

## Task

Prepare a five-minute decision defense for executives and an architecture council.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
