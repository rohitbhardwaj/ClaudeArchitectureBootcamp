# Assignment 5 — Design Rollout Waves

## Task

Create a phased rollout from lab to low-risk, customer-facing, and high-impact repositories.

## Deliverables

- completed worksheet;
- evidence table;
- decision and rationale;
- rollout or recovery artifact;
- two-minute architecture defense.

Attempt the assignment before reading `model_answer.md`.
