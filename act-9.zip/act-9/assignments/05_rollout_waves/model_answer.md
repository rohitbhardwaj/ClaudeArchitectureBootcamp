# Model Answer — Design Rollout Waves

Wave 0 uses sandbox and training repositories. Wave 1 uses internal or read-only systems. Wave 2 uses customer-facing systems with complete evals, traces, and rollback. Wave 3 includes payments, identity, and regulated systems only after enterprise gates and incident drills pass. Every wave needs entry criteria, exit criteria, stop authority, rollback trigger, owner, and observation period.

## Why this answer is strong

It protects evidence integrity, separates hard gates from improvement conditions, and connects the decision to reversible rollout and recovery.
