# Enterprise Release Gates

## Repository
- CLAUDE.md present and current
- CODEOWNERS complete
- PR template contains AI disclosure
- architecture rules encoded

## CI/CD
- unit, integration, and contract tests
- dependency and license scans
- secrets and PII logging scans
- API compatibility checks
- eval regression gate
- rollback evidence check

## Production
- trace coverage
- SLOs and cost budgets
- canary and wave controls
- feature flag or kill switch
- rollback rehearsal
- incident owner and runbook
