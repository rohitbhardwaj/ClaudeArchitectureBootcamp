# Incident Drill

## Scenario
## Detection signals
## Stop authority
## Containment
## Communication
## Rollback or compensation
## Evidence preservation
## Recovery verification
## Lessons encoded into repository and CI
