# Rollback Evidence

## Change
## Production impact
## Trigger
## First containment action
## Rollback command or procedure
## Data compatibility
## Irreversible side effects
## Reconciliation
## Verification
## Owner
## Rehearsal date
