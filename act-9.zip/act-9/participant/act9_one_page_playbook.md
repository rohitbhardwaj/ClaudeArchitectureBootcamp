# Act 9 One-Page Playbook

## Decide from evidence

Evidence → Score → Hard blockers → Conditions → Rollout waves → Rollback → Incident readiness → Decision

## Decision options

Go  
Conditional Go  
No-Go

## Never trade away

Ownership · Security · CI gates · Rollback · Evidence · Stop authority

> Production readiness is a decision you must be able to explain, reverse, and defend.
