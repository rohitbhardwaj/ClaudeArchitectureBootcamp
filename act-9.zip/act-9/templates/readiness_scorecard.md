# Production Readiness Scorecard

| Dimension | Evidence | Target | Actual | Weight | Hard gate | Owner | Status |
|---|---|---:|---:|---:|---|---|---|
| Repository control | | | | | | | |
| Review and ownership | | | | | | | |
| CI/CD gates | | | | | | | |
| Security and privacy | | | | | | | |
| Evals and quality | | | | | | | |
| Observability | | | | | | | |
| Rollback and recovery | | | | | | | |
| Training and adoption | | | | | | | |
| Governance | | | | | | | |
| Business outcomes | | | | | | | |
