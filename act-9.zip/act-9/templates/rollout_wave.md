# Rollout Wave

## Name
## Repository types
## Entry criteria
## Exit criteria
## Observation period
## Stop authority
## Rollback trigger
## First containment action
## Owner
## Evidence required
