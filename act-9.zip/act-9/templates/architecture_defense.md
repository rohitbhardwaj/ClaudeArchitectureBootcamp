# Architecture Defense

## Decision
## Why now
## Evidence
## Hard blockers
## Conditions
## Business value
## Rollout waves
## Rollback and incident readiness
## Named owners
## Next review date
