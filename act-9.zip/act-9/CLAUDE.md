# CLAUDE.md — Act 9 Production Delivery and Architecture Defense

## Purpose

This repository teaches evidence-based production-readiness decisions.

## Hard rules

1. Never change readiness thresholds merely to obtain a preferred decision.
2. Never remove a hard blocker without verified evidence.
3. Never treat business velocity as a substitute for safety, rollback, or ownership.
4. Never approve enterprise rollout without named owners and recovery evidence.
5. Always distinguish observed evidence, assumptions, and recommendations.
6. Always run the full Act 9 test suite after Java or policy changes.
7. Ask before editing readiness policy, evidence, rollout gates, or model answers.

## Repository map

- `act-9-java-readiness/`: Java decision engine
- `evidence/`: current state, policy, gates, rollback, and incident templates
- `assignments/`: certification-style exercises and model answers
- `.claude/skills/act9-defense/`: architecture-defense workflow
- `.claude/hooks/`: policy and evidence protection
- `.github/`: governance and CI examples

## Required workflow

1. Read the assignment and evidence.
2. State the decision criteria.
3. Separate hard blockers from conditions.
4. Produce a plan before editing.
5. Preserve evidence integrity.
6. Run tests.
7. Defend the decision with rollout and rollback.

## Commands

```bash
cd act-9-java-readiness
./scripts/test.sh
./scripts/demo.sh
```
