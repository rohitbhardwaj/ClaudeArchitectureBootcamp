# Model Answer — Add Approval and Idempotency

Approval must bind approver, user, tool, normalized arguments, amount, tenant, run, expiry, and policy version. Idempotency keys must be unique to the business action and persisted with the final result. On timeout, retrieve the prior result before retrying. The lab token is intentionally simple and must not be used in production.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
