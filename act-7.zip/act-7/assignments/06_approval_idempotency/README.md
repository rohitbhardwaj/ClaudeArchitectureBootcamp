# Assignment 6 — Add Approval and Idempotency

## Task

Design approval and duplicate-call prevention for update_case_status and issue_refund.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
