# Model Answer — Design a Safe Tool Contract

Keep a narrow action name. Use a closed schema with orderId, amount, currency, reasonCode, and approval reference. Reject additional fields. Bound amount and currency. Bind approval to user, run, arguments, and expiry. Require idempotency. Return refund ID, status, amount, policy version, and audit event ID. Never accept free-form instructions that can override policy.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
