# Assignment 3 — Design a Safe Tool Contract

## Task

Review `issue_refund`. Improve its name, description, schema, errors, identity, approval, idempotency, audit, and output.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
