# Facilitator Guide — Design a Safe Tool Contract

## Watch for

- MCP treated as automatic security;
- broad service credentials;
- read and write tools mixed together;
- approvals represented only in prompts;
- no idempotency;
- open-ended schemas;
- retrieved text treated as authority;
- sensitive data in traces.

## Debrief

1. Who is the caller?
2. What is the tool allowed to do?
3. Which control is outside the model?
4. How is a duplicate prevented?
5. What evidence proves the action?
