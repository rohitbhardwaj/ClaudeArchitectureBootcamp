# Worksheet — Final MCP Production Readiness Defense

## Tool or resource decision

## Risk classification

## Identity and authorization

## Contract

| Field or control | Design | Failure prevented |
|---|---|---|
| | | |

## Approval and idempotency

## Audit evidence

## Claude Code command or prompt

## Final recommendation
