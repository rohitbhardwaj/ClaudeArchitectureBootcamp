# Assignment 10 — Final MCP Production Readiness Defense

## Task

Make a Go, Conditional Go, or No-Go decision for enterprise deployment.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
