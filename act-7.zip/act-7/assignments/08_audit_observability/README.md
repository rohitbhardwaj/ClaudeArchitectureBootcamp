# Assignment 8 — Audit and Observability

## Task

Design the event trail for tool discovery and execution.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
