# Model Answer — Audit and Observability

Record connection identity, server version, tool-list version, tool selected, normalized argument hash, authorization decision, approval ID, idempotency key hash, start/end time, outcome, downstream reference, error class, and trace ID. Redact sensitive values. Link the MCP event to the Claude run and business outcome.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
