# Model Answer — Tool or Resource?

Customer profile and policy document are naturally resources when read as addressable context. Search operations are tools. Drafting, status update, and refund issuance are tools because they perform computation or action. A system may expose both a policy resource and a search tool, but their contracts and permissions should remain distinct.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
