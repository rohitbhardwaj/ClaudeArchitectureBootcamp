# Assignment 1 — Tool or Resource?

## Task

Classify customer profile, refund policy, case-note drafting, case-status update, refund issuance, and policy document URI as MCP tools, resources, or both.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
