# Model Answer — Tool Risk Classification

get_customer and search_refund_policy are read-only: require tenant authorization and audit. draft_case_note is draft-only: validate output and prevent persistence. update_case_status is reversible write: require approval, idempotency, previous-state evidence, and rollback. issue_refund is irreversible financial write: require named approval, amount limits, idempotency, audit, and reconciliation.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
