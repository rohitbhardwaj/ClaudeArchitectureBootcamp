# Assignment 2 — Tool Risk Classification

## Task

Classify every server tool as read-only, draft, reversible write, or irreversible write. Define the minimum control for each.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
