# Model Answer — Defend Against Prompt Injection

Treat the case text as untrusted data. It cannot modify system policy, tool availability, approval rules, or identity. The model may summarize it, but the dispatcher independently validates authorization, schema, approval, limits, and idempotency. Record the attempted override as a security signal.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
