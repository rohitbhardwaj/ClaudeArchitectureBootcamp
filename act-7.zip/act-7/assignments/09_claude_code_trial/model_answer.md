# Model Answer — Connect the Server to Claude Code

Build with Maven, copy `.mcp.json.example`, use an absolute JAR path, start Claude Code, inspect `/mcp`, and approve the project server. First call get_customer. For a write tool, display exact arguments, approval token, and idempotency key, then wait for explicit approval. Follow `claude-code/SETUP.md`.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
