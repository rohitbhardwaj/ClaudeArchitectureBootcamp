# Assignment 9 — Connect the Server to Claude Code

## Task

Build the server, configure `.mcp.json`, list tools, call a read tool, and prepare—but do not execute—a write tool.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
