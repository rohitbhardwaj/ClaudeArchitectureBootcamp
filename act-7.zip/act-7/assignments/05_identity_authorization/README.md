# Assignment 5 — Add Identity and Authorization

## Task

Define how user, tenant, service, tool, resource, and downstream identities should be represented and enforced.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
