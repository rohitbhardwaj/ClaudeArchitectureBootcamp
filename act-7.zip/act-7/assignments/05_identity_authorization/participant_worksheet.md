# Worksheet — Add Identity and Authorization

## Tool or resource decision

## Risk classification

## Identity and authorization

## Contract

| Field or control | Design | Failure prevented |
|---|---|---|
| | | |

## Approval and idempotency

## Audit evidence

## Claude Code command or prompt

## Final recommendation
