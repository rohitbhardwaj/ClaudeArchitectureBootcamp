# Model Answer — Add Identity and Authorization

Authenticate the MCP client connection. Propagate or exchange user identity. Authorize before retrieving data and before tool execution. Enforce tenant filters at the data layer. Use narrow service identity only when delegation is impossible. Record user, tenant, tool, arguments hash, policy decision, and downstream identity in audit.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
