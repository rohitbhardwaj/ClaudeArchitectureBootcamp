# Assignment 4 — Separate Read and Write Authority

## Task

Redesign the server so read discovery cannot silently escalate into write authority.

## Deliverables

- completed worksheet;
- code or architecture artifact;
- risk/control table;
- Claude Code trial prompt where relevant;
- two-minute defense.

Attempt the assignment before reading `model_answer.md`.
