# Model Answer — Separate Read and Write Authority

Use separate tool groups or servers for read, draft, reversible write, and irreversible write. Give the model only the tools required for the current workflow stage. Prefer user-scoped identity. Do not expose issue_refund during investigation. Add an explicit handoff before write tools become available.

## Why this is strong

It treats MCP as a controlled enterprise boundary rather than as a convenient tool adapter.
