# Start Here — Act 7

1. Tool or Resource?
2. Tool Risk Classification
3. Design a Safe Tool Contract
4. Separate Read and Write Authority
5. Add Identity and Authorization
6. Add Approval and Idempotency
7. Defend Against Prompt Injection
8. Audit and Observability
9. Connect the Server to Claude Code
10. Final MCP Production Readiness Defense

Every assignment includes a `model_answer.md`.
