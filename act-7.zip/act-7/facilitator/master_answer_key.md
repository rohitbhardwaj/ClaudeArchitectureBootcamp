# Master Answer Key

## Core architecture

Client → MCP protocol → identity → authorization → validation → approval → idempotency → tool → audit → outcome.

## Strong controls

- closed schemas;
- least privilege;
- user and tenant authorization;
- read/write separation;
- approval bound to exact action;
- persistent idempotency;
- timeouts and rate limits;
- audit and trace correlation;
- reconciliation for irreversible actions;
- tool and schema versioning;
- kill switch.

## Common weak answers

- “MCP handles security.”
- “The prompt requires approval.”
- “Use one admin service account.”
- “Retry the refund on timeout.”
- “Expose all tools and let Claude choose.”
