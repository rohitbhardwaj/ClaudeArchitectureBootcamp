# Act 7 One-Page Playbook

## MCP is a boundary

Discover → Select → Authorize → Validate → Approve → Execute → Audit

## Tool classes

Read-only · Draft · Reversible write · Irreversible write

## Required controls

Identity · Tenant scope · Closed schema · Least privilege · Approval · Idempotency · Trace · Reconciliation

> Standardized access is not the same as safe access.
