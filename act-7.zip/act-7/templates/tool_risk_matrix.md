# Tool Risk Matrix

| Tool | Risk | Side effect | Identity | Approval | Idempotency | Audit | Rollback |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
