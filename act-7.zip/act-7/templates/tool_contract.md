# MCP Tool Contract

## Name
## Purpose
## Risk class
## Caller identity
## Tenant boundary
## Input schema
## Output schema
## Validation
## Authorization
## Approval
## Idempotency
## Timeout
## Error model
## Audit
## Rollback or reconciliation
## Owner
