# MCP Threat Model

| Threat | Entry point | Impact | Prevent | Detect | Respond |
|---|---|---|---|---|---|
| Prompt injection | | | | | |
| Cross-tenant access | | | | | |
| Tool argument abuse | | | | | |
| Approval spoofing | | | | | |
| Duplicate write | | | | | |
| Excessive authority | | | | | |
| Trace leakage | | | | | |
