package com.example.mcp;

public class ApprovalVerifier {
    public boolean verify(String token, String toolName, String userId) {
        if (token == null || token.isBlank()) return false;
        return token.equals("APPROVED:" + toolName + ":" + userId);
    }
}
