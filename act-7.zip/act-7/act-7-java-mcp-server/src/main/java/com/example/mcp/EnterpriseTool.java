package com.example.mcp;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.Map;

public interface EnterpriseTool {
    String name();
    String description();
    ToolRisk risk();
    Map<String,Object> inputSchema();
    ToolResult execute(JsonNode arguments, ToolContext context);
}
