package com.example.mcp;

import com.example.mcp.tools.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

public class ControlledMcpServer {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private final ControlledToolDispatcher dispatcher;

    public ControlledMcpServer() {
        this.dispatcher = new ControlledToolDispatcher(List.of(
            new GetCustomerTool(),
            new SearchPolicyTool(),
            new DraftCaseNoteTool(),
            new UpdateCaseStatusTool(),
            new IssueRefundTool()
        ));
    }

    public static void main(String[] args) throws Exception {
        new ControlledMcpServer().run();
    }

    public void run() throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.isBlank()) continue;
            JsonNode request = MAPPER.readTree(line);
            JsonNode response = handle(request);
            if (response != null) {
                System.out.println(MAPPER.writeValueAsString(response));
                System.out.flush();
            }
        }
    }

    JsonNode handle(JsonNode request) {
        String method = request.path("method").asText("");
        JsonNode id = request.get("id");

        if ("notifications/initialized".equals(method)) {
            return null;
        }

        try {
            return switch (method) {
                case "initialize" -> success(id, Map.of(
                    "protocolVersion", "2025-06-18",
                    "capabilities", Map.of("tools", Map.of("listChanged", false)),
                    "serverInfo", Map.of(
                        "name", "controlled-enterprise-mcp",
                        "version", "1.0.0"
                    )
                ));
                case "ping" -> success(id, Map.of());
                case "tools/list" -> success(id, Map.of(
                    "tools", dispatcher.tools().stream().map(tool -> Map.of(
                        "name", tool.name(),
                        "description", tool.description(),
                        "inputSchema", tool.inputSchema()
                    )).toList()
                ));
                case "tools/call" -> handleToolCall(id, request.path("params"));
                default -> error(id, -32601, "Method not found");
            };
        } catch (Exception ex) {
            return error(id, -32603, "Internal error");
        }
    }

    private JsonNode handleToolCall(JsonNode id, JsonNode params) {
        String name = params.path("name").asText();
        JsonNode arguments = params.path("arguments");
        ToolContext context = new ToolContext(
            text(arguments, "_userId", "workshop-user"),
            text(arguments, "_tenantId", "tenant-a"),
            text(arguments, "_traceId", "trace-local"),
            text(arguments, "_approvalToken", null),
            text(arguments, "_idempotencyKey", null)
        );

        ObjectNode sanitized = arguments.deepCopy();
        sanitized.remove(List.of(
            "_userId","_tenantId","_traceId","_approvalToken","_idempotencyKey"
        ));

        ToolResult result = dispatcher.call(name, sanitized, context);
        Map<String,Object> content = Map.of(
            "type","text",
            "text", toJson(result)
        );

        return success(id, Map.of(
            "content", List.of(content),
            "isError", !result.success()
        ));
    }

    private static String text(JsonNode node, String name, String fallback) {
        String value = node.path(name).asText(null);
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String toJson(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (Exception ex) {
            return "{\"success\":false,\"errorCode\":\"SERIALIZATION_ERROR\"}";
        }
    }

    private static JsonNode success(JsonNode id, Object result) {
        ObjectNode response = MAPPER.createObjectNode();
        response.put("jsonrpc", "2.0");
        if (id != null) response.set("id", id);
        response.set("result", MAPPER.valueToTree(result));
        return response;
    }

    private static JsonNode error(JsonNode id, int code, String message) {
        ObjectNode response = MAPPER.createObjectNode();
        response.put("jsonrpc", "2.0");
        if (id != null) response.set("id", id);
        response.set("error", MAPPER.valueToTree(Map.of(
            "code", code,
            "message", message
        )));
        return response;
    }
}
