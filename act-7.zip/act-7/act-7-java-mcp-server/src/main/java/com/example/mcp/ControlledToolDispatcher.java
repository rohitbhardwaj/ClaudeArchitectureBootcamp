package com.example.mcp;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ControlledToolDispatcher {
    private final Map<String,EnterpriseTool> tools;
    private final AuthorizationPolicy authorization;
    private final ApprovalVerifier approvalVerifier;
    private final IdempotencyStore idempotency;
    private final AuditLogger audit;

    public ControlledToolDispatcher(List<EnterpriseTool> tools) {
        this.tools = tools.stream().collect(Collectors.toMap(EnterpriseTool::name, Function.identity()));
        this.authorization = new AuthorizationPolicy();
        this.approvalVerifier = new ApprovalVerifier();
        this.idempotency = new IdempotencyStore();
        this.audit = new AuditLogger();
    }

    public List<EnterpriseTool> tools() {
        return tools.values().stream().sorted(java.util.Comparator.comparing(EnterpriseTool::name)).toList();
    }

    public ToolResult call(String toolName, JsonNode args, ToolContext context) {
        EnterpriseTool tool = tools.get(toolName);
        if (tool == null) return ToolResult.error("UNKNOWN_TOOL", "Unknown tool");

        if (!authorization.isAllowed(context, tool)) {
            audit.record("DENIED", toolName, context, false, "authorization");
            return ToolResult.error("FORBIDDEN", "Caller is not authorized");
        }

        if (authorization.requiresApproval(tool)
            && !approvalVerifier.verify(context.approvalToken(), toolName, context.userId())) {
            audit.record("DENIED", toolName, context, false, "approval");
            return ToolResult.error("APPROVAL_REQUIRED", "Valid approval token required");
        }

        if (tool.risk() == ToolRisk.REVERSIBLE_WRITE
            || tool.risk() == ToolRisk.IRREVERSIBLE_WRITE) {
            if (context.idempotencyKey() == null || context.idempotencyKey().isBlank()) {
                return ToolResult.error("IDEMPOTENCY_REQUIRED", "Idempotency key required");
            }
            ToolResult previous = idempotency.get(context.idempotencyKey());
            if (previous != null) {
                audit.record("REPLAY", toolName, context, previous.success(), "idempotent replay");
                return previous;
            }
        }

        try {
            ToolResult result = tool.execute(args, context);
            if ((tool.risk() == ToolRisk.REVERSIBLE_WRITE
                || tool.risk() == ToolRisk.IRREVERSIBLE_WRITE)
                && result.success()) {
                idempotency.put(context.idempotencyKey(), result);
            }
            audit.record("CALLED", toolName, context, result.success(), result.errorCode());
            return result;
        } catch (IllegalArgumentException ex) {
            audit.record("INVALID_ARGUMENTS", toolName, context, false, ex.getMessage());
            return ToolResult.error("INVALID_ARGUMENTS", ex.getMessage());
        }
    }
}
