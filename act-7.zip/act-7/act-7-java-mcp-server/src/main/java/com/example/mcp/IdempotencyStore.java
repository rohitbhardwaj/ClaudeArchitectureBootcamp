package com.example.mcp;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class IdempotencyStore {
    private final Map<String, ToolResult> results = new ConcurrentHashMap<>();

    public ToolResult get(String key) {
        return results.get(key);
    }

    public void put(String key, ToolResult result) {
        results.putIfAbsent(key, result);
    }
}
