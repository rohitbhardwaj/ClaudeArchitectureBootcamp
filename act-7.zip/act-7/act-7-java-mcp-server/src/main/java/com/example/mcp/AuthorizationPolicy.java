package com.example.mcp;

import java.util.Set;

public class AuthorizationPolicy {

    public boolean isAllowed(ToolContext context, EnterpriseTool tool) {
        if (context.userId() == null || context.userId().isBlank()) return false;
        if (context.tenantId() == null || context.tenantId().isBlank()) return false;

        Set<String> allowedTenants = Set.of("tenant-a", "tenant-b");
        if (!allowedTenants.contains(context.tenantId())) return false;

        return true;
    }

    public boolean requiresApproval(EnterpriseTool tool) {
        return tool.risk() == ToolRisk.IRREVERSIBLE_WRITE
            || tool.risk() == ToolRisk.REVERSIBLE_WRITE;
    }
}
