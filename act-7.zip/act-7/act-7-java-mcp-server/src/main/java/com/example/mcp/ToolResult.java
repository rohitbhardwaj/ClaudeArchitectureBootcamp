package com.example.mcp;

import java.util.Map;

public record ToolResult(
    boolean success,
    String message,
    Map<String,Object> data,
    String errorCode
) {
    public static ToolResult ok(String message, Map<String,Object> data) {
        return new ToolResult(true, message, data, null);
    }

    public static ToolResult error(String code, String message) {
        return new ToolResult(false, message, Map.of(), code);
    }
}
