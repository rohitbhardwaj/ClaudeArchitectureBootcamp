package com.example.mcp;

public record ToolContext(
    String userId,
    String tenantId,
    String traceId,
    String approvalToken,
    String idempotencyKey
) {}
