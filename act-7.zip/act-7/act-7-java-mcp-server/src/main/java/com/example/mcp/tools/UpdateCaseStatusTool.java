package com.example.mcp.tools;

import com.example.mcp.*;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Map;
import java.util.Set;

public class UpdateCaseStatusTool implements EnterpriseTool {
    public String name() { return "update_case_status"; }
    public String description() { return "Update a case status. Reversible but approval-gated."; }
    public ToolRisk risk() { return ToolRisk.REVERSIBLE_WRITE; }

    public Map<String,Object> inputSchema() {
        return Map.of(
            "type","object",
            "additionalProperties",false,
            "required",java.util.List.of("caseId","status"),
            "properties",Map.of(
                "caseId",Map.of("type","string","maxLength",50),
                "status",Map.of("type","string","enum",java.util.List.of("OPEN","PENDING","RESOLVED"))
            )
        );
    }

    public ToolResult execute(JsonNode args, ToolContext context) {
        String caseId = ArgumentValidator.requiredText(args, "caseId", 50);
        String status = ArgumentValidator.allowedEnum(
            args, "status", Set.of("OPEN","PENDING","RESOLVED")
        );
        return ToolResult.ok("Case updated", Map.of(
            "caseId",caseId,
            "status",status,
            "previousStatus","OPEN"
        ));
    }
}
