package com.example.mcp;

public enum ToolRisk {
    READ_ONLY,
    DRAFT,
    REVERSIBLE_WRITE,
    IRREVERSIBLE_WRITE
}
