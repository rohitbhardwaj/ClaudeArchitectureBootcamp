package com.example.mcp;

import java.time.Instant;

public class AuditLogger {
    public void record(String event, String tool, ToolContext context, boolean success, String detail) {
        System.err.printf(
            "%s event=%s tool=%s user=%s tenant=%s trace=%s success=%s detail=%s%n",
            Instant.now(),
            event,
            tool,
            context.userId(),
            context.tenantId(),
            context.traceId(),
            success,
            detail == null ? "" : detail.replaceAll("[\r\n]", " ")
        );
    }
}
