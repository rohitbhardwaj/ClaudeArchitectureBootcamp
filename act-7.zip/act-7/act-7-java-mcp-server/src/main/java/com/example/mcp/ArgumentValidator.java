package com.example.mcp;

import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.util.Set;

public final class ArgumentValidator {
    private ArgumentValidator() {}

    public static String requiredText(JsonNode args, String field, int maxLength) {
        String value = args.path(field).asText(null);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(field + " is required");
        }
        if (value.length() > maxLength) {
            throw new IllegalArgumentException(field + " exceeds max length");
        }
        return value;
    }

    public static BigDecimal requiredAmount(JsonNode args, String field,
                                            BigDecimal minimum, BigDecimal maximum) {
        if (!args.has(field) || !args.get(field).isNumber()) {
            throw new IllegalArgumentException(field + " must be numeric");
        }
        BigDecimal value = args.get(field).decimalValue();
        if (value.compareTo(minimum) < 0 || value.compareTo(maximum) > 0) {
            throw new IllegalArgumentException(field + " outside allowed range");
        }
        return value;
    }

    public static String allowedEnum(JsonNode args, String field, Set<String> allowed) {
        String value = requiredText(args, field, 100);
        if (!allowed.contains(value)) {
            throw new IllegalArgumentException(field + " has unsupported value");
        }
        return value;
    }
}
