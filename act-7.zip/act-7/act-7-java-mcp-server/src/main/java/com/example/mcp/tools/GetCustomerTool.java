package com.example.mcp.tools;

import com.example.mcp.*;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Map;

public class GetCustomerTool implements EnterpriseTool {
    public String name() { return "get_customer"; }
    public String description() { return "Read a customer profile within the caller tenant."; }
    public ToolRisk risk() { return ToolRisk.READ_ONLY; }

    public Map<String,Object> inputSchema() {
        return Map.of(
            "type","object",
            "additionalProperties",false,
            "required",java.util.List.of("customerId"),
            "properties",Map.of(
                "customerId",Map.of("type","string","maxLength",50)
            )
        );
    }

    public ToolResult execute(JsonNode args, ToolContext context) {
        String customerId = ArgumentValidator.requiredText(args, "customerId", 50);
        return ToolResult.ok("Customer found", Map.of(
            "customerId",customerId,
            "tenantId",context.tenantId(),
            "segment","STANDARD",
            "region","US"
        ));
    }
}
