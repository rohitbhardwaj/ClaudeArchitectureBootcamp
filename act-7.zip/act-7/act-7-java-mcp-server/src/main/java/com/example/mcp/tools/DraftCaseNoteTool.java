package com.example.mcp.tools;

import com.example.mcp.*;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Map;

public class DraftCaseNoteTool implements EnterpriseTool {
    public String name() { return "draft_case_note"; }
    public String description() { return "Create a non-persistent draft note for human review."; }
    public ToolRisk risk() { return ToolRisk.DRAFT; }

    public Map<String,Object> inputSchema() {
        return Map.of(
            "type","object",
            "additionalProperties",false,
            "required",java.util.List.of("caseId","summary"),
            "properties",Map.of(
                "caseId",Map.of("type","string","maxLength",50),
                "summary",Map.of("type","string","maxLength",500)
            )
        );
    }

    public ToolResult execute(JsonNode args, ToolContext context) {
        String caseId = ArgumentValidator.requiredText(args, "caseId", 50);
        String summary = ArgumentValidator.requiredText(args, "summary", 500);
        return ToolResult.ok("Draft created", Map.of(
            "caseId",caseId,
            "draft",summary,
            "persisted",false
        ));
    }
}
