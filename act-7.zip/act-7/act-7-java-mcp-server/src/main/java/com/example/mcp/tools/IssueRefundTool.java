package com.example.mcp.tools;

import com.example.mcp.*;
import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.util.Map;

public class IssueRefundTool implements EnterpriseTool {
    public String name() { return "issue_refund"; }
    public String description() { return "Issue a financial refund. Irreversible and approval-gated."; }
    public ToolRisk risk() { return ToolRisk.IRREVERSIBLE_WRITE; }

    public Map<String,Object> inputSchema() {
        return Map.of(
            "type","object",
            "additionalProperties",false,
            "required",java.util.List.of("orderId","amount","currency"),
            "properties",Map.of(
                "orderId",Map.of("type","string","maxLength",50),
                "amount",Map.of("type","number","minimum",0.01,"maximum",500.00),
                "currency",Map.of("type","string","enum",java.util.List.of("USD"))
            )
        );
    }

    public ToolResult execute(JsonNode args, ToolContext context) {
        String orderId = ArgumentValidator.requiredText(args, "orderId", 50);
        BigDecimal amount = ArgumentValidator.requiredAmount(
            args, "amount", new BigDecimal("0.01"), new BigDecimal("500.00")
        );
        String currency = ArgumentValidator.allowedEnum(
            args, "currency", java.util.Set.of("USD")
        );
        return ToolResult.ok("Refund issued", Map.of(
            "refundId","refund-" + Math.abs((orderId + amount).hashCode()),
            "orderId",orderId,
            "amount",amount,
            "currency",currency,
            "status","ISSUED"
        ));
    }
}
