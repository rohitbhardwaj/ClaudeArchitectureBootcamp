package com.example.mcp;

import com.example.mcp.tools.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ControlledToolDispatcherTest {
    private final ObjectMapper mapper = new ObjectMapper();

    private ControlledToolDispatcher dispatcher() {
        return new ControlledToolDispatcher(List.of(
            new GetCustomerTool(),
            new SearchPolicyTool(),
            new DraftCaseNoteTool(),
            new UpdateCaseStatusTool(),
            new IssueRefundTool()
        ));
    }

    @Test
    void readToolDoesNotRequireApproval() throws Exception {
        var result = dispatcher().call(
            "get_customer",
            mapper.readTree("{\"customerId\":\"cust-1\"}"),
            new ToolContext("user-1","tenant-a","trace-1",null,null)
        );
        assertTrue(result.success());
    }

    @Test
    void irreversibleWriteRequiresApproval() throws Exception {
        var result = dispatcher().call(
            "issue_refund",
            mapper.readTree("{\"orderId\":\"order-1\",\"amount\":25,\"currency\":\"USD\"}"),
            new ToolContext("user-1","tenant-a","trace-1",null,"idem-1")
        );
        assertFalse(result.success());
        assertEquals("APPROVAL_REQUIRED", result.errorCode());
    }

    @Test
    void writeRequiresIdempotency() throws Exception {
        var result = dispatcher().call(
            "issue_refund",
            mapper.readTree("{\"orderId\":\"order-1\",\"amount\":25,\"currency\":\"USD\"}"),
            new ToolContext(
                "user-1","tenant-a","trace-1",
                "APPROVED:issue_refund:user-1",null
            )
        );
        assertEquals("IDEMPOTENCY_REQUIRED", result.errorCode());
    }

    @Test
    void approvedWriteIsIdempotent() throws Exception {
        var dispatcher = dispatcher();
        var args = mapper.readTree("{\"orderId\":\"order-1\",\"amount\":25,\"currency\":\"USD\"}");
        var context = new ToolContext(
            "user-1","tenant-a","trace-1",
            "APPROVED:issue_refund:user-1","idem-1"
        );
        var first = dispatcher.call("issue_refund", args, context);
        var second = dispatcher.call("issue_refund", args, context);
        assertTrue(first.success());
        assertEquals(first.data(), second.data());
    }

    @Test
    void rejectsCrossTenantCaller() throws Exception {
        var result = dispatcher().call(
            "get_customer",
            mapper.readTree("{\"customerId\":\"cust-1\"}"),
            new ToolContext("user-1","tenant-x","trace-1",null,null)
        );
        assertEquals("FORBIDDEN", result.errorCode());
    }
}
