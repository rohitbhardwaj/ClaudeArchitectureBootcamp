# Controlled Enterprise MCP Server

This Java program implements a compact MCP STDIO server for workshop use.

Supported requests:

- `initialize`
- `notifications/initialized`
- `ping`
- `tools/list`
- `tools/call`

## Build

```bash
mvn test
mvn package
```

## Run

```bash
java -jar target/controlled-enterprise-mcp-1.0.0.jar
```

## Manual protocol test

```bash
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"test","version":"1"}}}' '{"jsonrpc":"2.0","method":"notifications/initialized"}' '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}' | java -jar target/controlled-enterprise-mcp-1.0.0.jar
```

The server writes protocol messages to stdout and audit events to stderr.
