# Try Act 7 with Claude Code

## 1. Build the server

From the repository root:

```bash
cd act-7-java-mcp-server
mvn test
mvn package
cd ..
```

## 2. Add the project MCP server

The package includes `.mcp.json.example`. Copy it to `.mcp.json` and replace the absolute path:

```bash
cp claude-code/.mcp.json.example .mcp.json
```

Edit the `args` value so it points to:

```text
<ABSOLUTE_REPO_PATH>/act-7-java-mcp-server/target/controlled-enterprise-mcp-1.0.0.jar
```

Project-scoped MCP servers may require approval when Claude Code first loads them.

## 3. Start Claude Code

```bash
claude
```

Useful checks inside Claude Code:

```text
/mcp
```

Ask Claude:

```text
List the MCP tools available from controlled-enterprise-mcp.
Do not call any write tool.
```

## 4. Start in plan mode for assignments

```bash
claude --permission-mode plan
```

## 5. Suggested assignment prompts

### Read-only discovery

```text
Read CLAUDE.md and assignments/01_tool_or_resource/README.md.
Inspect the Java MCP server.
Produce the assignment deliverable without changing files.
You may use only read-only MCP tools.
```

### Tool contract review

```text
Analyze the issue_refund tool contract.
Do not call it.
Identify missing identity, authorization, approval, idempotency,
validation, audit, timeout, and error controls.
Write your answer to assignments/03_safe_tool_contract/submission.md.
```

### Safe read call

```text
Use get_customer for customerId cust-1.
Use tenant-a and trace assignment-5.
Explain the request, result, and audit evidence.
```

### Approval-gated write simulation

```text
Plan a call to update_case_status for CASE-100.
Do not execute until I approve the exact tool arguments.
Use userId workshop-user, tenantId tenant-a,
traceId assignment-6, and idempotencyKey case-100-pending-v1.
```

### Refund simulation

```text
Prepare, but do not execute, issue_refund for order-1, USD 25.
Show the required approval token and idempotency key.
Explain why the tool must not run without both.
```

## 6. Recommended Claude Code safety flags

Use explicit allowed/disallowed tools for non-interactive exercises. Example:

```bash
claude -p --max-turns 4   --permission-mode plan   --allowedTools "Read" "Glob" "Grep"   --disallowedTools "Bash(rm:*)" "Bash(git push:*)"   "Review Assignment 2 and produce a plan only."
```

Do not use `--dangerously-skip-permissions` for this workshop.
