# Claude Production Architecture Workshop — Act 7

## MCP and Controlled Enterprise Agency

This GitHub-ready package contains:

- a working Java STDIO MCP server implementing the core `initialize`, `tools/list`, and `tools/call` flow;
- read-only, draft, reversible-write, and irreversible-write tools;
- identity, argument validation, approval, idempotency, and audit controls;
- Claude Code project configuration examples;
- a `CLAUDE.md` designed for the assignments;
- ten assignments with participant worksheets, facilitator guides, and model answers inside each assignment folder;
- Act 7 slides.

Core lesson:

> MCP standardizes tool access. It does not automatically make tool access safe.

## Quick start

```bash
cd act-7-java-mcp-server
mvn test
mvn package
java -jar target/controlled-enterprise-mcp-1.0.0.jar
```

For Claude Code setup, read `claude-code/SETUP.md`.
