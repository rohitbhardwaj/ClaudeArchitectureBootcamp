# Failure-Mode Table

| Failure | Detect | Retry? | Fallback | Client response | Audit |
|---|---|---|---|---|---|
| Timeout | | | | | |
| Rate limit | | | | | |
| Invalid JSON | | | | | |
| Missing evidence | | | | | |
| Context failure | | | | | |
| Duplicate request | | | | | |
