# Master Answer Key

Core path:

Experience → Request validation → Context → Model → Schema validation → Business policy → Approval → Action/response → Observability

Core controls:

- schema validation;
- evidence requirement;
- business policy outside the model;
- idempotency;
- traceability;
- one retry owner;
- human approval;
- independent versioning;
- eval and rollback gates.
