# Assignment 3 — Build the Structured Output Contract

## Task
Create a JSON Schema with an enumerated decision, reason codes, evidence IDs, confidence, approval flag, and no additional fields.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
