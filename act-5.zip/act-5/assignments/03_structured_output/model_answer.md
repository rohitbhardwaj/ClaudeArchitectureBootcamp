# Model Answer — Build the Structured Output Contract

Use `contracts/model-decision.schema.json`. The strongest design uses enums, required fields, `additionalProperties: false`, at least one evidence ID, and confidence bounded from 0 to 1.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
