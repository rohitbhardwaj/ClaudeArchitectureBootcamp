# Assignment 6 — Add Idempotency and Traceability

## Task
Explain idempotency key, request ID, trace ID, model-call ID, and audit-event ID.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
