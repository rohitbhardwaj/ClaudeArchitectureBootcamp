# Assignment 2 — Design the Claude Request Path

## Task
Map Experience → Instruction → Context → Claude API → Validation → Policy → Action → Observability. Identify what must exist before and after the model.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
