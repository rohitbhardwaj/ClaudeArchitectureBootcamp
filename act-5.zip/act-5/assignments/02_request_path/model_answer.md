# Model Answer — Design the Claude Request Path

Before: request validation, identity, instructions, trusted context, policy version, tool definitions, output schema. After: schema validation, business validation, approval, audit, response mapping, metrics, and traces. Claude is one component, not the architecture.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
