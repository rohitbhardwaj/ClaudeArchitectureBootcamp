# Worksheet — Design the Claude Request Path

## Architecture choice

## Inputs and outputs

## Risks and controls

| Risk | Impact | Control | Evidence |
|---|---|---|---|
| | | | |

## Failure behavior

## Human approval

## Observability

## Final recommendation
