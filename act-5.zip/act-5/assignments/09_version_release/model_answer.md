# Model Answer — Design Versioning and Release Gates

Version each independently. Gate with contract tests, regression evals, safety evals, latency/cost thresholds, canary, and rollback rehearsal. Rollback may require reverting prompt, model, policy, or index without changing app code.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
