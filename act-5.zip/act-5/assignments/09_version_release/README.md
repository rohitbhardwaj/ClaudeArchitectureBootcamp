# Assignment 9 — Design Versioning and Release Gates

## Task
Version API, schema, prompt, policy, model, and retrieval index. Define release and rollback gates.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
