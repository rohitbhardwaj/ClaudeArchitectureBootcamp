# Worksheet — Review API Security and Data Boundaries

## Architecture choice

## Inputs and outputs

## Risks and controls

| Risk | Impact | Control | Evidence |
|---|---|---|---|
| | | | |

## Failure behavior

## Human approval

## Observability

## Final recommendation
