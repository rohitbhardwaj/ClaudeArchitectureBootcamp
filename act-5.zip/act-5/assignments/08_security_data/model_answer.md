# Model Answer — Review API Security and Data Boundaries

Minimize and classify data, never put secrets in prompts, treat reason text as untrusted data, authorize before retrieval, enforce freshness, redact telemetry, use narrow identity, and keep write authority outside the model.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
