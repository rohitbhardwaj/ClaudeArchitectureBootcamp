# Assignment 8 — Review API Security and Data Boundaries

## Task
Threat-check PII, secrets, prompt injection in reason text, stale policy, cross-tenant context, raw model logging, and broad service identity.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
