# Assignment 7 — Add Human Approval and Safe Fallback

## Task
Classify autonomous, approval-gated, and prohibited outcomes. Design a degradation ladder.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
