# Model Answer — Add Human Approval and Safe Fallback

Autonomous: read, retrieve, recommend low-risk outcomes. Approval-gated: high amount, fraud, low confidence, conflicting evidence. Prohibited: override policy, bypass identity, approve above total, direct refund from model output. Degrade from full recommendation to rules-only, evidence-only, human queue, then refusal.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
