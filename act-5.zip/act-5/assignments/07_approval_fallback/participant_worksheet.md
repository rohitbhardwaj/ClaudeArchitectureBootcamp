# Worksheet — Add Human Approval and Safe Fallback

## Architecture choice

## Inputs and outputs

## Risks and controls

| Risk | Impact | Control | Evidence |
|---|---|---|---|
| | | | |

## Failure behavior

## Human approval

## Observability

## Final recommendation
