# Facilitator Guide — Add Human Approval and Safe Fallback

Watch for:
- natural language treated as a contract;
- prompt-only policy;
- indefinite retries;
- missing evidence;
- confusion between tracing and idempotency;
- direct model-to-business-action paths;
- missing rollback.

Debrief:
1. What stays outside the model?
2. What must stop the workflow?
3. What evidence is mandatory?
4. What requires human approval?
