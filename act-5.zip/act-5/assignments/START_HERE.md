# Start Here — Act 5

1. Choose the Interaction Pattern
2. Design the Claude Request Path
3. Build the Structured Output Contract
4. Validate Model Output
5. Design Failure and Retry Behavior
6. Add Idempotency and Traceability
7. Add Human Approval and Fallback
8. Review Security and Data Boundaries
9. Design Versioning and Release Gates
10. Final Production Readiness Defense

Each assignment includes `model_answer.md`.
