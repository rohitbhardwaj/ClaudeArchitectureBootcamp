# Assignment 1 — Choose the Correct Interaction Pattern

## Task
Choose synchronous, streaming, asynchronous, batch, or tool-driven design for: short classification, long explanation, 300-page contract, 20,000 nightly documents, and policy retrieval plus refund action.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
