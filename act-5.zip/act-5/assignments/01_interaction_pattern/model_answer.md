# Model Answer — Choose the Correct Interaction Pattern

Short classification → synchronous. Long explanation → streaming. Large contract → asynchronous job. Nightly documents → batch. Policy plus refund action → tool-driven workflow, possibly agent-assisted. Do not use an agent where deterministic orchestration is sufficient.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
