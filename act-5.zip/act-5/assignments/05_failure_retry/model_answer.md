# Model Answer — Design Failure and Retry Behavior

Timeout → bounded retry or safe fallback. Rate limit → backoff with one retry owner. Invalid output → validate, optionally repair once, then fail safely. Context failure → stop. Duplicate retry → idempotency lookup. Partial failure → checkpoint, compensate, or escalate.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
