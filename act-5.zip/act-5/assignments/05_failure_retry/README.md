# Assignment 5 — Design Failure and Retry Behavior

## Task
Define handling for timeout, rate limit, invalid output, context failure, duplicate client retry, and partial downstream failure.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
