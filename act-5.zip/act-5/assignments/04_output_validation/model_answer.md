# Model Answer — Validate Model Output Before Business Use

Invalid JSON, unknown decision, out-of-range confidence, and missing evidence fail validation. Fraud hold is overridden to RECOMMEND_REVIEW. Amount above total is overridden to DENY. Schema and business validation are separate gates.

## Why this is strong

It separates model capability from application authority and requires explicit contracts, controls, and evidence.
