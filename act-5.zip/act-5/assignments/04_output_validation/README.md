# Assignment 4 — Validate Model Output Before Business Use

## Task
Decide what happens for invalid JSON, unknown decision, confidence 1.4, no evidence, APPROVE on fraud hold, and APPROVE above order total.

## Deliverables
- completed worksheet;
- architecture decision;
- risks and controls;
- evidence;
- two-minute defense.

Read `model_answer.md` only after attempting the assignment.
