# Claude Production Architecture Workshop — Act 5

## Claude APIs and Structured Application Contracts

This package contains a working Java/Spring Boot example, OpenAPI 3.1, JSON Schema, failure simulations, assignments, and a model answer inside every assignment folder.

Core lesson:

> Do not ship model calls. Ship controlled, validated, grounded application behavior.

## Quick start

```bash
cd act-5-java-repo
mvn test
mvn spring-boot:run
```

Then open `assignments/START_HERE.md`.
