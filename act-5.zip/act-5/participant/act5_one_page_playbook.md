# Act 5 One-Page Playbook

## Interaction
Sync · Streaming · Async · Batch · Tool-driven

## Controlled path
Input → Context → Model → Schema → Policy → Approval → Action → Observe

## Reliability
Timeout · One retry owner · Idempotency · Fallback · Safe refusal

> Do not ship model calls. Ship controlled, grounded, evaluated application behavior.
