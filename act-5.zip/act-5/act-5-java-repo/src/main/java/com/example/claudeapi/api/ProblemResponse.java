package com.example.claudeapi.api;

public record ProblemResponse(
    String type,
    String title,
    int status,
    String detail,
    String instance,
    String traceId
) {}
