package com.example.claudeapi.api;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.UUID;

public record RefundRecommendationRequest(
    @NotNull UUID orderId,
    @NotBlank String customerId,
    @NotNull @DecimalMin("0.01") BigDecimal requestedAmount,
    @NotBlank String currency,
    @NotBlank String reason
) {}
