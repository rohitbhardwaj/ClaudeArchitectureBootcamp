package com.example.claudeapi.infrastructure;

import com.example.claudeapi.api.RefundRecommendationRequest;
import com.example.claudeapi.application.ClaudeModelGateway;
import com.example.claudeapi.application.ContextPackage;
import org.springframework.stereotype.Component;

@Component
public class FakeClaudeModelGateway implements ClaudeModelGateway {
    public String recommend(RefundRecommendationRequest request, ContextPackage context) {
        if (request.reason().toLowerCase().contains("invalid-json")) {
            return "{not-valid-json";
        }
        if (request.reason().toLowerCase().contains("missing-evidence")) {
            return "{\"decision\":\"APPROVE\",\"reasonCodes\":[\"WITHIN_POLICY\"],\"evidenceIds\":[],\"confidence\":0.95,\"requiresHumanApproval\":false}";
        }
        return "{\"decision\":\"APPROVE\",\"reasonCodes\":[\"WITHIN_POLICY\"],\"evidenceIds\":[\"refund-policy-2026-07-v4\"],\"confidence\":0.91,\"requiresHumanApproval\":false}";
    }
}
