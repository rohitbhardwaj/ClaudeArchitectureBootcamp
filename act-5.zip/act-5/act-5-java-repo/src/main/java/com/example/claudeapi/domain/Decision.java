package com.example.claudeapi.domain;
public enum Decision { APPROVE, RECOMMEND_REVIEW, DENY }
