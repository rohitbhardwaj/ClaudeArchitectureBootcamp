package com.example.claudeapi.api;

import com.example.claudeapi.application.RefundRecommendationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/refund-recommendations")
public class RefundRecommendationController {
    private final RefundRecommendationService service;

    public RefundRecommendationController(RefundRecommendationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RefundRecommendationResponse> recommend(
        @Valid @RequestBody RefundRecommendationRequest request,
        @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
        @RequestHeader(value = "X-Trace-Id", required = false) String traceId
    ) {
        String requestId = (idempotencyKey == null || idempotencyKey.isBlank())
            ? UUID.randomUUID().toString() : idempotencyKey;
        String resolvedTraceId = (traceId == null || traceId.isBlank())
            ? UUID.randomUUID().toString() : traceId;
        return ResponseEntity.ok(service.recommend(request, requestId, resolvedTraceId));
    }
}
