package com.example.claudeapi.application;
import com.example.claudeapi.domain.ModelDecision;

public interface AuditRecorder {
    void record(String requestId, String traceId, ContextPackage context, ModelDecision decision);
}
