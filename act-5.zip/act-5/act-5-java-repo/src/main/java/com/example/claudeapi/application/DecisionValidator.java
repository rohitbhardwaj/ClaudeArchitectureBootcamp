package com.example.claudeapi.application;
import com.example.claudeapi.domain.ModelDecision;

public interface DecisionValidator {
    ModelDecision validate(String rawJson);
}
