package com.example.claudeapi.infrastructure;

import com.example.claudeapi.api.RefundRecommendationRequest;
import com.example.claudeapi.application.ContextPackage;
import com.example.claudeapi.application.ContextProvider;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.List;

@Component
public class FakeContextProvider implements ContextProvider {
    public ContextPackage load(RefundRecommendationRequest request) {
        return new ContextPackage(
            request.customerId(),
            new BigDecimal("150.00"),
            request.currency(),
            List.of("refund-policy-2026-07-v4"),
            request.reason().toLowerCase().contains("fraud"),
            "2026-07-v4"
        );
    }
}
