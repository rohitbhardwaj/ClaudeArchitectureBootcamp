package com.example.claudeapi.application;
import com.example.claudeapi.api.RefundRecommendationRequest;

public interface ClaudeModelGateway {
    String recommend(RefundRecommendationRequest request, ContextPackage context);
}
