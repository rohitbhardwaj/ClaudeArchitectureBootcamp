package com.example.claudeapi.application;

import com.example.claudeapi.api.RefundRecommendationRequest;
import com.example.claudeapi.api.RefundRecommendationResponse;
import com.example.claudeapi.domain.Decision;
import com.example.claudeapi.domain.ModelDecision;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RefundRecommendationService {
    private final ContextProvider contextProvider;
    private final ClaudeModelGateway modelGateway;
    private final DecisionValidator validator;
    private final AuditRecorder auditRecorder;

    public RefundRecommendationService(ContextProvider contextProvider,
                                       ClaudeModelGateway modelGateway,
                                       DecisionValidator validator,
                                       AuditRecorder auditRecorder) {
        this.contextProvider = contextProvider;
        this.modelGateway = modelGateway;
        this.validator = validator;
        this.auditRecorder = auditRecorder;
    }

    public RefundRecommendationResponse recommend(RefundRecommendationRequest request,
                                                  String requestId,
                                                  String traceId) {
        ContextPackage context = contextProvider.load(request);
        ModelDecision model = validator.validate(modelGateway.recommend(request, context));
        ModelDecision governed = applyPolicy(request, context, model);
        auditRecorder.record(requestId, traceId, context, governed);

        return new RefundRecommendationResponse(
            requestId, traceId, governed.decision().name(),
            governed.reasonCodes(), governed.evidenceIds(),
            governed.confidence(), governed.requiresHumanApproval(), "COMPLETED"
        );
    }

    private ModelDecision applyPolicy(RefundRecommendationRequest request,
                                      ContextPackage context,
                                      ModelDecision model) {
        if (context.fraudHold()) {
            return new ModelDecision(
                Decision.RECOMMEND_REVIEW, List.of("FRAUD_HOLD"),
                model.evidenceIds(), model.confidence(), true
            );
        }
        if (request.requestedAmount().compareTo(context.orderTotal()) > 0) {
            return new ModelDecision(
                Decision.DENY, List.of("AMOUNT_EXCEEDS_ORDER_TOTAL"),
                model.evidenceIds(), model.confidence(), false
            );
        }
        if (model.confidence() < 0.75) {
            return new ModelDecision(
                Decision.RECOMMEND_REVIEW, List.of("LOW_CONFIDENCE"),
                model.evidenceIds(), model.confidence(), true
            );
        }
        return model;
    }
}
