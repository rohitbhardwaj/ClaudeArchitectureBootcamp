package com.example.claudeapi.api;
import java.util.List;

public record RefundRecommendationResponse(
    String requestId,
    String traceId,
    String decision,
    List<String> reasonCodes,
    List<String> evidenceIds,
    double confidence,
    boolean requiresHumanApproval,
    String status
) {}
