package com.example.claudeapi.application;
import com.example.claudeapi.api.RefundRecommendationRequest;

public interface ContextProvider {
    ContextPackage load(RefundRecommendationRequest request);
}
