package com.example.claudeapi.infrastructure;

import com.example.claudeapi.application.AuditRecorder;
import com.example.claudeapi.application.ContextPackage;
import com.example.claudeapi.domain.ModelDecision;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class LoggingAuditRecorder implements AuditRecorder {
    private static final Logger log = LoggerFactory.getLogger(LoggingAuditRecorder.class);

    public void record(String requestId, String traceId, ContextPackage context, ModelDecision decision) {
        log.info("requestId={} traceId={} policyVersion={} evidenceIds={} decision={} confidence={} approval={}",
            requestId, traceId, context.policyVersion(), decision.evidenceIds(),
            decision.decision(), decision.confidence(), decision.requiresHumanApproval());
    }
}
