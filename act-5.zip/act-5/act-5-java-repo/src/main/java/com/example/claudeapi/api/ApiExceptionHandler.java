package com.example.claudeapi.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ProblemResponse> invalid(IllegalArgumentException ex) {
        String traceId = UUID.randomUUID().toString();
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(
            new ProblemResponse(
                "https://example.com/problems/invalid-model-output",
                "Model output failed validation",
                422,
                ex.getMessage(),
                "/api/v1/refund-recommendations",
                traceId
            )
        );
    }
}
