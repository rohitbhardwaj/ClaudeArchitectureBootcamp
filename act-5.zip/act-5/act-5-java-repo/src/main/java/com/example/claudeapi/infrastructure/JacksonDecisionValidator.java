package com.example.claudeapi.infrastructure;

import com.example.claudeapi.application.DecisionValidator;
import com.example.claudeapi.domain.Decision;
import com.example.claudeapi.domain.ModelDecision;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class JacksonDecisionValidator implements DecisionValidator {
    private final ObjectMapper mapper = new ObjectMapper();

    public ModelDecision validate(String rawJson) {
        try {
            JsonNode root = mapper.readTree(rawJson);
            Decision decision = Decision.valueOf(required(root, "decision"));
            List<String> reasons = array(root, "reasonCodes");
            List<String> evidence = array(root, "evidenceIds");
            double confidence = root.path("confidence").asDouble(-1);
            boolean approval = root.path("requiresHumanApproval").asBoolean();

            if (confidence < 0 || confidence > 1) {
                throw new IllegalArgumentException("confidence must be between 0 and 1");
            }
            if (evidence.isEmpty()) {
                throw new IllegalArgumentException("at least one evidenceId is required");
            }
            return new ModelDecision(decision, reasons, evidence, confidence, approval);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Invalid model output", ex);
        }
    }

    private static String required(JsonNode root, String field) {
        String value = root.path(field).asText(null);
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required");
        return value;
    }

    private static List<String> array(JsonNode root, String field) {
        if (!root.path(field).isArray()) throw new IllegalArgumentException(field + " must be an array");
        List<String> result = new ArrayList<>();
        root.path(field).forEach(n -> result.add(n.asText()));
        return result;
    }
}
