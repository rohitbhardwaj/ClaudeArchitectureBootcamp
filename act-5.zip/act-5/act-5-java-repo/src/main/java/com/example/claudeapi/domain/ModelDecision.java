package com.example.claudeapi.domain;
import java.util.List;

public record ModelDecision(
    Decision decision,
    List<String> reasonCodes,
    List<String> evidenceIds,
    double confidence,
    boolean requiresHumanApproval
) {}
