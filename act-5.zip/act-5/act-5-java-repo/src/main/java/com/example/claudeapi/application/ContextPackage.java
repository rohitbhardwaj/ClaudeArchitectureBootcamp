package com.example.claudeapi.application;
import java.math.BigDecimal;
import java.util.List;

public record ContextPackage(
    String customerId,
    BigDecimal orderTotal,
    String currency,
    List<String> trustedPolicyIds,
    boolean fraudHold,
    String policyVersion
) {}
