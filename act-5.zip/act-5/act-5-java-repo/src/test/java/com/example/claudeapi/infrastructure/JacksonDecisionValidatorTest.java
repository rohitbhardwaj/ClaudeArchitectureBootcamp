package com.example.claudeapi.infrastructure;

import com.example.claudeapi.domain.Decision;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class JacksonDecisionValidatorTest {
    private final JacksonDecisionValidator validator = new JacksonDecisionValidator();

    @Test
    void validatesStructuredDecision() {
        var result = validator.validate("{\"decision\":\"APPROVE\",\"reasonCodes\":[\"WITHIN_POLICY\"],\"evidenceIds\":[\"policy-1\"],\"confidence\":0.91,\"requiresHumanApproval\":false}");
        assertEquals(Decision.APPROVE, result.decision());
    }

    @Test
    void rejectsInvalidJson() {
        assertThrows(IllegalArgumentException.class, () -> validator.validate("{invalid"));
    }

    @Test
    void rejectsMissingEvidence() {
        assertThrows(IllegalArgumentException.class, () ->
            validator.validate("{\"decision\":\"APPROVE\",\"reasonCodes\":[\"WITHIN_POLICY\"],\"evidenceIds\":[],\"confidence\":0.91,\"requiresHumanApproval\":false}")
        );
    }
}
