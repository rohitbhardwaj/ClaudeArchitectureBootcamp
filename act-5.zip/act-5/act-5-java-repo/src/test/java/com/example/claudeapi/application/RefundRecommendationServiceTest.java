package com.example.claudeapi.application;

import com.example.claudeapi.api.RefundRecommendationRequest;
import com.example.claudeapi.domain.Decision;
import com.example.claudeapi.domain.ModelDecision;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class RefundRecommendationServiceTest {
    @Test
    void fraudHoldForcesHumanReview() {
        ContextProvider context = req -> new ContextPackage(
            req.customerId(), new BigDecimal("150.00"), "USD",
            List.of("policy-1"), true, "v1"
        );
        ClaudeModelGateway gateway = (req, ctx) -> "{}";
        DecisionValidator validator = raw -> new ModelDecision(
            Decision.APPROVE, List.of("WITHIN_POLICY"),
            List.of("policy-1"), 0.95, false
        );
        RefundRecommendationService service = new RefundRecommendationService(
            context, gateway, validator, (a,b,c,d) -> {}
        );

        var response = service.recommend(
            new RefundRecommendationRequest(
                UUID.randomUUID(), "cust-1",
                new BigDecimal("50.00"), "USD", "possible fraud"
            ),
            "req-1", "trace-1"
        );

        assertEquals("RECOMMEND_REVIEW", response.decision());
        assertTrue(response.requiresHumanApproval());
    }
}
