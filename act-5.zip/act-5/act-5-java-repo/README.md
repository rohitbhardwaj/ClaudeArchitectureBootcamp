# Claude Refund Recommendation API

## Run

```bash
mvn test
mvn spring-boot:run
```

## Example

```bash
curl -X POST http://localhost:8082/api/v1/refund-recommendations   -H 'Content-Type: application/json'   -H 'Idempotency-Key: refund-123'   -H 'X-Trace-Id: trace-abc'   -d '{
    "orderId":"00000000-0000-0000-0000-000000000001",
    "customerId":"cust-1",
    "requestedAmount":50.00,
    "currency":"USD",
    "reason":"duplicate order"
  }'
```

Failure simulation reasons:
- `invalid-json`
- `missing-evidence`
- `possible fraud`
