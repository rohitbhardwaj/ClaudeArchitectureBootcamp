# Sample Answer — Five-Question Triage

1. Job: classify complaint, retrieve facts, recommend remediation, draft communication, and possibly update CRM.
2. Context: complaint, customer profile, account history, current policy, prior actions, user authority.
3. Tools: customer lookup, policy search, CRM update, response draft, escalation.
4. Failure: privacy leakage, wrong remediation, unauthorized update, injection, duplicate action.
5. Proof and control: user-scoped identity, read/write separation, policy validation, approval, schema validation, traces, task and safety evals.

Recommended pattern: Agent SDK + MCP + RAG, with writes and approvals outside the model.
