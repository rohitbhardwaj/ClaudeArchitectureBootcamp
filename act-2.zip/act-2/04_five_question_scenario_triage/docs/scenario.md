# Scenario

Claude analyzes customer complaints, retrieves account history, recommends remediation, updates CRM fields, and drafts a response.

## Hidden complication

The design will eventually support multiple teams with different identities, permissions, risk tolerances, and owners.

## Architecture pressure

Leadership wants productivity quickly. Security wants least privilege. Operations wants traceability and rollback. Product wants acceptable latency and cost.
