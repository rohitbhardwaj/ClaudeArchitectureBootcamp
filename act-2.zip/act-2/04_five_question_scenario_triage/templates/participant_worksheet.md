# Participant Worksheet — Assignment 4 — Five-Question Scenario Triage

## Business outcome

## Active domains

| Domain | Active / Supporting / Not needed | Why? |
|---|---|---|
| Platform fundamentals | | |
| Claude Code | | |
| MCP and tools | | |
| Agent SDK | | |
| Claude API | | |
| RAG and context | | |
| Evals and observability | | |
| Production governance | | |

## Six layers

| Layer | Components | Owner | Main risk |
|---|---|---|---|
| Experience | | | |
| Claude capability | | | |
| Context | | | |
| Tools | | | |
| Governance | | | |
| Operations | | | |

## Five-question triage

1. What is Claude being asked to do?
2. What context does it need?
3. What tools can it access?
4. What can go wrong?
5. How will we control and prove the outcome?

## Risks and controls

| Risk | Impact | Control | Evidence |
|---|---|---|---|
| | | | |

## Recommendation
Go / Conditional Go / No-Go
