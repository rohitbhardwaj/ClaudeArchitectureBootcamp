# Assignment 4 — Five-Question Scenario Triage

## Goal
Apply architecture-first triage before selecting technology.

## Scenario
Claude analyzes customer complaints, retrieves account history, recommends remediation, updates CRM fields, and drafts a response.

## Tasks
1. Define the job Claude performs.
2. Define required context.
3. Classify tool access.
4. Identify failure modes.
5. Define proof and controls.
6. Choose the architecture only after triage.

## Deliverables
- Five-question triage
- Risk classification
- Selected architecture
- Evidence plan

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
