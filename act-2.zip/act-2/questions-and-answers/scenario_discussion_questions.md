# Scenario Discussion Questions

1. Which domain is most visible and which is most important but least visible?
2. Which layer owns user experience? Which owns authority?
3. What is the simplest viable architecture?
4. Where does agentic behavior add value?
5. Where does agentic behavior add unnecessary risk?
6. What is evidence and what is instruction?
7. Which tool creates the greatest blast radius?
8. What must be externally enforced?
9. What would you trace to reconstruct failure?
10. What would force a No-Go?
