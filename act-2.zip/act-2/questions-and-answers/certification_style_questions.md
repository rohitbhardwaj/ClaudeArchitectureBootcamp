# Certification-Style Questions

## 1
Claude output is sent directly into a payment service. Best first correction?

A. Larger model  
B. Longer prompt  
C. Explicit contracts, validation, policy checks, and observability  
D. Longer timeout

**Answer: C**

## 2
Classify a short support message into six categories; no tools or iteration.

A. Multi-agent  
B. Claude API with structured output  
C. Claude Code  
D. MCP deployment tool

**Answer: B**

## 3
A workflow reads Jira, inspects code, runs tests, and opens a PR.

A. Only Claude Code  
B. Only MCP  
C. Multi-domain: Claude Code, tools, evals, governance  
D. No operations layer

**Answer: C**

## 4
A RAG assistant has UI, API, vector index, and model, but no source ownership, evals, or traces. Weakest layers?

A. Experience  
B. Governance and operations  
C. Tools  
D. Claude capability

**Answer: B**

## 5
An assistant evolves from answers to issuing refunds. What should happen?

A. Same controls  
B. Automatic autonomy  
C. Add identity, policy, approval, audit, idempotency, rollback  
D. Larger context

**Answer: C**

## 6
Best reason to use Agent SDK?

A. It sounds innovative  
B. Multi-step planning, tools, evaluation, continuation  
C. Long prompt  
D. JSON output

**Answer: B**

## 7
Best evidence for increasing autonomy?

A. Positive demo  
B. Confident output  
C. Repeated eval success, low violations, traceable outcomes, tested rollback  
D. Longer prompt

**Answer: C**

## 8
Where should least privilege and approval gates live?

A. Experience  
B. Governance  
C. Context  
D. Model prose

**Answer: B**
