# Product and Pattern Selection Cases

1. Summarize a two-page customer email within five seconds; no tools.
2. Refactor one repository module, edit files, run tests, and prepare a PR.
3. Answer employee policy questions with current citations and regional access control.
4. Read a support ticket, retrieve policy, update CRM, draft a reply, and escalate high-value refunds.
5. Process 500 pull requests nightly into structured release notes.
6. Correlate incidents, inspect runbooks and code, propose a fix, run validation, and request deployment approval.
