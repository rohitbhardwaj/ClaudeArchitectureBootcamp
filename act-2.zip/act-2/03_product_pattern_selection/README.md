# Assignment 3 — Product and Pattern Selection

## Goal
Choose the simplest appropriate Claude capability based on workflow shape and risk.

## Scenario
Select an architecture for six enterprise use cases.

## Tasks
1. Choose Claude Code, Claude API, Agent SDK, MCP, RAG, or a combination.
2. Explain why a simpler pattern is insufficient.
3. Explain why a more agentic pattern may be unnecessary.
4. Name the first governance control.
5. Name the first eval.

## Deliverables
- Selection matrix
- Tradeoff rationale
- Over-agenting warning
- Control and eval recommendations

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
