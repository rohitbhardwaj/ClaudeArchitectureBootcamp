# Sample Answer

| Case | Recommended pattern | Why |
|---|---|---|
| 1 | Claude API, synchronous | Simple one-step transformation |
| 2 | Claude Code | Repository-aware editing, tests, and PR workflow |
| 3 | Claude API + RAG + evals | Controlled app flow with current evidence |
| 4 | Agent SDK + MCP + RAG | Multi-step workflow with tools and policy evidence |
| 5 | Batch API workflow | High-volume offline processing |
| 6 | Agent SDK + MCP + repository workflow | Multi-domain workflow with checkpoints and approval |

Use the simplest architecture that satisfies the workflow.
