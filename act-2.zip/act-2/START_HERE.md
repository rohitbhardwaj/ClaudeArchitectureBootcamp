# Start Here — Act 2: The Claude Architecture Landscape

## Central question

> When Claude becomes part of code, data, tools, workflows, and production operations, which architecture domains and controls become active?

## Learning outcomes

1. Explain the eight Claude architecture domains.
2. Describe the six-layer production architecture stack.
3. Map a real use case to multiple active domains.
4. Select the simplest appropriate Claude pattern.
5. Identify context, tools, risks, controls, and evidence.
6. Defend decisions under cost, latency, security, and governance constraints.

## Suggested sequence

| Order | Assignment | Time |
|---|---|---:|
| 1 | Eight-Domain Mapping | 15 min |
| 2 | Six-Layer Stack Assembly | 15 min |
| 3 | Product and Pattern Selection | 20 min |
| 4 | Five-Question Scenario Triage | 20 min |
| 5 | Multi-Domain Bug-Fix Bot | 25 min |
| 6 | Capability-to-Control Escalation | 20 min |
| 7 | Architecture Tradeoff Defense | 25 min |
| 8 | Final Landscape Capstone | 35 min |

## Memory line

> Feature-first answers fail architecture scenarios. Domain-first reasoning wins.
