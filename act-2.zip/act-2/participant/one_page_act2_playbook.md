# Act 2 One-Page Playbook

## Eight domains
Platform · Claude Code · MCP · Agent SDK · API · RAG · Evals · Production

## Six layers
Experience · Claude Capability · Context · Tools · Governance · Operations

## Five questions
1. What is Claude being asked to do?
2. What context does it need?
3. What tools can it access?
4. What can go wrong?
5. How will we control and prove it?

## Product lens
- Claude API: controlled application interactions
- Claude Code: repository-aware engineering
- MCP: enterprise tool and data boundary
- Agent SDK: bounded multi-step workflows
- RAG: trusted current evidence
- Evals and observability: proof and improvement

> Use the simplest pattern that satisfies the workflow.
