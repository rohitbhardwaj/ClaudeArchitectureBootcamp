# Facilitator Run of Show

## 0–5 min
Reconnect to Act 1: uncontrolled capability creates risk.

## 5–12 min
Teach the eight domains.

## 12–18 min
Teach the six layers.

## 18–25 min
Model the five-question triage.

## 25–40 min
Run Assignment 1 or 2.

## 40–55 min
Run Assignment 3 or 4.

## Extended practice
Use Assignments 5–8 as deeper workshop labs or GitHub katas.

## Closing sentence
> We use ______ because the workflow requires ______, while keeping ______ outside Claude because ______.
