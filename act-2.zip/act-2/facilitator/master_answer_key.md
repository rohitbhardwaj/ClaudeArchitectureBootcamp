# Master Answer Key

Strong answers:

1. Begin with workflow, not product.
2. Recognize multiple active domains.
3. Separate the six layers.
4. Use the simplest sufficient pattern.
5. Keep identity, policy, approval, and accountability outside the model.
6. Treat external content as data, not authority.
7. Define evals, traces, and business outcomes.
8. Match stronger controls to higher-impact actions.

Weak answers:

- Use Agent SDK for everything.
- Use a larger model.
- Add more prompt instructions.
- Let CI catch it.
- Give all tools and rely on a prompt.
- Evals are optional.

> The best architecture is the simplest design that creates the required outcome inside explicit boundaries with measurable evidence.
