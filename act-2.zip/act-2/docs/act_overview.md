# Act 2 Overview

Teams often start with a product or model choice. That creates feature-first architectures: a direct API call without validation, an agent with broad tools, RAG without source governance, or Claude Code without repository controls.

Act 2 reverses the sequence. First classify the work, context, tools, risk, evidence, and operational needs. Then choose the Claude capability.

## Eight domains

1. Platform Fundamentals
2. Claude Code
3. MCP and Tools
4. Agent SDK
5. Claude API
6. RAG and Context
7. Evals and Observability
8. Production Governance

## Six layers

1. Experience
2. Claude Capability
3. Context
4. Tools
5. Governance
6. Operations

> As Claude moves closer to production impact, capability increases and control must increase with it.
