# Eight-Domain Reference

## 1. Platform Fundamentals
Models, messages, system instructions, context windows, tool use, structured output, streaming, and batches.

## 2. Claude Code
Repository exploration, file edits, command execution, tests, pull requests, and engineering automation.

## 3. MCP and Tools
Enterprise systems, identity, permissions, tool contracts, read/write separation, side effects, and audit.

## 4. Agent SDK
Programmable multi-step workflows, session context, tool loops, checkpoints, stop conditions, retries, and escalation.

## 5. Claude API
Application integration, validation, structured output, streaming, async jobs, and tool-driven flows.

## 6. RAG and Context
Source curation, retrieval, metadata, freshness, access control, citations, answerability, and context budgeting.

## 7. Evals and Observability
Golden datasets, regression testing, traces, prompt versions, source evidence, tool calls, latency, tokens, cost, and outcomes.

## 8. Production Governance
Identity, risk classification, approvals, release gates, audit, incidents, rollback, ownership, and compliance.
