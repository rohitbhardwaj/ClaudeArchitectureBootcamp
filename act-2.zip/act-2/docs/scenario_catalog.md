# Scenario Catalog

## A — Repository Modernization Assistant
Inspects Java code, proposes modernization, edits code, runs tests, and opens PRs.

## B — Employee Policy Assistant
Retrieves HR policies and answers with citations and regional access controls.

## C — Support Refund Agent
Reads tickets, retrieves policy, updates CRM, and issues approved refunds.

## D — Production Incident Assistant
Reads alerts and logs, searches runbooks, inspects code, creates Jira issues, proposes patches, and requests deployment.

## E — Contract Risk Analysis API
Asynchronously analyzes large contracts, retrieves legal guidance, returns structured findings, and routes high-risk cases to legal review.

## F — Batch Documentation Generator
Generates release notes and migration guides from hundreds of pull requests nightly.
