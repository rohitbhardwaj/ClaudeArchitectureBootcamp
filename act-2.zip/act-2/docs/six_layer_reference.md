# Six-Layer Production Architecture Reference

## Experience
Chat, IDE, CLI, GitHub, workflow UI, API, event, or batch job.

## Claude Capability
Claude API, Claude Code, Agent SDK, or a combination.

## Context
User request, repository, files, policies, RAG evidence, session state, profiles, and tool results.

## Tools
MCP servers, APIs, databases, SaaS, CI/CD, messaging, and business actions.

## Governance
Identity, least privilege, approvals, policy enforcement, validation, and audit.

## Operations
Traces, evals, cost, latency, reliability, incidents, fallbacks, and rollback.
