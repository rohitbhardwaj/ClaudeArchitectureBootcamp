# Scenario

A legal-analysis workflow must be accurate, cited, under $2 per document, usually complete within 90 seconds, and fully traceable. Documents can exceed 300 pages.

## Hidden complication

The design will eventually support multiple teams with different identities, permissions, risk tolerances, and owners.

## Architecture pressure

Leadership wants productivity quickly. Security wants least privilege. Operations wants traceability and rollback. Product wants acceptable latency and cost.
