# Sample Answer — Legal Analysis

Use an asynchronous job architecture with Claude API, curated retrieval, structured findings, trace IDs, citations, and human review for high-risk findings.

Avoid one synchronous call because document size and runtime vary. Avoid fully autonomous legal disposition because business authority remains with legal reviewers.

Cost controls: segmentation, reusable retrieval, token budgets, model routing, caching, and answerability checks.

Quality controls: schema validation, citation verification, legal-risk evals, regression tests, and reviewer override tracking.
