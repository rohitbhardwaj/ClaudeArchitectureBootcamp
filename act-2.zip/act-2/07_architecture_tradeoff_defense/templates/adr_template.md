# Architecture Decision Record

## Title
## Status
## Context
## Decision drivers
## Options considered
## Decision
## Consequences
## Risks and mitigations
## Eval and release gates
## Rollback strategy
