# Assignment 7 — Architecture Tradeoff Defense

## Goal
Defend architecture choices under conflicting requirements.

## Scenario
A legal-analysis workflow must be accurate, cited, under $2 per document, usually complete within 90 seconds, and fully traceable. Documents can exceed 300 pages.

## Tasks
1. Choose sync, streaming, async, or batch.
2. Choose one-shot API or agent workflow.
3. Define retrieval.
4. Define structured output and human review.
5. Explain cost, latency, quality, and governance tradeoffs.
6. Present to an architecture review board.

## Deliverables
- ADR
- Tradeoff matrix
- Risk register
- Three-minute defense

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
