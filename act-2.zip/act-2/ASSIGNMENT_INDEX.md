# Act 2 Assignment Index

| Assignment | Skill | Primary artifact |
|---|---|---|
| 1. Eight-Domain Mapping | Recognize active domains | Domain map |
| 2. Six-Layer Stack Assembly | Separate architecture layers | Layered design |
| 3. Product and Pattern Selection | Choose the simplest suitable capability | Decision matrix |
| 4. Five-Question Scenario Triage | Analyze before selecting technology | Triage worksheet |
| 5. Multi-Domain Bug-Fix Bot | Design a cross-domain workflow | Architecture proposal |
| 6. Capability-to-Control Escalation | Match controls to authority | Control ladder |
| 7. Architecture Tradeoff Defense | Defend choices under constraints | ADR and defense |
| 8. Final Landscape Capstone | Synthesize the act | Production landscape canvas |
