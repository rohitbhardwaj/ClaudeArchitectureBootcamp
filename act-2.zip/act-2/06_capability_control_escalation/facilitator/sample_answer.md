# Sample Answer — Capability-to-Control Escalation

| Stage | Minimum added control |
|---|---|
| Answer | Output validation and quality evals |
| Retrieve | Source authorization, freshness, citations, answerability |
| Modify code | Repo boundaries, plan-first workflow, tests, PR review |
| Write tools | Least privilege, identity, validation, idempotency, approval |
| Production action | Separate workflow, named owner, canary, kill switch, rollback |

Autonomy should increase only when measured evidence proves the bounded workflow is safe.
