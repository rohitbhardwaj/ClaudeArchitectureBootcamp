# Capability-to-Control Ladder

| Stage | New capability | New failure mode | Minimum control | Evidence before scaling |
|---|---|---|---|---|
| 1. Answer | | | | |
| 2. Retrieve | | | | |
| 3. Modify code | | | | |
| 4. Write tools | | | | |
| 5. Production action | | | | |
