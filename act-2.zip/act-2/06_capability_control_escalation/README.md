# Assignment 6 — Capability-to-Control Escalation

## Goal
Match stronger controls to increasing Claude authority.

## Scenario
An assistant evolves from answering questions to retrieving data, editing code, calling write tools, and triggering production changes.

## Tasks
1. Define each new capability.
2. Define each new failure mode.
3. Add the minimum control before advancing.
4. Define evidence required for more autonomy.
5. Choose your organization’s current stop point.

## Deliverables
- Capability-control ladder
- Autonomy evidence table
- Stop point
- Conditional scale plan

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
