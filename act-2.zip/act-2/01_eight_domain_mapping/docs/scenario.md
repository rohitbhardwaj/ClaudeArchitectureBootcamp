# Scenario

Claude reads a GitHub issue, inspects a repository, retrieves an internal runbook, proposes a fix, runs tests, opens a pull request, and notifies the team in Slack.

## Hidden complication

The design will eventually support multiple teams with different identities, permissions, risk tolerances, and owners.

## Architecture pressure

Leadership wants productivity quickly. Security wants least privilege. Operations wants traceability and rollback. Product wants acceptable latency and cost.
