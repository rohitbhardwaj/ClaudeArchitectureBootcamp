# Participant Instructions

## Scenario
Claude reads a GitHub issue, inspects a repository, retrieves an internal runbook, proposes a fix, runs tests, opens a pull request, and notifies the team in Slack.

## Working method

1. Read the scenario without selecting a product.
2. Identify business outcome and failure impact.
3. Complete the worksheet.
4. Create one architecture diagram.
5. Record assumptions.
6. Prepare a two-minute defense.

## Questions

- What job is Claude performing?
- What information is required and trusted?
- Which actions change state?
- What happens if Claude is wrong?
- Which controls exist outside the model?
- What evidence proves success?
