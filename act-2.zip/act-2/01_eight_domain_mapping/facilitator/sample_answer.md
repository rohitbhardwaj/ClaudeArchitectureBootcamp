# Sample Answer — Eight-Domain Mapping

| Domain | Classification | Rationale |
|---|---|---|
| Platform fundamentals | Supporting | Messages, context, and tool use underpin execution |
| Claude Code | Active | Inspects and changes repository files and runs tests |
| MCP and tools | Active | GitHub, Slack, runbooks, and CI are external tools |
| Agent SDK | Active or Supporting | Coordinates multi-step work |
| Claude API | Supporting | Application integration |
| RAG and context | Active | Retrieves trusted runbook evidence |
| Evals and observability | Active | Measures tests, traces, tool calls, and outcomes |
| Production governance | Active | Controls identity, approval, merge, and rollback |

Most forgotten domain: evals and observability.
