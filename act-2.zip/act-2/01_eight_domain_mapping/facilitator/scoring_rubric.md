# Scoring Rubric

Score 0–3 per dimension.

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Domain mapping | Missing | Partial | Mostly correct | Complete and justified |
| Layer separation | Collapsed | Several gaps | Clear | Clear with ownership |
| Pattern selection | Feature-first | Weak rationale | Appropriate | Simplest defensible design |
| Risk controls | Missing | Prompt-only | Multiple controls | Risk-proportional controls |
| Evidence | None | Generic logs | Evals or traces | End-to-end evidence |
| Tradeoff defense | None | Assertions | Reasoned | Alternatives and consequences |

Maximum: 18.
