# Assignment 1 — Eight-Domain Mapping

## Goal
Identify which Claude architecture domains are active and explain why.

## Scenario
Claude reads a GitHub issue, inspects a repository, retrieves an internal runbook, proposes a fix, runs tests, opens a pull request, and notifies the team in Slack.

## Tasks
1. Mark each domain Active, Supporting, or Not Required.
2. Explain every Active domain in one sentence.
3. Identify the domain with the greatest production risk.
4. Identify the domain most likely to be forgotten.
5. Draw the dependency flow among active domains.

## Deliverables
- Completed domain map
- Dependency diagram
- Top three risks
- One-sentence architecture thesis

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
