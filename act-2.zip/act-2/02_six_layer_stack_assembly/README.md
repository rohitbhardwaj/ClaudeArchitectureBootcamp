# Assignment 2 — Six-Layer Stack Assembly

## Goal
Separate a Claude system into experience, capability, context, tools, governance, and operations.

## Scenario
An employee asks whether a travel expense is reimbursable. Claude retrieves the current policy, checks region, cites evidence, and drafts an approval request.

## Tasks
1. Place every component into one of six layers.
2. Identify components that cross layers.
3. Add one missing governance component.
4. Add one missing operations component.
5. Describe the request path end to end.

## Deliverables
- Six-layer architecture
- Request-path narrative
- Missing-control analysis
- Layer ownership table

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
