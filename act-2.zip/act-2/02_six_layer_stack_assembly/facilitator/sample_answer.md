# Sample Answer — Six-Layer Stack

| Layer | Components |
|---|---|
| Experience | Employee chat |
| Claude capability | Claude API |
| Context | User intent, region, current travel policy |
| Tools | Policy search, profile lookup, approval-draft service |
| Governance | Authorization, regional filters, approval, validation |
| Operations | Trace ID, citations, latency, cost, groundedness, escalation |

Common missing control: source authorization before retrieval.
