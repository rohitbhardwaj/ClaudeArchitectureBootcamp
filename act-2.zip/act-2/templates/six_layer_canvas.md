# Six-Layer Architecture Canvas

| Layer | Components | Data or authority | Owner | Failure mode |
|---|---|---|---|---|
| Experience | | | | |
| Claude capability | | | | |
| Context | | | | |
| Tools | | | | |
| Governance | | | | |
| Operations | | | | |
