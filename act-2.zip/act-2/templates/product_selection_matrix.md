# Product and Pattern Selection Matrix

| Use case | Workflow shape | Recommended capability | Supporting domains | Why not simpler? | Why not more agentic? |
|---|---|---|---|---|---|
| | | | | | |
