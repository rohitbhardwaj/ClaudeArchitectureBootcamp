# Five-Question Scenario Triage

1. What is Claude being asked to do?
2. What context does it need?
3. What tools can it access?
4. What can go wrong?
5. How will we control and prove the outcome?
