# Eight-Domain Map

| Domain | Active? | Role | Main risk | Required control |
|---|---|---|---|---|
| Platform fundamentals | | | | |
| Claude Code | | | | |
| MCP and tools | | | | |
| Agent SDK | | | | |
| Claude API | | | | |
| RAG and context | | | | |
| Evals and observability | | | | |
| Production governance | | | | |
