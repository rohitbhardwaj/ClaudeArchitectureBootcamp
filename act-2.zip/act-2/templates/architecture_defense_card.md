# Architecture Defense Card

## Decision

## Business outcome

## Selected pattern

## Why this is the simplest sufficient design

## Authority kept outside Claude

## Top three risks

## Required controls

## Evidence and evals

## Fallback and rollback

## One rejected alternative and why
