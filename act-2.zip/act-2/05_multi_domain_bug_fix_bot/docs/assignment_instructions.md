# Participant Instructions

## Scenario
Claude reads incidents, correlates logs, inspects code, retrieves runbooks, proposes a patch, runs tests, opens a PR, and requests deployment.

## Working method

1. Read the scenario without selecting a product.
2. Identify business outcome and failure impact.
3. Complete the worksheet.
4. Create one architecture diagram.
5. Record assumptions.
6. Prepare a two-minute defense.

## Questions

- What job is Claude performing?
- What information is required and trusted?
- Which actions change state?
- What happens if Claude is wrong?
- Which controls exist outside the model?
- What evidence proves success?
