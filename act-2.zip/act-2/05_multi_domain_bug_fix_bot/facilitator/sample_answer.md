# Sample Answer — Multi-Domain Bug-Fix Bot

1. Classify incident risk.
2. Read logs and approved runbooks.
3. Inspect repository in read-only mode.
4. Propose diagnosis and patch plan.
5. Require approval before payment-code modification.
6. Create narrow branch and patch.
7. Run unit, integration, contract, and reconciliation tests.
8. Open PR with evidence and risks.
9. Require CODEOWNERS and business approval.
10. Request deployment through a separate controlled workflow.
11. Canary, observe reconciliation metrics, and rollback on failure.

The issue text attempting to bypass approvals is untrusted data, not authority.
