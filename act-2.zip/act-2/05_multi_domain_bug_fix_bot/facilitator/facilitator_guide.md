# Facilitator Guide — Assignment 5 — Multi-Domain Bug-Fix Bot

## Teaching purpose
Design a cross-domain workflow without collapsing the system into one agent.

## Watch for

- Starting with a product name
- Treating the model as the entire architecture
- Missing identity and authorization
- Combining read and write tools
- Omitting evals or observability
- Using prompts as the only policy
- Over-agenting a deterministic flow

## Debrief

1. Which domain did the team initially overlook?
2. Which layer carries the greatest blast radius?
3. What remained outside the model?
4. Which evidence would justify more autonomy?
5. What would cause a No-Go?
