# Assignment 5 — Multi-Domain Bug-Fix Bot

## Goal
Design a cross-domain workflow without collapsing the system into one agent.

## Scenario
Claude reads incidents, correlates logs, inspects code, retrieves runbooks, proposes a patch, runs tests, opens a PR, and requests deployment.

## Tasks
1. Map all active domains.
2. Classify actions by risk.
3. Choose where deterministic orchestration replaces autonomy.
4. Define human approval points.
5. Define observability and rollback.
6. Identify one prompt-injection path.

## Deliverables
- End-to-end architecture
- Risk ladder
- Approval map
- Telemetry map
- Rollback plan

## Completion rule
A strong answer explains not only what technology is selected, but why its authority, context, tools, evidence, and production controls are appropriate.
