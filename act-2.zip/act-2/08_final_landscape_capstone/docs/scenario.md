# Scenario

Design a support operations platform that reads cases, retrieves policy, drafts responses, updates records, issues approved credits, evaluates quality, and operates across regions.

## Hidden complication

The design will eventually support multiple teams with different identities, permissions, risk tolerances, and owners.

## Architecture pressure

Leadership wants productivity quickly. Security wants least privilege. Operations wants traceability and rollback. Product wants acceptable latency and cost.
