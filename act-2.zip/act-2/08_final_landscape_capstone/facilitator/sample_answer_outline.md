# Sample Answer Outline

A strong design may use:

- workflow UI or case-management experience;
- Agent SDK for bounded multi-step orchestration;
- Claude API for structured decisions and drafted responses;
- RAG for current regional policy;
- MCP tools separated into read, draft, write, and financial action classes;
- user-scoped identity where possible;
- approval for high-value credits and irreversible actions;
- prompt, RAG, tool, safety, regression, and business evals;
- traces linking intent, evidence, model calls, tools, approvals, and outcomes;
- staged release from read-only to progressive autonomy.

Likely decision: Conditional Go until authorization filters, approval evidence, rollback tests, and policy ownership are verified.
