# Production Landscape Canvas

1. Business purpose
2. Eight-domain map
3. Six-layer architecture
4. Identities
5. Context and source trust
6. Tool authority
7. Agent versus deterministic boundary
8. Evals and release gates
9. Observability and business outcomes
10. Failure, fallback, and rollback
11. Ownership
12. Go / Conditional Go / No-Go
