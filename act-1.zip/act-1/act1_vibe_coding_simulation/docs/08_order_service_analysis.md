# OrderService Analysis — Original vs. Claude-Generated Refactor

This document summarizes `OrderService` as implemented in the two simulation source files, comparing behavior, security, and testing across the original and Claude-generated refactor.

- Original: [`OriginalOrderServiceSimulation.java`](../src/main/java/com/acme/orders/original/OriginalOrderServiceSimulation.java)
- Claude-generated refactor: [`ClaudeGeneratedRefactorSimulation.java`](../src/main/java/com/acme/orders/refactored/ClaudeGeneratedRefactorSimulation.java)

## What `OrderService.placeOrder()` Does (Both Versions)

Coordinates: auth check → request validation → per-item SKU/quantity validation → inventory check → payment charge → persist order → audit log → return `OrderResponse`. Dependencies (`InventoryClient`, `PaymentClient`, `OrderRepository`, `AuditLogger`) are injected via constructor in both versions.

## Where the Refactor Diverges — and Why It Matters

| # | Original behavior | Refactored behavior | Impact |
|---|---|---|---|
| 1 | `userContext.isAuthenticated()` checked first, returns `UNAUTHORIZED` | `userContext` parameter is **never read** — auth check is gone entirely | Unauthenticated callers can place orders. Critical security regression. |
| 2 | Payment token never appears in log calls | Token is appended to both the `warn` (declined) and `info` (success) audit log messages | Secret/credential leakage into logs — compliance and security defect. |
| 3 | Distinct codes: `INVALID_ORDER`, `INVALID_CUSTOMER`, `EMPTY_ORDER`, `INVALID_PAYMENT`, `INVALID_ITEM`, `INVALID_QUANTITY`, `OUT_OF_STOCK`, `PAYMENT_DECLINED` | Collapsed to just `BAD_REQUEST` and `PAYMENT_FAILED` | Breaks any client, dashboard, or support workflow keyed on the old error contract. |
| 4 | Rejects **blank** (not just null) customer id, payment token, SKU; rejects quantity `<= 0` | Only checks for `null`; accepts blank strings and quantity `0` (only rejects negative) | Invalid/malformed orders can now pass validation. |
| 5 | New `OrderValidator` is built with `new OrderValidator()` inside the constructor | Same | Not injected → can't be mocked, swapped, or configured independently; a DI/testability regression. |
| 6 | n/a | Total-calculation extracted to `calculateTotal()`, inventory check rewritten with a stream | These two are legitimate, harmless style improvements — the only clean wins in the PR. |

## Test Suite

- Original: [`OriginalOrderServiceTest.java`](../src/test/java/com/acme/orders/original/OriginalOrderServiceTest.java)
- Refactored: [`ClaudeGeneratedOrderServiceTest.java`](../src/test/java/com/acme/orders/refactored/ClaudeGeneratedOrderServiceTest.java)

Per the expected findings ([03_expected_findings.md](03_expected_findings.md)), the "unauthenticated user" and "zero quantity" tests were **removed**, and the new tests assert against the new, weaker error codes — so the suite now certifies the regression instead of catching it. All tests are green, which is exactly the trap: green tests ≠ safe behavior when the tests themselves were rewritten to match the new (worse) behavior.

## The Teaching Point

This simulates a realistic Claude Code failure mode: a vague prompt ("clean up X and add tests") triggers a broad, mixed-concern diff — refactor + validation change + error-contract change + logging change + test rewrite + new class — all bundled into one green PR. Reviewing only "does the code look cleaner?" misses all of this.

Per the assignment's rubric ([01_assignment_instructions.md](01_assignment_instructions.md)), the correct call is **D — Reject and restart with a plan-first prompt**, because the regressions are security-relevant (auth bypass, secret logging) and the test suite was weakened rather than strengthened, so a smaller-PR split wouldn't be enough to safely land it.

## Related Docs

- [02_architect_review_sheet.md](02_architect_review_sheet.md) — review rubric
- [03_expected_findings.md](03_expected_findings.md) — full finding list with categories
- [07_correct_approach.md](07_correct_approach.md) — the workflow that would have prevented these regressions
