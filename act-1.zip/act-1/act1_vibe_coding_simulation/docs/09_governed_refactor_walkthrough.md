# The Governed Refactor — Walkthrough

This document maps [07_correct_approach.md](07_correct_approach.md) to what was actually done in
[`GovernedOrderServiceSimulation.java`](../src/main/java/com/acme/orders/governed/GovernedOrderServiceSimulation.java)
and [`GovernedOrderServiceTest.java`](../src/test/java/com/acme/orders/governed/GovernedOrderServiceTest.java).

It answers the same prompt used to produce the flawed refactor:

```text
Clean up the OrderService and add tests.
```

## Step-by-step

| Step (from 07) | What was done |
|---|---|
| 1. Separate planning from modification | Scope was fixed before any code was written: one concern only (see Step 5 below), reusing the plan-first workflow instead of generating a refactor and tests in the same pass. |
| 2. Capture current behavior before touching code | Reused the behavior inventory already written in [08_order_service_analysis.md](08_order_service_analysis.md): every error code, every validation rule (including blank strings and zero quantity), the position of the auth check, and the no-secret-logging rule. |
| 3. Add characterization tests before refactoring | `GovernedOrderServiceTest` reproduces every test from `OriginalOrderServiceTest` unchanged, plus new tests for the gaps that suite left open: `rejectsMissingOrderRequest`, `rejectsEmptyItems`, `rejectsBlankPaymentToken`, `rejectsBlankSku`, `rejectsDeclinedPayment`, and `neverLogsPaymentToken`. None of these assertions were relaxed to make the refactor pass. |
| 4. Make non-negotiable constraints explicit | The auth check stays first and inline, no error code is renamed/merged, and the payment token never reaches `auditLogger` — all unchanged from the original, and now each is covered by its own test rather than relying on a reviewer to notice a diff. |
| 5. Keep the change small enough to review | Exactly one concern: extract request/item validation into `OrderValidator`, injected as a constructor dependency. No behavior change, no new error codes, no test deletions — matching the example PR description in 07 verbatim. |
| 6. Review for behavior and boundaries, not just "cleaner" | The diff below is the whole change; every other line of `placeOrder` is untouched. |

## What actually changed vs. the original

```text
+ OrderValidator added as a 5th constructor parameter (injected, not `new`'d inline)
+ Validation logic (6 checks) moved from inline `if` statements into OrderValidator.validate()
  - same 6 error codes, same messages, same blank-string and zero-quantity rules
= Auth check: unchanged, same position
= Inventory loop, total calculation, payment charge, persistence, audit logging: unchanged
= Zero renamed, merged, or new error codes
= Zero deleted tests
```

Compare this to the flawed refactor's diff in [08_order_service_analysis.md](08_order_service_analysis.md):
auth check deleted, payment token logged, eight error codes collapsed into two, and two tests removed —
all bundled into one "just cleanup" PR. The governed version demonstrates that the same prompt, run
through a plan-first / tests-first workflow, does not have to produce any of that.
