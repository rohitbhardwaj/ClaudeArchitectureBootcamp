package com.acme.orders.governed;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Characterization tests for the governed refactor.
 *
 * <p>Teaching note: every test from {@code OriginalOrderServiceTest} is reproduced unchanged here,
 * plus new tests covering the gaps that suite left open (per {@code docs/07_correct_approach.md}
 * Step 3). None of these assertions were relaxed to make the refactor pass.</p>
 */
class GovernedOrderServiceTest {

    /** Mock inventory dependency to avoid calling a real inventory system during unit tests. */
    private final InventoryClient inventoryClient = mock(InventoryClient.class);

    /** Mock payment dependency to avoid making real charges during unit tests. */
    private final PaymentClient paymentClient = mock(PaymentClient.class);

    /** Mock repository to verify persistence behavior without writing to a database. */
    private final OrderRepository orderRepository = mock(OrderRepository.class);

    /** Mock audit logger to verify behavior without writing real logs. */
    private final AuditLogger auditLogger = mock(AuditLogger.class);

    /** Real validator instance: pure and dependency-free, so it is not mocked. */
    private final OrderValidator orderValidator = new OrderValidator();

    /** Service under test, with the validator injected like every other collaborator. */
    private final OrderService orderService = new OrderService(
            inventoryClient,
            paymentClient,
            orderRepository,
            auditLogger,
            orderValidator
    );

    /**
     * Protects the authentication contract.
     *
     * <p>This is the exact check the flawed refactor silently deleted.</p>
     */
    @Test
    void rejectsUnauthenticatedUser() {
        OrderRequest request = validRequest();

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(false, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("UNAUTHORIZED", response.getErrorCode());

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /** Protects the missing-request contract, lost to a generic BAD_REQUEST in the flawed refactor. */
    @Test
    void rejectsMissingOrderRequest() {
        OrderResponse response = orderService.placeOrder(
                null,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_ORDER", response.getErrorCode());
    }

    /**
     * Protects customer-id validation.
     *
     * <p>Blank customer ids should be rejected, not treated as valid customers.</p>
     */
    @Test
    void rejectsBlankCustomerId() {
        OrderRequest request = new OrderRequest(
                " ",
                List.of(new OrderItem("SKU-1", 1, BigDecimal.TEN)),
                "tok_123"
        );

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_CUSTOMER", response.getErrorCode());

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /** Protects the empty-items contract. */
    @Test
    void rejectsEmptyItems() {
        OrderRequest request = new OrderRequest(
                "cust-123",
                List.of(),
                "tok_123"
        );

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("EMPTY_ORDER", response.getErrorCode());
    }

    /** Protects blank payment token validation, which the flawed refactor's null-only check missed. */
    @Test
    void rejectsBlankPaymentToken() {
        OrderRequest request = new OrderRequest(
                "cust-123",
                List.of(new OrderItem("SKU-1", 1, BigDecimal.TEN)),
                " "
        );

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_PAYMENT", response.getErrorCode());

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /** Protects blank SKU validation, which the flawed refactor's null-only check missed. */
    @Test
    void rejectsBlankSku() {
        OrderRequest request = new OrderRequest(
                "cust-123",
                List.of(new OrderItem(" ", 1, BigDecimal.TEN)),
                "tok_123"
        );

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_ITEM", response.getErrorCode());

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /**
     * Protects quantity validation.
     *
     * <p>Zero quantity is invalid because it can create nonsensical orders and downstream accounting issues.</p>
     */
    @Test
    void rejectsZeroQuantity() {
        OrderRequest request = new OrderRequest(
                "cust-123",
                List.of(new OrderItem("SKU-1", 0, BigDecimal.TEN)),
                "tok_123"
        );

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_QUANTITY", response.getErrorCode());

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /**
     * Protects inventory-specific behavior.
     *
     * <p>The out-of-stock error code, and the specific SKU it names, are part of the public
     * behavior clients may depend on.</p>
     */
    @Test
    void returnsOutOfStockWhenInventoryUnavailable() {
        OrderRequest request = validRequest();

        when(inventoryClient.checkAvailability("SKU-1", 2))
                .thenReturn(new InventoryStatus(false));

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("OUT_OF_STOCK", response.getErrorCode());
        assertTrue(response.getMessage().contains("SKU-1"));

        verifyNoInteractions(paymentClient);
        verifyNoInteractions(orderRepository);
    }

    /** Protects the declined-payment contract, renamed to PAYMENT_FAILED in the flawed refactor. */
    @Test
    void rejectsDeclinedPayment() {
        OrderRequest request = validRequest();

        when(inventoryClient.checkAvailability("SKU-1", 2))
                .thenReturn(new InventoryStatus(true));

        when(paymentClient.charge("tok_123", new BigDecimal("20"), "cust-123"))
                .thenReturn(new PaymentResult(false));

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertFalse(response.isSuccess());
        assertEquals("PAYMENT_DECLINED", response.getErrorCode());

        verifyNoInteractions(orderRepository);
    }

    /**
     * Protects the happy path.
     *
     * <p>Successful orders should calculate total, charge payment, and save the order.</p>
     */
    @Test
    void placesOrderWhenInventoryAndPaymentSucceed() {
        OrderRequest request = validRequest();

        when(inventoryClient.checkAvailability("SKU-1", 2))
                .thenReturn(new InventoryStatus(true));

        when(paymentClient.charge("tok_123", new BigDecimal("20"), "cust-123"))
                .thenReturn(new PaymentResult(true));

        OrderResponse response = orderService.placeOrder(
                request,
                new UserContext(true, "user-123")
        );

        assertTrue(response.isSuccess());
        assertEquals(new BigDecimal("20"), response.getTotal());

        verify(orderRepository).save(any(Order.class));
    }

    /**
     * Regression test for the flawed refactor's most severe defect: logging the raw payment token.
     *
     * <p>Captures every message passed to the audit logger across both the decline and success
     * paths and asserts none of them contain the token.</p>
     */
    @Test
    void neverLogsPaymentToken() {
        OrderRequest request = validRequest();
        String secretToken = "tok_123";

        when(inventoryClient.checkAvailability("SKU-1", 2))
                .thenReturn(new InventoryStatus(true));
        when(paymentClient.charge(secretToken, new BigDecimal("20"), "cust-123"))
                .thenReturn(new PaymentResult(false));

        orderService.placeOrder(request, new UserContext(true, "user-123"));

        when(paymentClient.charge(secretToken, new BigDecimal("20"), "cust-123"))
                .thenReturn(new PaymentResult(true));

        orderService.placeOrder(request, new UserContext(true, "user-123"));

        ArgumentCaptor<String> warnMessages = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> infoMessages = ArgumentCaptor.forClass(String.class);
        verify(auditLogger, atLeastOnce()).warn(warnMessages.capture());
        verify(auditLogger, atLeastOnce()).info(infoMessages.capture());

        for (String message : warnMessages.getAllValues()) {
            assertFalse(message.contains(secretToken), "warn log leaked the payment token: " + message);
        }
        for (String message : infoMessages.getAllValues()) {
            assertFalse(message.contains(secretToken), "info log leaked the payment token: " + message);
        }
    }

    /** Builds a valid request used by tests that do not focus on request validation. */
    private OrderRequest validRequest() {
        return new OrderRequest(
                "cust-123",
                List.of(new OrderItem("SKU-1", 2, BigDecimal.TEN)),
                "tok_123"
        );
    }
}
