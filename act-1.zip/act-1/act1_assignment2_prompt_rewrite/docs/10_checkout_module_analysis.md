# Checkout Module Analysis

**Scope:** `src/main/java/com/acme/checkout/` (`CheckoutController`, `LegacyCheckoutService`, and boundary interfaces/DTOs)
**Mode:** Analysis only. No files were modified as part of producing this document.

---

## 1. Current Responsibilities of the Module

- **`CheckoutController`** — a pure pass-through facade. It holds no business logic; it just delegates `checkout(request, userContext)` to `LegacyCheckoutService`.
- **`LegacyCheckoutService.checkout(...)`** is a single method that currently owns at least six distinct responsibilities:
  1. Authentication check (`UserContext`)
  2. Request-shape and field-level validation (customer id, cart id, payment token, items)
  3. Per-item domain validation (SKU, quantity, price)
  4. Orchestration of external boundaries (cart validation, inventory check, payment capture, order creation)
  5. Pricing calculation (running total via `BigDecimal`)
  6. Audit logging (decline and success events)
- **DTOs** (`CheckoutRequest`, `CheckoutItem`, `CheckoutResponse`, `UserContext`, `CartStatus`, `InventoryStatus`, `PaymentResult`) are simple, immutable value carriers with no self-validation — all enforcement happens inside `LegacyCheckoutService`.
- **Boundary interfaces** (`PaymentGateway`, `InventoryClient`, `CartClient`, `OrderClient`, `AuditLogger`) define the module's contracts with external systems.

## 2. Current API Behavior and Error Responses

`CheckoutController.checkout(CheckoutRequest, UserContext) → CheckoutResponse`, where the response is either `success(orderId, total)` or `failure(errorCode, message)`.

Error codes, in the order they are evaluated (validation short-circuits on first failure):

| Order | Error Code | Trigger |
|---|---|---|
| 1 | `UNAUTHORIZED` | `userContext` is null or not authenticated |
| 2 | `INVALID_CHECKOUT_REQUEST` | `request` is null |
| 3 | `INVALID_CUSTOMER` | customer id null/blank |
| 4 | `INVALID_CART` | cart id null/blank |
| 5 | `INVALID_PAYMENT` | payment token null/blank |
| 6 | `EMPTY_CART` | items null/empty |
| 7 | `INVALID_CART` | `CartClient.validateCart(...)` reports invalid (**reuses code from row 4**) |
| 8 | `INVALID_ITEM` | item SKU null/blank (per item, in list order) |
| 9 | `INVALID_QUANTITY` | item quantity ≤ 0 |
| 10 | `INVALID_PRICE` | item unit price null or negative |
| 11 | `INVENTORY_UNAVAILABLE` | inventory check fails for an item |
| 12 | `PAYMENT_DECLINED` | payment gateway declines |

**Notable ambiguity:** `INVALID_CART` is emitted for two semantically different conditions — a missing field (row 4) vs. a failed ownership check against `CartClient` (row 7). Clients cannot currently distinguish these from the error code alone.

The per-item loop fails fast on the *first* invalid item rather than collecting all errors, so response content for a multi-error cart depends on item order.

## 3. Dependencies on Payment, Inventory, Cart, and Order Services

- **`CartClient.validateCart(cartId, customerId) → CartStatus`** — called once, before the item loop.
- **`InventoryClient.checkAvailability(sku, quantity) → InventoryStatus`** — called once per item, inside the loop, before payment.
- **`PaymentGateway.authorizeAndCapture(paymentToken, total, customerId) → PaymentResult`** — called once, after every item has passed validation and inventory check.
- **`OrderClient.createOrder(customerId, cartId, items, total, paymentId) → orderId`** — called once, only after payment is approved.
- **`AuditLogger`** — side-channel; `warn` on payment decline (customer id only, no token), `info` on success (order id + customer id).

**Load-bearing sequence:** cart validation → per-item validation + inventory check + running total → payment authorize/capture → order creation → audit log. This ordering is intentional and documented in comments (inventory-before-payment prevents charging for unfulfillable items).

## 4. Signs of Hidden Coupling or Mixed Concerns

- `checkout()` is a god-method mixing authentication, validation, pricing, orchestration, and logging — a textbook SRP violation.
- Total-price calculation is embedded directly in the same loop that does validation and inventory checks, so pricing logic cannot be tested or reused independently.
- `INVALID_CART` is shared between two unrelated failure types (see §2), coupling field-presence validation to ownership validation through one error code.
- Audit logging is interleaved with business logic rather than centralized, so any future behavior change risks also touching log statements.
- DTOs describe validation rules only in Javadoc; the rules are enforced far away, inside the service — an anemic-model pattern that makes it easy for the rules to drift from the objects they describe.
- `CartStatus`, `InventoryStatus`, and `PaymentResult` carry only booleans, with no reason/error detail — the service has to invent its own message strings, coupling presentation text to boundary responses that carry no context.
- `CheckoutController` is currently clean (no logic), which is good — but it means 100% of boundary-preservation risk is concentrated in `LegacyCheckoutService`. Any refactor must resist the temptation to "helpfully" move logic into the controller.

## 5. Existing Test Coverage and Test Gaps

**Covered** (`LegacyCheckoutServiceTest`, 6 tests):
- Unauthenticated user → `UNAUTHORIZED`, no payment interaction
- Blank customer id → `INVALID_CUSTOMER`
- Blank payment token → `INVALID_PAYMENT`
- Zero quantity → `INVALID_QUANTITY`
- Inventory unavailable → `INVENTORY_UNAVAILABLE`, no payment interaction (sequence check)
- Happy path → success, order id, total (single item only)

**Not covered:**
- Null request (`INVALID_CHECKOUT_REQUEST`)
- Blank cart id (`INVALID_CART`, field-missing branch)
- Cart invalid for customer (`INVALID_CART`, ownership branch) — the dual-meaning ambiguity from §2 is entirely untested
- Empty items list (`EMPTY_CART`)
- Blank/null item SKU (`INVALID_ITEM`)
- Negative or null unit price (`INVALID_PRICE`)
- Payment declined path (`PAYMENT_DECLINED`) and its audit `warn` log
- Success-path audit `info` log content
- Multi-item total calculation (only a single-item sum is tested)
- `CheckoutController` — no test file exists for it at all
- No test asserts the payment token is never logged, despite this being a stated hard requirement
- No test locks in per-item validation order (SKU → quantity → price → inventory) across multiple items

## 6. Security and Validation Risks

- **Payment token never logged today** — correct, but unenforced by any test. This is the single highest-value invariant to protect with a regression test before any refactor touches logging or the payment path.
- Audit messages are built via string concatenation with unvalidated input (`customerId`), which is a log-injection risk (e.g., embedded newlines) and a potential PII exposure if `customerId` is itself sensitive (e.g., an email).
- No length/format validation on `sku`, `customerId`, `cartId`, or `paymentToken` before they reach downstream systems or logs.
- No visible idempotency protection — a retried request could trigger a duplicate payment capture and a duplicate order. Not covered by any test or code path today.
- DTO constructors perform no validation themselves; all enforcement lives downstream in the service, so any other code path constructing these objects directly bypasses the checks.
- **Authorization gap:** the service checks `userContext.isAuthenticated()` but never verifies that `userContext.getUserId()` matches `request.getCustomerId()`. An authenticated user could submit a checkout naming a different customer id. This looks like a genuine finding to raise with the architect — not something to silently fix.

## 7. Proposed Refactoring Plan (Small Reviewable Steps)

This is a proposal only; no code has been changed.

1. **This PR — analysis only.** No production code changes.
2. Add characterization tests for every currently-untested branch listed in §5 (including the `INVALID_CART` ambiguity and multi-item totals) before touching any production code.
3. Extract per-item validation (SKU/quantity/price) into a small pure `CheckoutItemValidator`, unit-tested in isolation. `LegacyCheckoutService` calls it; error codes and ordering stay identical.
4. Extract total-price calculation into a pure `CheckoutPricingCalculator`, tested with multi-item and non-trivial decimal cases.
5. Flag (not resolve) the `INVALID_CART` dual-meaning issue to the architect as a proposed API change (e.g., a new `CART_OWNERSHIP_INVALID` code) — only proceed with explicit sign-off, since it's a public behavior change.
6. Consider consolidating audit-logging calls behind one narrow method (e.g., `logCheckoutOutcome(...)`) to reduce interleaving, without changing log content or level.
7. Raise the authorization gap from §6 as a separate proposal to the architect — this is a behavior change, not a refactor, and needs its own decision and rollout.

Each step ships as its own small, revertible PR. No step changes external behavior or error codes without explicit architect approval.

## 8. Files Likely to Change (Across the Full Plan)

- `LegacyCheckoutService.java` — primary extraction target
- `LegacyCheckoutServiceTest.java` — new characterization tests added; existing tests untouched
- New: `CheckoutItemValidator.java`, `CheckoutPricingCalculator.java` (if steps 3–4 proceed), plus their test files
- New: `CheckoutControllerTest.java` (currently missing)

**Not expected to change:** `CheckoutController.java`, `PaymentGateway.java`, `InventoryClient.java`, `CartClient.java`, `OrderClient.java`, `AuditLogger.java`, `CheckoutRequest.java`, `CheckoutResponse.java`, `CheckoutItem.java`, `CartStatus.java`, `InventoryStatus.java`, `PaymentResult.java`, `UserContext.java` — these are boundary/DTO contracts and should remain stable absent explicit approval.

## 9. Behavior That Must Remain Unchanged

- Validation order and fail-fast semantics: auth → request null → customer id → cart id → payment token → items empty → cart ownership → per-item (SKU → quantity → price → inventory, in list order) → payment → order creation.
- All existing error codes exactly as-is, including both uses of `INVALID_CART`.
- Inventory-checked-before-payment sequencing.
- Payment token never appears in any log statement.
- Decline log includes customer id, never the payment token; success log includes order id and customer id.
- Total = sum(unit price × quantity) via `BigDecimal`, computed only over items that passed validation.
- `CheckoutController` remains a pure pass-through with no business logic.
- Public constructors/getters on all current DTOs (`CheckoutRequest`, `CheckoutItem`, `CheckoutResponse`, `UserContext`, `CartStatus`, `InventoryStatus`, `PaymentResult`).

## 10. Rollback Risks

- Payment capture and order creation are two separate external calls with no visible compensating action if order creation fails after a successful capture (no refund/void path in this module). Any refactor that changes sequencing or error handling between them risks introducing (or obscuring) an orphaned-charge window — this is a pre-existing gap, not something to fix silently in the same change as an unrelated refactor.
- Changing the per-item loop's fail-fast behavior (e.g., validating all items instead of stopping at the first bad one) would change externally visible responses for multi-error carts; there are currently no multi-item negative tests to catch this.
- Extracting pricing logic risks subtle `BigDecimal` scale/rounding drift if operations aren't reproduced exactly; current tests only use whole-number amounts, so non-trivial decimals should be added before extraction.
- If the `INVALID_CART` ambiguity is ever split into two codes, any client parsing error codes will silently misclassify one of the two cases unless the change is coordinated and released as an isolated, revertible commit.
- No test exists for `CheckoutController` today, so a regression introduced there would not be caught by the current suite and would only surface in later manual or staging verification — increasing the cost of detecting (and therefore rolling back) a bad change.

---

## Constraints Observed While Producing This Analysis

- Preserve public API behavior — not evaluated for change here; documented in §9.
- Preserve existing error codes unless explicitly approved — flagged as a decision point in §2 and §7, not altered.
- No tests removed or weakened — no test files were modified.
- No new frameworks introduced.
- Domain logic confirmed to already sit outside the controller (§1, §4).
- Payment logic confirmed to remain behind `PaymentGateway` (§3).
- No payment tokens, secrets, or PII included in this document.
- No files were modified in producing this analysis.

**Next step:** await approval before proceeding to Step 2 of the refactoring plan (§7).
