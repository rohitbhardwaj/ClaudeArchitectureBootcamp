# Act 1 Overview

## Narrative purpose

Act 1 creates the tension for the whole workshop: Claude can accelerate change, but speed without architecture produces faster uncertainty.

## Core frameworks

### VIBE

- **V**ague intent
- **I**nstant generation
- **B**lind trust
- **E**ntropy at scale

### GEAR

- **G**uardrails
- **E**valuation
- **A**rchitecture judgment
- **R**eview discipline

## Control-system diagnosis

Participants should discover five missing controls:

1. **Intent boundary** — what outcome was required?
2. **Change boundary** — which files, layers, and contracts were in scope?
3. **Evidence boundary** — what tests and checks prove safety?
4. **Authority boundary** — which changes required approval?
5. **Recovery boundary** — how could the change be contained or rolled back?

## Transition to Act 2

Act 1 asks why architecture is necessary. Act 2 maps the complete Claude architecture landscape where those controls must operate.
