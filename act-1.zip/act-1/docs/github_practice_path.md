# GitHub Practice Path

## Core workshop path

Use these during the facilitated session:

1. `act1_vibe_coding_simulation`
2. `act1_assignment2_prompt_rewrite`
3. `act1_assignment4_claude_boundaries`

## Extended practice path

Use these after the live session:

4. `act1_assignment3_architecture_risk_radar`
5. `act1_assignment5_production_incident_role_play`
6. `act1_assignment6_personal_reflection`

## Suggested pull-request workflow

Participants may create a branch such as:

```bash
git checkout -b act1/<name>-governed-restart
```

They should commit:

- a completed review worksheet,
- a safer prompt,
- one repository rule,
- one quality-gate recommendation.

Suggested commit message:

```text
act1: add governed restart plan for vibe coding incident
```

Suggested PR title:

```text
[Act 1] Replace vibe coding with bounded engineering workflow
```
