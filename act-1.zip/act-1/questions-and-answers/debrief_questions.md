# Debrief Questions

1. Which failure looked like a code defect but was actually an architecture-control failure?
2. Which existing test created false confidence?
3. What should have been characterized before refactoring?
4. Which part of the generated change had the largest blast radius?
5. What action should have required explicit approval?
6. What would you add to CLAUDE.md?
7. What would you add to the PR template?
8. What CI gate would have caught part of the risk?
9. What risk would CI still not catch without human judgment?
10. What is the smallest safe restart step?
