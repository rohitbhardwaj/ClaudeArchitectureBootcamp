# Act 1 Certification-Style Questions

## Question 1

A developer asks Claude to “clean up” a payment service. Claude changes 24 files, modifies a shared retry utility, and updates tests. CI passes, but downstream reconciliation fails.

What should the architect do first before the workflow is reused?

A. Add a stronger sentence telling Claude to be careful.  
B. Disable Claude Code for all payment code.  
C. Define scope, non-goals, contract constraints, characterization tests, review ownership, and rollback evidence before execution.  
D. Add more unit tests after the next change.

**Answer: C**

The architecture must bound the change before execution. More instructions or tests alone do not address authority, scope, contracts, and recovery.

## Question 2

Which signal is weakest when used alone to approve an AI-generated refactor?

A. Green tests  
B. Small change set  
C. Explicit architecture boundary  
D. Named reviewer approval

**Answer: A**

Green tests only prove the assertions that exist. They may omit important behavior or have been weakened to match the new implementation.

## Question 3

Which action should normally require the strongest approval in Act 1’s scenario?

A. Reading project documentation  
B. Running unit tests  
C. Changing authentication, payment, or data-contract behavior  
D. Formatting source files

**Answer: C**

High-impact and hard-to-reverse changes require stronger review and evidence.

## Question 4

What is the best meaning of “architecture control system” in this act?

A. One long system prompt  
B. A combination of repository rules, scoped permissions, tests, review gates, CI controls, ownership, and rollback  
C. A larger model  
D. Manual code review only

**Answer: B**

No single prompt or gate is sufficient. The control system is layered and operational.

## Question 5

A team wants speed without reviewing every low-risk action. Which principle is best?

A. Approve everything manually.  
B. Give Claude full autonomy after one successful run.  
C. Match autonomy and approval to blast radius, reversibility, and evidence.  
D. Use CI as the only control.

**Answer: C**
