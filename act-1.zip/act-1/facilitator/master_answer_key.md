# Master Answer Key

## Expected diagnosis

The strongest answer is not “Claude generated bad code.” The strongest answer is that the delivery system allowed an under-specified, high-blast-radius change to proceed without architecture controls.

## Expected findings

### Architecture

- Responsibilities moved across layers without an explicit decision.
- Shared behavior changed outside the original request.
- Hidden coupling increased.
- Public or downstream behavior was not protected as a contract.

### Testing

- Tests were added after behavior changed rather than characterizing behavior first.
- Passing tests prove only what was asserted.
- Failure paths and contract behavior were incomplete.
- Assertions may have been weakened or aligned to the new implementation.

### Security and data

- Logging or errors may expose sensitive information.
- Validation assumptions changed.
- Authentication, payments, or data paths lacked named review ownership.

### Review

- The diff was treated as code output rather than an architecture change.
- The change set was too broad for effective review.
- No explicit plan, risk summary, or changed-contract list existed.

### Recovery

- No feature flag, rollback evidence, or containment plan was required.
- The team could not explain the safest rollback unit.

## Best restart sequence

1. Inspect and summarize current behavior.
2. Identify impacted files and contracts.
3. Add characterization tests.
4. Propose a small-step plan.
5. Obtain approval.
6. Implement one reviewable slice.
7. Run targeted and regression checks.
8. Explain residual risk and rollback.

## Best policy principle

> Allow speed where blast radius is small. Require approval where impact is high or difficult to reverse.
