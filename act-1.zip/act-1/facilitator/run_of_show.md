# Facilitator Run of Show

## Total recommended time: 55–70 minutes

### 0–5 min — Frame the incident

Read the Friday prompt and Monday outcome. Do not explain the answer yet.

Ask:

> “Everything was green. Production was not. What failed?”

### 5–12 min — Individual diagnosis

Participants inspect the incident and list risks silently.

### 12–30 min — Team simulation

Teams compare original and refactored code and complete the review sheet.

Prompt teams to look beyond syntax:

- behavior,
- boundaries,
- contracts,
- security,
- observability,
- rollback.

### 30–42 min — Governed restart

Teams rewrite the original prompt and define an approval checkpoint.

### 42–52 min — Boundary policy

Teams classify representative actions as ALLOW / ASK / DENY.

### 52–62 min — Debrief

Use the debrief questions and reveal expected findings.

### 62–70 min — Bridge

Ask each team to state one new repository rule. Close with:

> “AI does not remove architecture. AI increases the need for architecture.”
