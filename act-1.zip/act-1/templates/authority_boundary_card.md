# Claude Authority Boundary Card

## Task

Describe the task Claude is being asked to perform:

## ALLOW — low-risk actions Claude may perform

1.
2.
3.

## ASK — actions requiring human approval

1.
2.
3.

## DENY — actions Claude must not perform in this workflow

1.
2.
3.

## Mandatory approval owner

- Role:
- Approval point:
- Evidence required:

## Rollback or containment action

- Trigger:
- Action:
- Owner:
