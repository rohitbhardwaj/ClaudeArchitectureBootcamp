# VIBE → GEAR Worksheet

| VIBE symptom | Evidence in scenario | GEAR correction | Repository control |
|---|---|---|---|
| Vague intent |  | Guardrails |  |
| Instant generation |  | Evaluation |  |
| Blind trust |  | Architecture judgment |  |
| Entropy at scale |  | Review discipline |  |

## Final diagnosis

The incident happened because:

## First control to add

## Why this control should exist before execution
