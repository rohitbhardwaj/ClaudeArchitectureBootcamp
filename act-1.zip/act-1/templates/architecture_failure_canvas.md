# Architecture Failure Canvas

## Intended change

## Actual change

## Blast radius

- Files:
- Layers:
- Contracts:
- Data:
- Operations:

## Missing controls

| Control | Missing evidence | Risk created | Corrective action |
|---|---|---|---|
| Intent |  |  |  |
| Scope |  |  |  |
| Tests |  |  |  |
| Security |  |  |  |
| Review |  |  |  |
| Rollback |  |  |  |

## Decision

- [ ] Proceed
- [ ] Proceed with conditions
- [ ] Stop and redesign
