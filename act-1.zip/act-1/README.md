# Claude Production Architecture Bootcamp

## Act 1 — The Day Vibe Coding Hit Production

This package supports the opening act of the full-day workshop. It turns the production-failure story into a practical architecture exercise.

### Act thesis

> Claude did not fail alone. The engineering system failed to define boundaries, evidence, approval, and rollback.

### Learning outcomes

Participants will be able to:

1. Distinguish fast AI-generated output from governed engineering change.
2. Diagnose architecture, testing, security, review, and rollback failures.
3. Apply the VIBE → GEAR model.
4. Define what Claude may do, must ask before doing, and must never do.
5. Convert incident lessons into repository rules and quality gates.

### Recommended flow

| Segment | Time | Artifact |
|---|---:|---|
| Opening production story | 10 min | Slides 1–7 |
| Failure-system diagnosis | 10 min | Architecture Risk Radar |
| VIBE → GEAR model | 5 min | Participant handout |
| Main simulation | 20–25 min | Vibe Coding Simulation |
| Prompt rewrite | 10–15 min | Governed Prompt Worksheet |
| Debrief and team policy | 10 min | Claude Boundary Card |

The full package contains six assignments. For a 25-minute conference talk, use only the simulation. For the full-day workshop, use the simulation plus two selected assignments and leave the others as GitHub practice.

### Directory map

```text
act-1/
├── act1_vibe_coding_simulation/
├── act1_assignment2_prompt_rewrite/
├── act1_assignment3_architecture_risk_radar/
├── act1_assignment4_claude_boundaries/
├── act1_assignment5_production_incident_role_play/
├── act1_assignment6_personal_reflection/
├── docs/
├── facilitator/
├── participant/
├── questions-and-answers/
├── templates/
└── slides/
```

Start with [`act-1/START_HERE.md`](act-1/START_HERE.md).
