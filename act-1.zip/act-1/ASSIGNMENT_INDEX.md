# Act 1 Assignment Index

| Assignment | Primary skill | Recommended use | Time |
|---|---|---|---:|
| Vibe Coding Simulation | Diagnose uncontrolled AI change | Required live lab | 20–25 min |
| Prompt Rewrite | Convert vague request into bounded workflow | Required live or pair work | 10–15 min |
| Architecture Risk Radar | See system-level risks beyond code | Optional live / required homework | 15 min |
| Claude Boundaries | Define ALLOW / ASK / DENY | Required live debrief | 10 min |
| Production Incident Role Play | Practice cross-functional accountability | Extended workshop | 25–35 min |
| Personal Reflection | Convert learning into action | Closing or homework | 5–10 min |
