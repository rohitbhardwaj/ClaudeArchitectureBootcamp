# Act 1 One-Page Playbook

## Before Claude changes code

Ask:

1. What outcome is intended?
2. What is in scope?
3. What must not change?
4. Which contracts must be preserved?
5. Which tests prove behavior?
6. Which risks need named review?
7. How will the change be rolled back?

## VIBE warning signs

- “Make it better.”
- Broad or unclear scope
- Immediate editing
- Large multi-file diff
- Tests generated only after behavior changed
- Green CI treated as sufficient evidence
- No approval boundary
- No rollback story

## GEAR workflow

```text
Guardrails → Evaluation → Architecture judgment → Review discipline
```

## Memory line

> Plan before change. Constrain before generation. Test before trust. Review before merge.
