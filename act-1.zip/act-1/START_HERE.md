# Start Here — Act 1

## The Day Vibe Coding Hit Production

### Scenario

At 4:58 PM on Friday, a developer asks Claude:

> “Clean up this service and add tests.”

The generated change touches many files, moves responsibilities, weakens behavior protection, and still passes the visible checks. On Monday morning, production fails.

The exercise does not ask participants to blame the developer or the model. It asks them to diagnose the missing engineering control system.

## Recommended participant path

1. Read the incident brief in `act1_vibe_coding_simulation/README.md`.
2. Review the original and AI-refactored source.
3. Complete the architect review sheet.
4. Identify the missing boundaries and gates.
5. Rewrite the original request as a governed prompt.
6. Classify Claude actions as **ALLOW**, **ASK**, or **DENY**.
7. Record one repository rule that would prevent recurrence.

## Required team output

- Five failure findings
- One VIBE → GEAR diagnosis
- One governed restart prompt
- One ALLOW / ASK / DENY policy
- One CI or PR quality gate
- One rollback or incident-control improvement

## Success criteria

A strong answer identifies that “green tests” are insufficient evidence when:

- the wrong behavior is tested,
- existing assertions are weakened,
- contracts are changed implicitly,
- architecture boundaries drift,
- sensitive behavior lacks named review ownership,
- rollback evidence is absent.
