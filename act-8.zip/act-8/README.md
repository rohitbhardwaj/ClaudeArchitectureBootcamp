# Claude Production Architecture Workshop — Act 8

## Trusted RAG, Security, Evals, and Observability

This GitHub-ready package contains a dependency-free Java example showing how to build and test a controlled RAG pipeline.

The repository includes:

- tenant-aware document retrieval;
- source ownership and freshness checks;
- prompt-injection detection;
- context budgeting;
- answerability and safe refusal;
- citation validation;
- security and quality evaluations;
- structured telemetry;
- golden datasets;
- adversarial test cases;
- Claude Code project settings, hooks, and a reusable `/act8-review` skill;
- ten assignments with a model answer inside every assignment.

Core lesson:

> A grounded answer is not merely an answer with retrieved text. It is an answer produced from authorized, trusted, current evidence and verified by measurable controls.

## Quick start

No Maven dependency is required.

```bash
cd act-8-java-rag
./scripts/test.sh
./scripts/demo.sh
```

Then open `assignments/START_HERE.md`.

## Main scenario

The application answers enterprise refund-policy questions. It must:

1. authorize the caller and tenant;
2. retrieve only permitted sources;
3. reject stale, unowned, or suspicious documents;
4. fit evidence into a bounded context package;
5. generate a cited answer;
6. verify citations and answerability;
7. refuse safely when evidence is inadequate;
8. emit a replayable trace;
9. pass quality, security, and reliability evals.
