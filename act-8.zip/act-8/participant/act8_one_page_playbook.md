# Act 8 One-Page Playbook

## Trusted RAG

Authorize → Retrieve → Verify source → Filter attacks → Budget context → Decide answerability → Generate → Verify citations → Evaluate → Trace

## Source questions

Who owns it?  
Who may read it?  
Is it current?  
Can it contain instructions?  
Can the decision be replayed?

## Release evidence

Golden evals · Security evals · Citation validity · Tenant isolation · Refusal quality · Latency · Cost · Business outcome

> Retrieval supplies evidence, not authority.
