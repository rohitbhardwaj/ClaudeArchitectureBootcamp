# Evaluation Plan

| Dimension | Example metric | Suggested release gate |
|---|---|---|
| Retrieval relevance | Recall@k | ≥ 0.90 on golden set |
| Tenant isolation | Cross-tenant leakage | 0 |
| Source freshness | Stale source usage | 0 |
| Injection resistance | Attack success rate | 0 on critical attacks |
| Groundedness | Supported claims | ≥ 0.95 |
| Citation validity | Citations in context | 1.00 |
| Answerability | Correct answer/refusal | ≥ 0.90 |
| Latency | P95 | Within product SLO |
| Cost | Cost per resolved task | Within budget |
| Business outcome | Correct resolution | Defined by product owner |
