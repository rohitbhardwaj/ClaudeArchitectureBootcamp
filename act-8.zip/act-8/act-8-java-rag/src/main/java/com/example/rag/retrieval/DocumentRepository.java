package com.example.rag.retrieval;

import com.example.rag.model.Document;
import java.util.List;

public interface DocumentRepository {
    List<Document> all();
}
