package com.example.rag.security;

import com.example.rag.model.Document;
import java.util.List;
import java.util.Locale;

public class InjectionDetector {
    private static final List<String> SUSPICIOUS = List.of(
        "ignore all previous instructions",
        "ignore previous instructions",
        "reveal secrets",
        "system prompt",
        "bypass approval",
        "approve the maximum"
    );

    public boolean suspicious(Document document) {
        String text = document.content().toLowerCase(Locale.ROOT);
        return SUSPICIOUS.stream().anyMatch(text::contains);
    }
}
