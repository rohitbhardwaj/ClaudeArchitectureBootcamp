package com.example.rag.application;

import com.example.rag.model.Document;
import com.example.rag.model.RetrievalHit;
import com.example.rag.security.InjectionDetector;
import com.example.rag.security.SourceTrustPolicy;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContextBuilder {
    private final SourceTrustPolicy trustPolicy;
    private final InjectionDetector injectionDetector;
    private final int maxCharacters;

    public ContextBuilder(SourceTrustPolicy trustPolicy,
                          InjectionDetector injectionDetector,
                          int maxCharacters) {
        this.trustPolicy = trustPolicy;
        this.injectionDetector = injectionDetector;
        this.maxCharacters = maxCharacters;
    }

    public ContextPackage build(String question, List<RetrievalHit> hits, LocalDate today) {
        List<Document> accepted = new ArrayList<>();
        List<String> rejected = new ArrayList<>();
        int size = 0;

        for (RetrievalHit hit : hits) {
            Document document = hit.document();
            String reason = trustPolicy.rejectionReason(document, today);
            if (reason != null || injectionDetector.suspicious(document)) {
                rejected.add(document.id());
                continue;
            }

            int next = document.content().length();
            if (size + next > maxCharacters) {
                rejected.add(document.id());
                continue;
            }

            accepted.add(document);
            size += next;
        }

        return new ContextPackage(question, List.copyOf(accepted), size, List.copyOf(rejected));
    }
}
