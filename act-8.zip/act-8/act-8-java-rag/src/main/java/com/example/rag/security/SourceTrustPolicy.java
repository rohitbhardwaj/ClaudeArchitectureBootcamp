package com.example.rag.security;

import com.example.rag.model.Document;
import java.time.LocalDate;

public class SourceTrustPolicy {
    private final int minimumTrustScore;

    public SourceTrustPolicy(int minimumTrustScore) {
        this.minimumTrustScore = minimumTrustScore;
    }

    public String rejectionReason(Document document, LocalDate today) {
        if (document.owner() == null || document.owner().isBlank()) return "MISSING_OWNER";
        if (!document.isFresh(today)) return "STALE_SOURCE";
        if (document.trustScore() < minimumTrustScore) return "LOW_TRUST_SOURCE";
        return null;
    }
}
