package com.example.rag.model;

public record RetrievalHit(
    Document document,
    double score,
    String matchedTerms
) {}
