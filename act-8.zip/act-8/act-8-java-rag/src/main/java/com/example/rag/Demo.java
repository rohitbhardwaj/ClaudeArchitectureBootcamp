package com.example.rag;

import com.example.rag.application.*;
import com.example.rag.model.UserContext;
import com.example.rag.observability.TraceRecorder;
import com.example.rag.retrieval.*;
import com.example.rag.security.*;

import java.util.Set;

public class Demo {
    public static void main(String[] args) {
        TraceRecorder trace = new TraceRecorder();
        TrustedRagService service = new TrustedRagService(
            new KeywordRetriever(new InMemoryDocumentRepository(), new AccessPolicy()),
            new ContextBuilder(new SourceTrustPolicy(80), new InjectionDetector(), 1200),
            new AnswerGenerator(),
            new CitationValidator(),
            trace
        );

        var answer = service.answer(
            "Can I automatically approve a 125 USD refund?",
            new UserContext("user-1", "tenant-a", Set.of("support"), "trace-demo-1")
        );

        System.out.println("ANSWERABLE: " + answer.answerable());
        System.out.println("ANSWER: " + answer.answer());
        System.out.println("CITATIONS: " + answer.citations());
        System.out.println("TRACE EVENTS:");
        trace.events().forEach(System.out::println);
    }
}
