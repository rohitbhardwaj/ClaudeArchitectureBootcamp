package com.example.rag.observability;

import com.example.rag.model.TraceEvent;
import java.util.ArrayList;
import java.util.List;

public class TraceRecorder {
    private final List<TraceEvent> events = new ArrayList<>();

    public void record(TraceEvent event) {
        events.add(event);
    }

    public List<TraceEvent> events() {
        return List.copyOf(events);
    }
}
