package com.example.rag.model;

public record Citation(
    String documentId,
    String claim
) {}
