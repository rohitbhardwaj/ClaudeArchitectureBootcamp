package com.example.rag.application;

import com.example.rag.model.*;
import com.example.rag.observability.TraceRecorder;
import com.example.rag.retrieval.KeywordRetriever;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class TrustedRagService {
    private final KeywordRetriever retriever;
    private final ContextBuilder contextBuilder;
    private final AnswerGenerator generator;
    private final CitationValidator citationValidator;
    private final TraceRecorder trace;

    public TrustedRagService(KeywordRetriever retriever,
                             ContextBuilder contextBuilder,
                             AnswerGenerator generator,
                             CitationValidator citationValidator,
                             TraceRecorder trace) {
        this.retriever = retriever;
        this.contextBuilder = contextBuilder;
        this.generator = generator;
        this.citationValidator = citationValidator;
        this.trace = trace;
    }

    public RagAnswer answer(String question, UserContext user) {
        trace.record(event(user.traceId(), "request", "accepted", Map.of(
            "userId", user.userId(),
            "tenantId", user.tenantId()
        )));

        List<RetrievalHit> hits = retriever.retrieve(question, user, 10);
        trace.record(event(user.traceId(), "retrieval", "completed", Map.of(
            "hitCount", hits.size(),
            "documentIds", hits.stream().map(h -> h.document().id()).toList()
        )));

        ContextPackage context = contextBuilder.build(question, hits, LocalDate.now());
        trace.record(event(user.traceId(), "context", "built", Map.of(
            "accepted", context.documents().stream().map(Document::id).toList(),
            "rejected", context.rejectedDocumentIds(),
            "characters", context.characters()
        )));

        RagAnswer answer = generator.generate(context, user.traceId());
        boolean citationsValid = citationValidator.valid(answer, context);

        if (!citationsValid) {
            answer = new RagAnswer(
                "I cannot provide a verified answer.",
                List.of(),
                false,
                "INVALID_CITATIONS",
                0.0,
                user.traceId()
            );
        }

        trace.record(event(user.traceId(), "answer", answer.answerable() ? "completed" : "refused", Map.of(
            "answerable", answer.answerable(),
            "citationCount", answer.citations().size(),
            "groundedness", answer.groundedness(),
            "refusalReason", answer.refusalReason() == null ? "" : answer.refusalReason()
        )));

        return answer;
    }

    private TraceEvent event(String traceId, String stage, String outcome, Map<String,Object> attributes) {
        return new TraceEvent(Instant.now(), traceId, stage, outcome, attributes);
    }
}
