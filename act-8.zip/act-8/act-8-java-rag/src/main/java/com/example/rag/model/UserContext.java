package com.example.rag.model;

import java.util.Set;

public record UserContext(
    String userId,
    String tenantId,
    Set<String> roles,
    String traceId
) {}
