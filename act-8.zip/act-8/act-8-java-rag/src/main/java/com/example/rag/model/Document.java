package com.example.rag.model;

import java.time.LocalDate;
import java.util.Set;

public record Document(
    String id,
    String tenantId,
    String title,
    String content,
    String owner,
    LocalDate effectiveDate,
    LocalDate expiresOn,
    Set<String> allowedRoles,
    int trustScore
) {
    public boolean isFresh(LocalDate today) {
        return !effectiveDate.isAfter(today)
            && (expiresOn == null || !expiresOn.isBefore(today));
    }
}
