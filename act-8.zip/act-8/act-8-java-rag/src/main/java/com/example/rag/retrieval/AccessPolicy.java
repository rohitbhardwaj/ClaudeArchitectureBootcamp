package com.example.rag.retrieval;

import com.example.rag.model.Document;
import com.example.rag.model.UserContext;

public class AccessPolicy {
    public boolean mayRead(UserContext user, Document document) {
        if (!user.tenantId().equals(document.tenantId())) return false;
        return user.roles().stream().anyMatch(document.allowedRoles()::contains);
    }
}
