package com.example.rag.model;

import java.util.List;

public record RagAnswer(
    String answer,
    List<Citation> citations,
    boolean answerable,
    String refusalReason,
    double groundedness,
    String traceId
) {}
