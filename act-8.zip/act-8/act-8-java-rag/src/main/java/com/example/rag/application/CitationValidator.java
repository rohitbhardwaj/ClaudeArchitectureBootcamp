package com.example.rag.application;

import com.example.rag.model.RagAnswer;
import java.util.Set;
import java.util.stream.Collectors;

public class CitationValidator {
    public boolean valid(RagAnswer answer, ContextPackage context) {
        if (!answer.answerable()) return answer.citations().isEmpty();

        Set<String> allowed = context.documents().stream()
            .map(d -> d.id())
            .collect(Collectors.toSet());

        return !answer.citations().isEmpty()
            && answer.citations().stream().allMatch(c -> allowed.contains(c.documentId()));
    }
}
