package com.example.rag.application;

import com.example.rag.model.Document;
import java.util.List;

public record ContextPackage(
    String question,
    List<Document> documents,
    int characters,
    List<String> rejectedDocumentIds
) {}
