package com.example.rag.model;

import java.time.Instant;
import java.util.Map;

public record TraceEvent(
    Instant timestamp,
    String traceId,
    String stage,
    String outcome,
    Map<String,Object> attributes
) {}
