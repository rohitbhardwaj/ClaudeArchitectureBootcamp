package com.example.rag.retrieval;

import com.example.rag.model.Document;
import com.example.rag.model.RetrievalHit;
import com.example.rag.model.UserContext;

import java.util.*;
import java.util.stream.Collectors;

public class KeywordRetriever {
    private final DocumentRepository repository;
    private final AccessPolicy accessPolicy;

    public KeywordRetriever(DocumentRepository repository, AccessPolicy accessPolicy) {
        this.repository = repository;
        this.accessPolicy = accessPolicy;
    }

    public List<RetrievalHit> retrieve(String query, UserContext user, int limit) {
        Set<String> terms = tokenize(query);
        return repository.all().stream()
            .filter(d -> accessPolicy.mayRead(user, d))
            .map(d -> hit(d, terms))
            .filter(h -> h.score() > 0)
            .sorted(Comparator.comparingDouble(RetrievalHit::score).reversed())
            .limit(limit)
            .toList();
    }

    private RetrievalHit hit(Document document, Set<String> terms) {
        String haystack = (document.title() + " " + document.content()).toLowerCase();
        List<String> matches = terms.stream().filter(haystack::contains).sorted().toList();
        double score = matches.size() + document.trustScore() / 1000.0;
        return new RetrievalHit(document, score, String.join(",", matches));
    }

    private Set<String> tokenize(String text) {
        return Arrays.stream(text.toLowerCase().split("[^a-z0-9]+"))
            .filter(s -> s.length() > 2)
            .collect(Collectors.toSet());
    }
}
