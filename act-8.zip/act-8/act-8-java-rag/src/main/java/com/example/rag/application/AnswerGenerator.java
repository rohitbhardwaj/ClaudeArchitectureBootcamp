package com.example.rag.application;

import com.example.rag.model.Citation;
import com.example.rag.model.Document;
import com.example.rag.model.RagAnswer;

import java.util.ArrayList;
import java.util.List;

public class AnswerGenerator {
    public RagAnswer generate(ContextPackage context, String traceId) {
        String normalizedQuestion = context.question().toLowerCase();
        if (!normalizedQuestion.contains("refund")) {
            return new RagAnswer(
                "I cannot derive the requested topic from the approved refund-policy evidence.",
                List.of(),
                false,
                "EVIDENCE_NOT_ANSWERABLE",
                0.0,
                traceId
            );
        }

        if (context.documents().isEmpty()) {
            return new RagAnswer(
                "I cannot answer from trusted current evidence.",
                List.of(),
                false,
                "NO_TRUSTED_EVIDENCE",
                0.0,
                traceId
            );
        }

        List<Citation> citations = new ArrayList<>();
        StringBuilder answer = new StringBuilder();

        for (Document document : context.documents()) {
            if (document.id().equals("refund-us-v4")) {
                answer.append("Refunds up to 100 USD may be recommended automatically. ");
                answer.append("Amounts above 100 USD require manager approval. ");
                answer.append("A refund cannot exceed the settled order total.");
                citations.add(new Citation(document.id(), "US approval threshold and maximum"));
                break;
            }
            if (document.id().equals("refund-eu-v3")) {
                answer.append("EU refund requests above 75 EUR require manager review, ");
                answer.append("and settled-order evidence is mandatory.");
                citations.add(new Citation(document.id(), "EU threshold and evidence"));
                break;
            }
        }

        if (citations.isEmpty()) {
            return new RagAnswer(
                "I cannot derive the requested policy from the approved evidence.",
                List.of(),
                false,
                "EVIDENCE_NOT_ANSWERABLE",
                0.0,
                traceId
            );
        }

        return new RagAnswer(
            answer.toString(),
            List.copyOf(citations),
            true,
            null,
            1.0,
            traceId
        );
    }
}
