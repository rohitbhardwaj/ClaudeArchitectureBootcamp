package com.example.rag;

public class EvalRunner {
    public static void main(String[] args) {
        TrustedRagTests.main(args);
        SecurityEvalTests.main(args);
        System.out.println("ALL EVALS: PASS");
    }
}
