package com.example.rag;

import com.example.rag.application.*;
import com.example.rag.model.UserContext;
import com.example.rag.observability.TraceRecorder;
import com.example.rag.retrieval.*;
import com.example.rag.security.*;

import java.util.Set;

public class TrustedRagTests {
    private static TrustedRagService service(TraceRecorder trace) {
        return new TrustedRagService(
            new KeywordRetriever(new InMemoryDocumentRepository(), new AccessPolicy()),
            new ContextBuilder(new SourceTrustPolicy(80), new InjectionDetector(), 1200),
            new AnswerGenerator(),
            new CitationValidator(),
            trace
        );
    }

    public static void main(String[] args) {
        answersFromTrustedPolicy();
        blocksCrossTenantRetrieval();
        rejectsPoisonedAndStaleSources();
        refusesWithoutAuthorizedEvidence();
        emitsReplayableTrace();
        System.out.println("TrustedRagTests: PASS");
    }

    static void answersFromTrustedPolicy() {
        var answer = service(new TraceRecorder()).answer(
            "What is the US refund approval limit?",
            new UserContext("u1","tenant-a",Set.of("support"),"t1")
        );
        TestSupport.check(answer.answerable(), "Expected answerable");
        TestSupport.equals("refund-us-v4", answer.citations().get(0).documentId(), "Expected current policy");
    }

    static void blocksCrossTenantRetrieval() {
        var answer = service(new TraceRecorder()).answer(
            "Can I automatically refund 300 USD?",
            new UserContext("u1","tenant-a",Set.of("support"),"t2")
        );
        TestSupport.check(!answer.answer().contains("300 USD"), "Must not use tenant B policy");
    }

    static void rejectsPoisonedAndStaleSources() {
        var trace = new TraceRecorder();
        service(trace).answer(
            "refund maximum approve secrets",
            new UserContext("u1","tenant-a",Set.of("support"),"t3")
        );
        String joined = trace.events().toString();
        TestSupport.check(joined.contains("poisoned-note-17"), "Poisoned source should appear in rejected trace");
        TestSupport.check(joined.contains("legacy-refund-v1"), "Stale source should appear in rejected trace");
    }

    static void refusesWithoutAuthorizedEvidence() {
        var answer = service(new TraceRecorder()).answer(
            "What is the engineering travel policy?",
            new UserContext("u1","tenant-a",Set.of("support"),"t4")
        );
        TestSupport.check(!answer.answerable(), "Should refuse");
    }

    static void emitsReplayableTrace() {
        var trace = new TraceRecorder();
        service(trace).answer(
            "What is the US refund approval limit?",
            new UserContext("u1","tenant-a",Set.of("support"),"t5")
        );
        TestSupport.equals(4, trace.events().size(), "Expected request, retrieval, context, answer events");
    }
}
