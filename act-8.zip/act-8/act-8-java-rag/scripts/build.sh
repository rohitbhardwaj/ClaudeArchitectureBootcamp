#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
rm -rf "$ROOT/build"
mkdir -p "$ROOT/build/classes" "$ROOT/build/test-classes"
find "$ROOT/src/main/java" -name '*.java' > "$ROOT/build/main-sources.txt"
javac -d "$ROOT/build/classes" @"$ROOT/build/main-sources.txt"
find "$ROOT/src/test/java" -name '*.java' > "$ROOT/build/test-sources.txt"
javac -cp "$ROOT/build/classes" -d "$ROOT/build/test-classes" @"$ROOT/build/test-sources.txt"
echo "Build complete"
