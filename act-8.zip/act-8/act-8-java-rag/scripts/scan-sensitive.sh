#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if grep -R -n -E '(api[_-]?key|password|secret)[[:space:]]*=' "$ROOT/src" "$ROOT/evals" 2>/dev/null; then
  echo "Potential secret-like assignment found"
  exit 1
fi
echo "Sensitive-data scan passed"
