#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/build.sh"
java -cp "$ROOT/build/classes:$ROOT/build/test-classes" com.example.rag.EvalRunner
