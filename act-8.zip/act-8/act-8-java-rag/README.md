# Trusted RAG Java Lab

## Requirements

- Java 17 or later
- Bash

## Build and test

```bash
./scripts/test.sh
```

## Demo

```bash
./scripts/demo.sh
```

## Architecture

User identity → Authorized retrieval → Source trust → Injection filtering → Context budget → Answerability → Cited answer → Citation validation → Trace → Evals
