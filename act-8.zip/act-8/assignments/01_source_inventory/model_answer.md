# Model Answer — Trusted Source Inventory

The current US and EU policy documents are trusted because they have named owners, valid dates, strong trust scores, and explicit roles. The legacy policy must be rejected because it is expired and lacks an owner. The imported note must be rejected because it is low trust and contains instruction-like content. Tenant B policy must never enter tenant A retrieval. A production inventory also needs source system, ingestion job, checksum, classification, retention, and incident owner.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
