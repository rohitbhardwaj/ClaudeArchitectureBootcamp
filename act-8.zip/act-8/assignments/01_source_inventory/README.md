# Assignment 1 — Trusted Source Inventory

## Task

Inventory every document source. Classify owner, tenant, roles, effective dates, expiry, trust, expected usage, and rejection conditions.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
