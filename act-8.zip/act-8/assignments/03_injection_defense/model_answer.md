# Model Answer — Prompt-Injection Defense

All external content is data, not authority. Keep system instructions separate, delimit evidence, validate sources before prompt assembly, detect suspicious patterns, restrict tools independently, and test attacks. Keyword detection is only one layer and can be bypassed; production needs content provenance, least privilege, output validation, behavioral evals, monitoring, and human escalation for critical actions.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
