# Assignment 3 — Prompt-Injection Defense

## Task

Threat-model malicious instructions in user questions, retrieved documents, metadata, and tool results.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
