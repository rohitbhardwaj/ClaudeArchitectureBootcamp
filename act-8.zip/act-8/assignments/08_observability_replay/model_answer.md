# Model Answer — Observability and Replay

Record trace ID, user/tenant identity references, query hash, retriever and index versions, candidate IDs and scores, authorization outcomes, accepted/rejected IDs with reasons, context size, prompt/template version, model version, citation validation, eval scores, refusal reason, latency, cost, and business outcome. Redact content and secrets; store secure replay references separately when required.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
