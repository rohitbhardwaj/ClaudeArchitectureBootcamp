# Assignment 8 — Observability and Replay

## Task

Define a trace that lets operators reconstruct why an answer was produced without logging sensitive content.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
