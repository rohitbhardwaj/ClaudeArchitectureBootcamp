# Worksheet — Context Budget and Answerability

## Current behavior

## Trust boundary

## Sources and identities

| Source or actor | Authorized? | Trusted? | Fresh? | Evidence |
|---|---|---|---|---|
| | | | | |

## Threats

| Threat | Prevent | Detect | Respond |
|---|---|---|---|
| | | | |

## Eval cases

## Trace requirements

## Decision
