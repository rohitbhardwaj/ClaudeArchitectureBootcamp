# Model Answer — Context Budget and Answerability

Select authorized and trusted evidence first, rank by relevance and authority, preserve source boundaries, and stop when the budget is full. Never truncate in a way that changes meaning. Refuse when no trusted evidence answers the question, when required sources conflict without resolution, or when evidence is incomplete. Record accepted and rejected source IDs and the context-budget decision.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
