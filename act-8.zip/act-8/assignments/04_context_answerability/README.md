# Assignment 4 — Context Budget and Answerability

## Task

Define selection, ordering, truncation, conflict, and refusal rules for a limited context window.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
