# Model Answer — Tenant-Aware Retrieval

Authorization must occur before retrieval and again at the data source where possible. The user tenant must equal the document tenant, and at least one user role must be allowed. Tests should prove tenant B documents never appear in tenant A hits, rejected lists, prompts, citations, or traces containing content. Do not depend on post-retrieval filtering alone for production data stores.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
