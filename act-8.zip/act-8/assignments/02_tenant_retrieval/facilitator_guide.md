# Facilitator Guide — Tenant-Aware Retrieval

## Watch for

- retrieval treated as truth;
- authorization after retrieval only;
- stale or ownerless sources;
- prompt-only injection defense;
- citations that merely look plausible;
- golden data changed to fit code;
- telemetry containing raw sensitive content;
- no refusal or rollback strategy.

## Debrief

1. Who owns the evidence?
2. Why is the source trusted?
3. What happens when evidence is inadequate?
4. Which eval blocks release?
5. Can an operator reconstruct the outcome safely?
