# Assignment 2 — Tenant-Aware Retrieval

## Task

Trace authorization from user identity through retrieval and context assembly. Identify bypass paths and propose tests.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
