# Assignment 5 — Citation and Groundedness Validation

## Task

Design a gate that verifies every material claim and every citation before returning an answer.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
