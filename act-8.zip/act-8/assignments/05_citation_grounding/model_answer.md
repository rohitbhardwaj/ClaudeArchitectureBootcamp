# Model Answer — Citation and Groundedness Validation

A citation must reference a document actually present in the approved context. Every material factual claim must be supported by one or more cited passages. Unsupported claims cause repair or refusal, not silent delivery. Groundedness should be evaluated independently from stylistic quality. For high-risk use cases, store claim-to-evidence mappings rather than document IDs alone.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
