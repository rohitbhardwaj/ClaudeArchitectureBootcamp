# Assignment 9 — Claude Code Guardrails

## Task

Review CLAUDE.md, project settings, hooks, and the Act 8 skill. Decide what is guidance, enforcement, or evidence.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
