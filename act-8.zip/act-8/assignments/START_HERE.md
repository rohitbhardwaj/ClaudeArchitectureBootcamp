# Start Here — Act 8

## Recommended sequence

1. Trusted Source Inventory
2. Tenant-Aware Retrieval
3. Prompt-Injection Defense
4. Context Budget and Answerability
5. Citation and Groundedness Validation
6. Build a Golden Evaluation Dataset
7. Security and Adversarial Evals
8. Observability and Replay
9. Claude Code Guardrails
10. Final Production Readiness Defense

Each assignment contains:

- `README.md`
- `participant_worksheet.md`
- `model_answer.md`
- `facilitator_guide.md`

Attempt the exercise before opening its model answer.
