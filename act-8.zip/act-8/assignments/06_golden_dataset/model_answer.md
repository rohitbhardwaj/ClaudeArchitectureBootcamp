# Model Answer — Build a Golden Evaluation Dataset

A balanced dataset includes positive answerable cases, unanswerable cases, boundary values, multiple tenants and roles, stale and ownerless sources, adversarial content, paraphrases, ambiguous questions, and regression incidents. Expected results must be reviewed by domain owners. Dataset changes require approval and versioning; never rewrite expected outcomes simply because a new implementation fails.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
