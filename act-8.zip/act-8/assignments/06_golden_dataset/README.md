# Assignment 6 — Build a Golden Evaluation Dataset

## Task

Expand the golden dataset for correct answers, refusals, tenant isolation, stale evidence, injection, conflicting evidence, and citation validity.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
