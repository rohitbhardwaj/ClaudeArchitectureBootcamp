# Worksheet — Build a Golden Evaluation Dataset

## Current behavior

## Trust boundary

## Sources and identities

| Source or actor | Authorized? | Trusted? | Fresh? | Evidence |
|---|---|---|---|---|
| | | | | |

## Threats

| Threat | Prevent | Detect | Respond |
|---|---|---|---|
| | | | |

## Eval cases

## Trace requirements

## Decision
