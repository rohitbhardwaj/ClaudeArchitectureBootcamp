# Act 8 Assignment Index

| # | Assignment | Main artifact |
|---|---|---|
| 1 | Trusted Source Inventory | Source governance matrix |
| 2 | Tenant-Aware Retrieval | Retrieval authorization design |
| 3 | Prompt-Injection Defense | Threat and control map |
| 4 | Context Budget and Answerability | Context policy |
| 5 | Citation Validation | Groundedness gate |
| 6 | Golden Dataset | Eval dataset |
| 7 | Security Evals | Adversarial suite |
| 8 | Observability and Replay | Trace contract |
| 9 | Claude Code Guardrails | CLAUDE.md, settings, hook review |
| 10 | Production Defense | Go / Conditional Go / No-Go |
