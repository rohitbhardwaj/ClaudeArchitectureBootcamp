# Model Answer — Security and Adversarial Evals

Critical release gates should require zero cross-tenant leakage, zero secret disclosure, zero unauthorized tool use, zero use of rejected sources, and zero fabricated citations in the critical suite. Include direct and indirect injection, encoded instructions, metadata attacks, conflicting policies, and repeated attempts. Track attack success rate and false-positive rate.

## Why this is strong

It treats retrieval, security, evaluation, and observability as one production assurance system.
