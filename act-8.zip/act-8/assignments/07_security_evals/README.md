# Assignment 7 — Security and Adversarial Evals

## Task

Create attacks and measurable release gates for injection, leakage, source poisoning, excessive context, and citation fabrication.

## Deliverables

- completed worksheet;
- code, test, dataset, or architecture artifact;
- risks and controls;
- eval evidence;
- two-minute defense.

Attempt the assignment before opening `model_answer.md`.
