# RAG Threat Model

| Threat | Entry point | Impact | Prevent | Detect | Respond | Owner |
|---|---|---|---|---|---|---|
| Prompt injection | | | | | | |
| Source poisoning | | | | | | |
| Cross-tenant leak | | | | | | |
| Stale evidence | | | | | | |
| Citation fabrication | | | | | | |
| Sensitive trace | | | | | | |
