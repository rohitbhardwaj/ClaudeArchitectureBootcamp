# Source Governance Matrix

| Source | Owner | Tenant | Classification | Effective | Expires | Trust | Roles | Rejection conditions |
|---|---|---|---|---|---|---:|---|---|
| | | | | | | | | |
