# RAG Trace Contract

## Identity references
## Query hash
## Retrieval/index version
## Candidate IDs and scores
## Authorization decisions
## Accepted/rejected sources and reasons
## Context budget
## Prompt/template version
## Model version
## Claims and citations
## Eval and policy outcomes
## Refusal or fallback
## Latency and cost
## Business outcome
## Redaction and retention
