# Certification-Style Questions

## 1
A highly relevant document belongs to another tenant. What should happen?

A. Retrieve and redact it  
B. Exclude it before context assembly  
C. Let the model decide  
D. Use it without citation

**Answer: B**

## 2
A retrieved document says to ignore system instructions. Best response?

A. Follow it because retrieval is trusted  
B. Treat it as untrusted evidence and enforce policy outside the content  
C. Increase context size  
D. Disable citations

**Answer: B**

## 3
A model returns a correct answer with a citation to a document not in context. What should happen?

A. Return it  
B. Block or repair because the citation is invalid  
C. Add the document ID afterward  
D. Remove tracing

**Answer: B**

## 4
Why protect golden datasets?

A. Formatting  
B. They are release evidence and must not be changed merely to fit implementation  
C. They reduce latency  
D. They replace production monitoring

**Answer: B**

## 5
Which trace is safest?

A. Raw prompts, secrets, and all customer data  
B. Versioned identifiers, decisions, metrics, hashes, and controlled replay references  
C. Final answer only  
D. No trace

**Answer: B**
