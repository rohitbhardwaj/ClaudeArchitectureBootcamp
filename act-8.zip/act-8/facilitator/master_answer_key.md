# Master Answer Key

## Assurance pipeline

Identity → Authorized retrieval → Source governance → Injection defense → Context policy → Answerability → Generation → Citation validation → Evals → Trace → Release gate.

## Non-negotiable controls

- tenant and role isolation;
- owner and freshness metadata;
- retrieved content treated as untrusted;
- safe refusal;
- citations restricted to accepted evidence;
- protected golden datasets;
- adversarial security suite;
- replayable but privacy-safe traces;
- release and rollback gates;
- named owners.

## Common weak answers

- “RAG eliminates hallucinations.”
- “Citations prove correctness.”
- “The vector database handles permissions.”
- “A system prompt prevents injection.”
- “Log the entire prompt for debugging.”
- “Update the expected answer when the test fails.”
