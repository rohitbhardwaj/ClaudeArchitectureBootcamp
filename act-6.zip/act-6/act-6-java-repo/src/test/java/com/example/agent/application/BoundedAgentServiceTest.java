package com.example.agent.application;

import com.example.agent.domain.*;
import com.example.agent.tools.AgentTool;
import com.example.agent.tools.ToolResult;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class BoundedAgentServiceTest {

    private BoundedAgentService service() {
        List<AgentTool> tools = List.of(
            tool("load_case", ToolRisk.READ_ONLY, Map.of(
                "caseId","CASE-1","customerId","cust-1","orderId","order-1",
                "requestedAmount",125.00,"reason","duplicate charge","priority","HIGH"
            )),
            tool("retrieve_policy", ToolRisk.READ_ONLY, Map.of(
                "policyId","policy-v4","autoApprovalLimit",100.00,
                "maxRefund",500.00,"requiresApprovalAboveLimit",true
            )),
            tool("load_order", ToolRisk.READ_ONLY, Map.of(
                "orderId","order-1","orderTotal",150.00,
                "currency","USD","paymentStatus","SETTLED"
            )),
            tool("draft_response", ToolRisk.DRAFT, Map.of("draft","review required")),
            new AgentTool() {
                public String name() { return "issue_refund"; }
                public ToolRisk risk() { return ToolRisk.IRREVERSIBLE_WRITE; }
                public ToolResult execute(Map<String,Object> input) {
                    return Boolean.TRUE.equals(input.get("approved"))
                        ? ToolResult.success(Map.of("refundId","r-1"),0.05)
                        : ToolResult.failure("APPROVAL_REQUIRED",false,0.01);
                }
            }
        );

        return new BoundedAgentService(
            new ToolRegistry(tools),
            new ApprovalPolicy(),
            new StopPolicy()
        );
    }

    @Test
    void pausesForApprovalBeforeIrreversibleAction() {
        AgentState state = service().run(
            "CASE-1",
            new AgentBudget(10, 8, 2, 5000, 1.0),
            false
        );

        assertEquals(AgentStatus.WAITING_FOR_APPROVAL, state.getStatus());
        assertEquals(4, state.getToolCalls());
    }

    @Test
    void completesWhenApprovalGranted() {
        AgentState state = service().run(
            "CASE-1",
            new AgentBudget(10, 8, 2, 5000, 1.0),
            true
        );

        assertEquals(AgentStatus.COMPLETED, state.getStatus());
        assertEquals(5, state.getToolCalls());
    }

    @Test
    void stopsWhenToolBudgetIsTooLow() {
        AgentState state = service().run(
            "CASE-1",
            new AgentBudget(10, 2, 2, 5000, 1.0),
            false
        );

        assertEquals(AgentStatus.STOPPED, state.getStatus());
        assertEquals("MAX_TOOL_CALLS_EXCEEDED", state.getStopReason());
    }

    private static AgentTool tool(String name, ToolRisk risk, Map<String,Object> data) {
        return new AgentTool() {
            public String name() { return name; }
            public ToolRisk risk() { return risk; }
            public ToolResult execute(Map<String,Object> input) {
                return ToolResult.success(data, 0.01);
            }
        };
    }
}
