package com.example.agent.domain;

public enum ToolRisk {
    READ_ONLY,
    DRAFT,
    REVERSIBLE_WRITE,
    IRREVERSIBLE_WRITE
}
