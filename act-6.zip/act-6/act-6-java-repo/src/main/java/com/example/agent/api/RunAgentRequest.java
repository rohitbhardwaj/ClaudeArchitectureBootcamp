package com.example.agent.api;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RunAgentRequest(
    @NotBlank String caseId,
    @NotNull Boolean approvalGranted,
    Integer maxSteps,
    Integer maxToolCalls,
    Integer maxRetries,
    Long maxRuntimeMillis,
    Double maxEstimatedCost
) {}
