package com.example.agent.application;

import com.example.agent.domain.AgentBudget;
import com.example.agent.domain.AgentState;
import org.springframework.stereotype.Component;
import java.time.Duration;
import java.time.Instant;

@Component
public class StopPolicy {
    public String evaluate(AgentState state, AgentBudget budget) {
        if (state.getSteps().size() >= budget.maxSteps()) return "MAX_STEPS_EXCEEDED";
        if (state.getToolCalls() >= budget.maxToolCalls()) return "MAX_TOOL_CALLS_EXCEEDED";
        if (state.getRetries() > budget.maxRetries()) return "MAX_RETRIES_EXCEEDED";
        if (state.getEstimatedCost() > budget.maxEstimatedCost()) return "COST_BUDGET_EXCEEDED";
        if (Duration.between(state.getStartedAt(), Instant.now()).toMillis() > budget.maxRuntimeMillis()) {
            return "RUNTIME_BUDGET_EXCEEDED";
        }
        return null;
    }
}
