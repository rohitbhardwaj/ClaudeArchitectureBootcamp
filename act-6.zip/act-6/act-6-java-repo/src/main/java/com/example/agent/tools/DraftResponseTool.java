package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class DraftResponseTool implements AgentTool {
    public String name() { return "draft_response"; }
    public ToolRisk risk() { return ToolRisk.DRAFT; }

    public ToolResult execute(Map<String, Object> input) {
        return ToolResult.success(Map.of(
            "draft", "Your refund request has been reviewed and requires approval.",
            "channel", "EMAIL"
        ), 0.03);
    }
}
