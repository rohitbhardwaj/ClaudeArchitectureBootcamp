package com.example.agent.domain;

import java.time.Instant;
import java.util.Map;

public record AgentStep(
    int sequence,
    StepType type,
    String toolName,
    ToolRisk risk,
    Map<String, Object> input,
    Map<String, Object> output,
    String status,
    Instant timestamp
) {}
