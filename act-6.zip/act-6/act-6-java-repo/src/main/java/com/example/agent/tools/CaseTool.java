package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class CaseTool implements AgentTool {
    public String name() { return "load_case"; }
    public ToolRisk risk() { return ToolRisk.READ_ONLY; }

    public ToolResult execute(Map<String, Object> input) {
        String caseId = String.valueOf(input.get("caseId"));
        return ToolResult.success(Map.of(
            "caseId", caseId,
            "customerId", "cust-100",
            "orderId", "order-900",
            "requestedAmount", 125.00,
            "reason", "duplicate charge",
            "priority", "HIGH"
        ), 0.01);
    }
}
