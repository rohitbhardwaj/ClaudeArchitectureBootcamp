package com.example.agent.api;

import com.example.agent.application.BoundedAgentService;
import com.example.agent.domain.AgentBudget;
import com.example.agent.domain.AgentState;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/agent-runs")
public class AgentController {

    private final BoundedAgentService service;

    public AgentController(BoundedAgentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<AgentState> run(@Valid @RequestBody RunAgentRequest request) {
        AgentBudget budget = new AgentBudget(
            request.maxSteps() == null ? 10 : request.maxSteps(),
            request.maxToolCalls() == null ? 8 : request.maxToolCalls(),
            request.maxRetries() == null ? 2 : request.maxRetries(),
            request.maxRuntimeMillis() == null ? 5000 : request.maxRuntimeMillis(),
            request.maxEstimatedCost() == null ? 1.00 : request.maxEstimatedCost()
        );

        return ResponseEntity.ok(
            service.run(request.caseId(), budget, request.approvalGranted())
        );
    }
}
