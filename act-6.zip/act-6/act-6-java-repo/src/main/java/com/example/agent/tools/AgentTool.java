package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import java.util.Map;

public interface AgentTool {
    String name();
    ToolRisk risk();
    ToolResult execute(Map<String, Object> input);
}
