package com.example.agent.application;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;

@Component
public class ApprovalPolicy {
    public boolean requiresApproval(ToolRisk risk, double amount, double autoApprovalLimit) {
        return risk == ToolRisk.IRREVERSIBLE_WRITE || amount > autoApprovalLimit;
    }
}
