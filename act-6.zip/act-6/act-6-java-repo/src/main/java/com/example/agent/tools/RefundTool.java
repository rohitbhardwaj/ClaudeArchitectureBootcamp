package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class RefundTool implements AgentTool {
    public String name() { return "issue_refund"; }
    public ToolRisk risk() { return ToolRisk.IRREVERSIBLE_WRITE; }

    public ToolResult execute(Map<String, Object> input) {
        if (!Boolean.TRUE.equals(input.get("approved"))) {
            return ToolResult.failure("APPROVAL_REQUIRED", false, 0.01);
        }
        return ToolResult.success(Map.of(
            "refundId", "refund-777",
            "status", "ISSUED",
            "amount", input.get("amount")
        ), 0.05);
    }
}
