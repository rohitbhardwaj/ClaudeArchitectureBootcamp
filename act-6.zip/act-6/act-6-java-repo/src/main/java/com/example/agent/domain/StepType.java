package com.example.agent.domain;

public enum StepType {
    LOAD_CASE,
    RETRIEVE_POLICY,
    LOAD_ORDER,
    EVALUATE_REFUND,
    DRAFT_RESPONSE,
    REQUEST_APPROVAL,
    ISSUE_REFUND,
    CLOSE_CASE
}
