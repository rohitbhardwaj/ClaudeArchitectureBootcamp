package com.example.agent.application;

import com.example.agent.domain.*;
import com.example.agent.tools.AgentTool;
import com.example.agent.tools.ToolResult;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
public class BoundedAgentService {

    private final ToolRegistry toolRegistry;
    private final ApprovalPolicy approvalPolicy;
    private final StopPolicy stopPolicy;

    public BoundedAgentService(
        ToolRegistry toolRegistry,
        ApprovalPolicy approvalPolicy,
        StopPolicy stopPolicy
    ) {
        this.toolRegistry = toolRegistry;
        this.approvalPolicy = approvalPolicy;
        this.stopPolicy = stopPolicy;
    }

    public AgentState run(String caseId, AgentBudget budget, boolean approvalGranted) {
        AgentState state = new AgentState(UUID.randomUUID(), caseId, new HashMap<>());
        state.setStatus(AgentStatus.RUNNING);

        execute(state, budget, StepType.LOAD_CASE, "load_case", Map.of("caseId", caseId));
        if (stopped(state)) return state;

        Map<String, Object> caseData = lastOutput(state);
        execute(state, budget, StepType.RETRIEVE_POLICY, "retrieve_policy", Map.of());
        if (stopped(state)) return state;

        Map<String, Object> policy = lastOutput(state);
        execute(state, budget, StepType.LOAD_ORDER, "load_order",
            Map.of("orderId", caseData.get("orderId")));
        if (stopped(state)) return state;

        double requested = ((Number) caseData.get("requestedAmount")).doubleValue();
        double orderTotal = ((Number) lastOutput(state).get("orderTotal")).doubleValue();
        double autoLimit = ((Number) policy.get("autoApprovalLimit")).doubleValue();

        if (requested > orderTotal) {
            state.stop("REQUEST_EXCEEDS_ORDER_TOTAL");
            return state;
        }

        state.getMemory().put("decision", requested <= autoLimit ? "APPROVE" : "REVIEW");
        state.getMemory().put("requestedAmount", requested);
        state.getMemory().put("policyId", policy.get("policyId"));

        execute(state, budget, StepType.DRAFT_RESPONSE, "draft_response",
            Map.of("decision", state.getMemory().get("decision")));
        if (stopped(state)) return state;

        boolean needsApproval = approvalPolicy.requiresApproval(
            ToolRisk.IRREVERSIBLE_WRITE, requested, autoLimit
        );

        if (needsApproval && !approvalGranted) {
            state.setStatus(AgentStatus.WAITING_FOR_APPROVAL);
            state.getMemory().put("approvalReason", "REFUND_REQUIRES_HUMAN_APPROVAL");
            return state;
        }

        execute(state, budget, StepType.ISSUE_REFUND, "issue_refund",
            Map.of("amount", requested, "approved", approvalGranted || !needsApproval));
        if (stopped(state)) return state;

        state.setStatus(AgentStatus.COMPLETED);
        return state;
    }

    private void execute(AgentState state, AgentBudget budget, StepType stepType,
                         String toolName, Map<String, Object> input) {
        String stop = stopPolicy.evaluate(state, budget);
        if (stop != null) {
            state.stop(stop);
            return;
        }

        AgentTool tool = toolRegistry.require(toolName);
        ToolResult result = tool.execute(input);
        state.incrementToolCalls();
        state.addCost(result.estimatedCost());

        state.addStep(new AgentStep(
            state.getSteps().size() + 1,
            stepType,
            tool.name(),
            tool.risk(),
            input,
            result.data(),
            result.success() ? "SUCCESS" : "FAILED:" + result.errorCode(),
            Instant.now()
        ));

        if (!result.success()) {
            if (result.retryable()) {
                state.incrementRetries();
            } else {
                state.stop(result.errorCode());
            }
        }

        String after = stopPolicy.evaluate(state, budget);
        if (after != null) state.stop(after);
    }

    private boolean stopped(AgentState state) {
        return state.getStatus() == AgentStatus.STOPPED
            || state.getStatus() == AgentStatus.FAILED;
    }

    private Map<String, Object> lastOutput(AgentState state) {
        return state.getSteps().get(state.getSteps().size() - 1).output();
    }
}
