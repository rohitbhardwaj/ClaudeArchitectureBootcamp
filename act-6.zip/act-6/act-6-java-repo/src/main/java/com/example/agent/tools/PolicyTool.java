package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class PolicyTool implements AgentTool {
    public String name() { return "retrieve_policy"; }
    public ToolRisk risk() { return ToolRisk.READ_ONLY; }

    public ToolResult execute(Map<String, Object> input) {
        return ToolResult.success(Map.of(
            "policyId", "refund-policy-v4",
            "autoApprovalLimit", 100.00,
            "maxRefund", 500.00,
            "requiresApprovalAboveLimit", true
        ), 0.02);
    }
}
