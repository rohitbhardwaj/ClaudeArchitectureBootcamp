package com.example.agent.domain;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class AgentState {
    private final UUID runId;
    private final String caseId;
    private final Instant startedAt;
    private AgentStatus status;
    private int toolCalls;
    private int retries;
    private double estimatedCost;
    private String stopReason;
    private final List<AgentStep> steps = new ArrayList<>();
    private final Map<String, Object> memory;

    public AgentState(UUID runId, String caseId, Map<String, Object> memory) {
        this.runId = runId;
        this.caseId = caseId;
        this.memory = memory;
        this.startedAt = Instant.now();
        this.status = AgentStatus.CREATED;
    }

    public UUID getRunId() { return runId; }
    public String getCaseId() { return caseId; }
    public Instant getStartedAt() { return startedAt; }
    public AgentStatus getStatus() { return status; }
    public int getToolCalls() { return toolCalls; }
    public int getRetries() { return retries; }
    public double getEstimatedCost() { return estimatedCost; }
    public String getStopReason() { return stopReason; }
    public List<AgentStep> getSteps() { return List.copyOf(steps); }
    public Map<String, Object> getMemory() { return memory; }

    public void setStatus(AgentStatus status) { this.status = status; }
    public void incrementToolCalls() { toolCalls++; }
    public void incrementRetries() { retries++; }
    public void addCost(double cost) { estimatedCost += cost; }
    public void addStep(AgentStep step) { steps.add(step); }
    public void stop(String reason) {
        this.status = AgentStatus.STOPPED;
        this.stopReason = reason;
    }
}
