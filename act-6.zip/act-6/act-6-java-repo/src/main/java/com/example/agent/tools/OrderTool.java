package com.example.agent.tools;

import com.example.agent.domain.ToolRisk;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class OrderTool implements AgentTool {
    public String name() { return "load_order"; }
    public ToolRisk risk() { return ToolRisk.READ_ONLY; }

    public ToolResult execute(Map<String, Object> input) {
        return ToolResult.success(Map.of(
            "orderId", input.get("orderId"),
            "orderTotal", 150.00,
            "currency", "USD",
            "paymentStatus", "SETTLED"
        ), 0.01);
    }
}
