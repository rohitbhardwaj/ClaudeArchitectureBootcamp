package com.example.agent.domain;

public record AgentBudget(
    int maxSteps,
    int maxToolCalls,
    int maxRetries,
    long maxRuntimeMillis,
    double maxEstimatedCost
) {}
