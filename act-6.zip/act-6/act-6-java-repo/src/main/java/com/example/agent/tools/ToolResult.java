package com.example.agent.tools;

import java.util.Map;

public record ToolResult(
    boolean success,
    Map<String, Object> data,
    String errorCode,
    boolean retryable,
    double estimatedCost
) {
    public static ToolResult success(Map<String, Object> data, double cost) {
        return new ToolResult(true, data, null, false, cost);
    }

    public static ToolResult failure(String code, boolean retryable, double cost) {
        return new ToolResult(false, Map.of(), code, retryable, cost);
    }
}
