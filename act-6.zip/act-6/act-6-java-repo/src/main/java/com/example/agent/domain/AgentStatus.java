package com.example.agent.domain;

public enum AgentStatus {
    CREATED,
    RUNNING,
    WAITING_FOR_APPROVAL,
    COMPLETED,
    FAILED,
    STOPPED
}
