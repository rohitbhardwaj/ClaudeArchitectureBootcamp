# Bounded Agent Workflow — Java Example

## Run

```bash
mvn test
mvn spring-boot:run
```

## Run without approval

```bash
curl -X POST http://localhost:8083/api/v1/agent-runs   -H 'Content-Type: application/json'   -d '{
    "caseId":"CASE-100",
    "approvalGranted":false,
    "maxSteps":10,
    "maxToolCalls":8,
    "maxRetries":2,
    "maxRuntimeMillis":5000,
    "maxEstimatedCost":1.0
  }'
```

Expected result: `WAITING_FOR_APPROVAL`.

## Run with approval

Set `approvalGranted` to `true`.

Expected result: `COMPLETED`.

## Simulate budget stop

Set `maxToolCalls` to `2`.

Expected result: `STOPPED` with `MAX_TOOL_CALLS_EXCEEDED`.
