# Agent Workflow Contract

## Goal
Resolve a refund support case using trusted evidence and bounded tools.

## Success
A valid recommendation, approved refund when authorized, drafted response, and complete audit trail.

## Stop conditions
- step budget exceeded;
- tool-call budget exceeded;
- retry budget exceeded;
- runtime budget exceeded;
- cost budget exceeded;
- request exceeds order total;
- required approval missing;
- tool returns non-retryable failure.

## Authority
The agent may read, retrieve, evaluate, and draft. Irreversible refund action requires external approval.
