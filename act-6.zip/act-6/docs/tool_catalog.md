# Tool Catalog

| Tool | Risk | Side effect | Approval |
|---|---|---|---|
| load_case | Read-only | None | No |
| retrieve_policy | Read-only | None | No |
| load_order | Read-only | None | No |
| draft_response | Draft | Creates draft only | No |
| issue_refund | Irreversible write | Financial action | Yes |
