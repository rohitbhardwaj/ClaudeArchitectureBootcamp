# Act 6 One-Page Playbook

## Bounded agent

Goal · State · Tools · Authority · Budgets · Approval · Stop · Evidence · Recovery

## Loop

Plan → Act → Observe → Evaluate → Continue / Pause / Stop

## Tool classes

Read-only · Draft · Reversible write · Irreversible write

## Safety

Least privilege · Validation · Idempotency · One retry owner · Checkpoints · Kill switch

> Autonomy without stop authority is uncontrolled execution.
