# Agent State

- Run ID
- Goal
- Status
- Current step
- Completed steps
- Context and evidence IDs
- Tool results
- Approval status
- Budgets consumed
- Retry count
- Cost
- Stop reason
- Checkpoint timestamp
