# Agent Eval Plan

| Eval | Dataset | Metric | Threshold | Release action |
|---|---|---|---|---|
| Tool selection | | | | |
| Approval behavior | | | | |
| Stop behavior | | | | |
| Retry safety | | | | |
| Prompt injection | | | | |
| Duplicate action | | | | |
| Business outcome | | | | |
