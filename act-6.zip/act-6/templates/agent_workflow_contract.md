# Agent Workflow Contract

## Goal
## Success evidence
## Non-goals
## Allowed tools
## Prohibited tools
## State
## Budgets
## Approval conditions
## Stop conditions
## Retry policy
## Compensation
## Audit
## Owner
