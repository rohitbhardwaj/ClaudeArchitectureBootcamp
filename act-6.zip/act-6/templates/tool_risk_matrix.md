# Tool Risk Matrix

| Tool | Read / Draft / Reversible / Irreversible | Identity | Validation | Approval | Idempotency | Audit |
|---|---|---|---|---|---|---|
| | | | | | | |
