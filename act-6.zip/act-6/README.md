# Claude Production Architecture Workshop — Act 6

## Agent SDK and Bounded Autonomous Workflows

This GitHub-ready package contains a working Java example of a bounded agent workflow, simulated tools, checkpoints, stop conditions, approval gates, audit events, tests, assignments, facilitator guides, and model answers inside every assignment.

Core lesson:

> Autonomy is safe only when goals, tools, authority, budgets, stop conditions, evidence, and recovery are explicit.

## Scenario

A support-resolution agent:

1. reads a support case;
2. retrieves the applicable refund policy;
3. loads the customer order;
4. evaluates refund eligibility;
5. drafts a response;
6. requests approval when the amount or risk is high;
7. records every step;
8. stops when budgets, safety rules, or required evidence are violated.

The Java implementation deliberately separates:

- planning;
- tool execution;
- policy;
- approval;
- state;
- audit;
- retry;
- stop authority.

## Quick start

```bash
cd act-6-java-repo
mvn test
mvn spring-boot:run
```

Then follow `assignments/START_HERE.md`.
