# Assignment 4 — Assignment 4 — Classify Tools and Authority

## Task


Classify tools as read-only, draft, reversible write, or irreversible write. Define identity, validation, approval, idempotency, and audit requirements.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
