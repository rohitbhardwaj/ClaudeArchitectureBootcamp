# Worksheet — Assignment 4 — Classify Tools and Authority

## Workflow decision

## Goal and success

## State required

## Tools and authority

| Tool or action | Risk | Approval | Idempotency | Audit |
|---|---|---|---|---|
| | | | | |

## Budgets and stop conditions

## Failure and recovery

## Evidence

## Final recommendation
