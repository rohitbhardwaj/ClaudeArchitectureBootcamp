# Model Answer — Assignment 4 — Classify Tools and Authority


Read-only: case, policy, order retrieval. Requires user-scoped authorization and source logging.

Draft: response drafting. No external side effect; still requires output validation.

Reversible write: case-tag update. Requires narrow scope, idempotency, and rollback.

Irreversible write: refund issuance. Requires named approval, amount validation, financial policy, idempotency, audit, and reconciliation.

The agent should never receive broader tool authority than the current step requires.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
