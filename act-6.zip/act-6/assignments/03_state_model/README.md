# Assignment 3 — Assignment 3 — Design the Agent State Model

## Task


Define the minimum state needed to pause, resume, audit, and recover the workflow.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
