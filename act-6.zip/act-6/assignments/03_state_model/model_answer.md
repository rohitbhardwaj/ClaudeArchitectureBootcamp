# Model Answer — Assignment 3 — Design the Agent State Model


State should include:
- run ID and case ID;
- status;
- current step;
- completed steps;
- tool calls and outputs;
- evidence IDs;
- policy version;
- approval status and approver;
- budgets consumed;
- retry count;
- estimated cost;
- stop reason;
- timestamps;
- idempotency keys for write actions.

The sample `AgentState` is intentionally minimal; production should persist checkpoints durably.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
