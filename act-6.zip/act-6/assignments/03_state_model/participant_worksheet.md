# Worksheet — Assignment 3 — Design the Agent State Model

## Workflow decision

## Goal and success

## State required

## Tools and authority

| Tool or action | Risk | Approval | Idempotency | Audit |
|---|---|---|---|---|
| | | | | |

## Budgets and stop conditions

## Failure and recovery

## Evidence

## Final recommendation
