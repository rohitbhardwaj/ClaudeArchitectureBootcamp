# Assignment 5 — Assignment 5 — Add Budgets and Loop Protection

## Task


Define limits for steps, tool calls, retries, runtime, tokens/cost, and repeated identical actions.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
