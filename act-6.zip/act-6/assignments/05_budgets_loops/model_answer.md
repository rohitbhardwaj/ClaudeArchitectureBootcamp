# Model Answer — Assignment 5 — Add Budgets and Loop Protection


Recommended starting controls:
- max 10 steps;
- max 8 tool calls;
- max 2 retries;
- max 5 seconds in the lab, longer in production as justified;
- cost budget per run;
- repeated-action detector;
- no retry for authorization or validation failures;
- one retry owner;
- hard stop followed by human escalation.

Budgets are policy controls, not performance suggestions.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
