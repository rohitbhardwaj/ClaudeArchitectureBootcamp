# Start Here — Act 6

## Recommended sequence

1. Agent or Deterministic Workflow?
2. Define Goal, Success, and Stop Conditions
3. Design the Agent State Model
4. Classify Tools and Authority
5. Add Budgets and Loop Protection
6. Add Human Approval Checkpoints
7. Design Retry, Resume, and Compensation
8. Threat-Model the Agent
9. Evaluate and Observe the Workflow
10. Final Autonomy Scale Decision

Each assignment includes:

- `README.md`
- `participant_worksheet.md`
- `model_answer.md`
- `facilitator_guide.md`
