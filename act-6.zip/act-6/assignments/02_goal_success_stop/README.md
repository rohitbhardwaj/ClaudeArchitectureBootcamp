# Assignment 2 — Assignment 2 — Define Goal, Success, and Stop Conditions

## Task


Write the workflow contract for the support-resolution agent. Define goal, success evidence, non-goals, escalation conditions, and stop conditions.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
