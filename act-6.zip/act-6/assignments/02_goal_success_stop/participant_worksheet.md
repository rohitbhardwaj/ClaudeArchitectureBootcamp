# Worksheet — Assignment 2 — Define Goal, Success, and Stop Conditions

## Workflow decision

## Goal and success

## State required

## Tools and authority

| Tool or action | Risk | Approval | Idempotency | Audit |
|---|---|---|---|---|
| | | | | |

## Budgets and stop conditions

## Failure and recovery

## Evidence

## Final recommendation
