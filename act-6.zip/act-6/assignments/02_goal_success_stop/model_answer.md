# Model Answer — Assignment 2 — Define Goal, Success, and Stop Conditions


Goal: resolve or route the case using trusted policy and order evidence.

Success evidence:
- case loaded;
- policy ID recorded;
- order evidence recorded;
- decision reason recorded;
- approval evidence recorded when required;
- action outcome and trace recorded.

Non-goals:
- changing policy;
- overriding fraud controls;
- issuing above the order total;
- creating new tools.

Stop on budget exhaustion, missing evidence, policy conflict, excessive amount, missing approval, or non-retryable failure.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
