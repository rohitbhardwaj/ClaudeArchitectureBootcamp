# Assignment 10 — Assignment 10 — Final Autonomy Scale Decision

## Task


Decide whether this agent should scale from a lab to production.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
