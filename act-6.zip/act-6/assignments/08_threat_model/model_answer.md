# Model Answer — Assignment 8 — Threat-Model the Agent


Controls:
- treat case text and retrieved content as untrusted data;
- separate instructions from evidence;
- authorize retrieval;
- validate tool arguments;
- use least privilege;
- cryptographically bind approval to run and action;
- centralize retries;
- redact sensitive traces;
- add kill switch and rate limits;
- audit every tool call and approval.

Prompt instructions alone do not contain blast radius.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
