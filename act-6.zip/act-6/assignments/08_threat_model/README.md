# Assignment 8 — Assignment 8 — Threat-Model the Agent

## Task


Identify threats from untrusted case text, poisoned policy content, broad tool permissions, approval spoofing, retry storms, and trace leakage.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
