# Assignment 1 — Assignment 1 — Agent or Deterministic Workflow?

## Task


For each case, choose deterministic orchestration, bounded agent workflow, or fully human workflow:

1. classify a support message;
2. retrieve policy and answer with citations;
3. investigate a case using multiple tools;
4. issue a $5 refund;
5. issue a $5,000 refund;
6. resolve an ambiguous fraud complaint.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
