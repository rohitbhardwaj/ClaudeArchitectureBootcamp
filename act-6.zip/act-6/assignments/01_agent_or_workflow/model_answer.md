# Model Answer — Assignment 1 — Agent or Deterministic Workflow?


1. Classification: deterministic API flow.
2. Policy answer: deterministic RAG flow.
3. Multi-tool investigation: bounded agent workflow.
4. $5 refund: deterministic workflow may be sufficient if policy is explicit.
5. $5,000 refund: human approval and controlled workflow.
6. Ambiguous fraud complaint: bounded investigation plus mandatory human decision.

Use an agent only when iteration, branching, and tool choice create real value.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
