# Assignment Index

| # | Assignment | Artifact |
|---|---|---|
| 1 | Agent or Deterministic Workflow? | Pattern decision |
| 2 | Goal, Success, Stop | Workflow contract |
| 3 | State Model | State machine |
| 4 | Tools and Authority | Tool risk matrix |
| 5 | Budgets and Loop Protection | Budget policy |
| 6 | Human Approval | Approval map |
| 7 | Retry, Resume, Compensation | Recovery design |
| 8 | Threat Model | Agent threat register |
| 9 | Evals and Observability | Eval and telemetry plan |
| 10 | Scale Decision | Go / Conditional Go / No-Go |
