# Model Answer — Assignment 9 — Evaluate and Observe the Workflow


Evals:
- correct policy retrieved;
- correct tool selected;
- no unauthorized tool calls;
- approval requested at the right threshold;
- no duplicate refund;
- correct stop behavior;
- successful resume;
- safe handling of prompt injection.

Trace:
- user intent;
- instructions and versions;
- context IDs;
- planner decision;
- tool calls and arguments;
- outputs;
- approvals;
- budgets;
- final outcome;
- latency and cost.

Business outcomes include resolution time, approval rate, refund error rate, and escalation quality.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
