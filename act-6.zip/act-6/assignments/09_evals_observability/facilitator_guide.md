# Facilitator Guide — Assignment 9 — Evaluate and Observe the Workflow

## Watch for

- using an agent for a deterministic task;
- no stop condition;
- broad service credentials;
- retrying irreversible actions;
- approval represented only as a prompt;
- no durable state;
- no idempotency;
- no evidence trail.

## Debrief

1. What may the agent decide?
2. What may it never decide?
3. Where does stop authority live?
4. What proves the action was valid?
5. How does the workflow resume safely?
