# Assignment 9 — Assignment 9 — Evaluate and Observe the Workflow

## Task


Define task, tool, policy, safety, reliability, and business evals. Define the trace.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
