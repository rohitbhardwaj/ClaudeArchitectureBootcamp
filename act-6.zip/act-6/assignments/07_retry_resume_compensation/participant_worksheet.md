# Worksheet — Assignment 7 — Design Retry, Resume, and Compensation

## Workflow decision

## Goal and success

## State required

## Tools and authority

| Tool or action | Risk | Approval | Idempotency | Audit |
|---|---|---|---|---|
| | | | | |

## Budgets and stop conditions

## Failure and recovery

## Evidence

## Final recommendation
