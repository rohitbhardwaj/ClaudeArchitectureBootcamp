# Model Answer — Assignment 7 — Design Retry, Resume, and Compensation


Transient read failure: bounded retry with backoff.

Timeout after refund submission: query by idempotency key before repeating.

Approval timeout: expire the checkpoint and route to human queue.

Service restart: reload durable state and continue from the last verified checkpoint.

Compensation: where writes are reversible, execute explicit compensating action. Financial refund may not be reversible, so prevention and reconciliation are more important than blind retry.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
