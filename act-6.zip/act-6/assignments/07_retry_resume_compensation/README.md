# Assignment 7 — Assignment 7 — Design Retry, Resume, and Compensation

## Task


Design recovery for transient tool failure, timeout after refund submission, approval timeout, and service restart.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
