# Assignment 6 — Assignment 6 — Add Human Approval Checkpoints

## Task


Define when the agent may continue automatically and when it must pause.


## Deliverables

- completed worksheet;
- architecture artifact;
- risk and control table;
- two-minute defense.

Read `model_answer.md` after attempting the assignment.
