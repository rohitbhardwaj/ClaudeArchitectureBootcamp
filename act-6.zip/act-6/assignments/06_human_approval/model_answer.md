# Model Answer — Assignment 6 — Add Human Approval Checkpoints


Automatic:
- read case;
- retrieve policy;
- load order;
- evaluate;
- draft response.

Pause for approval:
- any irreversible financial action;
- amount above auto-approval threshold;
- fraud hold;
- conflicting evidence;
- low confidence;
- policy exception.

Approval record must include approver identity, decision, timestamp, amount, evidence, and expiry.


## Why this answer is strong

It bounds autonomy using explicit authority, state, budgets, approval, evidence, and recovery.
