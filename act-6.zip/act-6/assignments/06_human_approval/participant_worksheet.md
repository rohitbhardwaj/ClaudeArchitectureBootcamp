# Worksheet — Assignment 6 — Add Human Approval Checkpoints

## Workflow decision

## Goal and success

## State required

## Tools and authority

| Tool or action | Risk | Approval | Idempotency | Audit |
|---|---|---|---|---|
| | | | | |

## Budgets and stop conditions

## Failure and recovery

## Evidence

## Final recommendation
