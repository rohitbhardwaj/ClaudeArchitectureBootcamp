# Master Answer Key

## Architecture pattern

Goal → Plan → Select tool → Validate authority → Execute → Record → Evaluate → Continue / Pause / Stop

## Required controls

- bounded tool catalog;
- risk classification;
- explicit state;
- budgets;
- stop authority;
- approval service;
- idempotency;
- checkpointing;
- one retry owner;
- compensation or reconciliation;
- evals and traces;
- kill switch.

## Common weak answers

- “The model will know when to stop.”
- “Approval is a prompt instruction.”
- “Retry every failure.”
- “Use one service account for all tools.”
- “Store only the final answer.”
- “Let the agent issue refunds and review later.”
