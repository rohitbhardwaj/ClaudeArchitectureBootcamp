# Certification-Style Questions

## 1
A workflow performs a fixed sequence with no branching. Best architecture?

A. Multi-agent system  
B. Deterministic orchestration  
C. Unbounded agent  
D. No validation

**Answer: B**

## 2
What is the best stop authority?

A. Model self-assessment only  
B. External policy enforcing budgets and safety conditions  
C. User patience  
D. Tool timeout only

**Answer: B**

## 3
A refund call times out after submission. What should happen first?

A. Retry immediately  
B. Query by idempotency key  
C. Increase temperature  
D. Start a second agent

**Answer: B**

## 4
Which action requires the strongest control?

A. Read policy  
B. Draft response  
C. Issue refund  
D. Summarize case

**Answer: C**

## 5
What must durable state support?

A. Styling  
B. Pause, resume, replay, audit, and recovery  
C. Larger prompts  
D. Fewer tests

**Answer: B**
